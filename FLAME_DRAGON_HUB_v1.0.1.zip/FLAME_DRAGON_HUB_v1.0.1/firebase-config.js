// Firebase Web API configuration for FLAME DRAGON HUB.
// These values identify your Firebase project; they are not server credentials.
// Replace the placeholder apiKey with the Web App config from Firebase Console.
window.FDH_FIREBASE_CONFIG = {
  apiKey: "PASTE_FIREBASE_WEB_API_KEY_HERE",
  projectId: "PASTE_FIREBASE_PROJECT_ID_HERE"
};
