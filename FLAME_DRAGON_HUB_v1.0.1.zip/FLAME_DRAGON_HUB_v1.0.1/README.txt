FLAME DRAGON HUB — Chrome Extension v0.9.2

This package is based on the supplied v0.9.1 archive. The original EvoWorld skin/pet
catalogs, animation data, sprite bridge, and replacement manager are preserved.

WHAT IS NEW IN 0.9.2
- Added an email/password account gate using Firebase Authentication REST endpoints.
- Added Login, Sign Up, Forgot Password, Remember Me, and Sign Out flows.
- Passwords are never saved by this extension. Only Firebase refresh tokens are stored:
  chrome.storage.local when Remember Me is checked, or chrome.storage.session otherwise.
  Chrome extension storage is scoped to this extension but is not encrypted at rest.
- Added a blue/purple dragon backdrop with subtle CSS motion and prefers-reduced-motion support.
- Google sign-in is intentionally disabled until a Google OAuth client is configured for the
  installed extension ID and linked to the Firebase project. It is not represented as working.

FIREBASE SETUP REQUIRED BEFORE ACCOUNT SIGN-IN CAN WORK
1. Open https://console.firebase.google.com/ and create/select a Firebase project.
2. In Authentication -> Sign-in method, enable Email/Password.
3. In Project settings -> General -> Your apps, create a Web app and copy its Web API Key.
4. Open firebase-config.js and replace the two placeholders:
     apiKey: "PASTE_FIREBASE_WEB_API_KEY_HERE"
     projectId: "PASTE_FIREBASE_PROJECT_ID_HERE"
   The Firebase Web API key is a public project identifier, not a server secret. Do not put
   service-account credentials or private keys in this extension.
5. Re-load the unpacked extension in chrome://extensions and test account creation, sign-in,
   password reset, Remember Me, and Sign Out. Password reset emails require a valid sender
   template/domain configuration in Firebase Authentication.
6. For Google sign-in, additional Google Cloud OAuth setup is required for the extension ID.
   The current build keeps that control disabled until that separate setup is completed.

SECURITY / SESSION NOTES
- Email/password authentication is performed by Firebase Authentication over HTTPS.
- The extension does not store the user's password.
- Remember Me stores a Firebase refresh token in chrome.storage.local; with Remember Me off,
  it uses chrome.storage.session and is cleared when the browser session ends.
- chrome.storage.local/session are extension-scoped storage APIs, not an encrypted password
  vault. Keep Chrome and the extension profile protected; never share the profile directory.
- The Firebase Web API key is not a secret. No service-account key is included.
- This is an account gate for the extension UI. It does not yet enforce per-user authorization
  on the EvoWorld game/CDN or sync skin selections between devices.

WHAT IS NEW IN 0.9.0
- Added the 22 character skins the live game has but the catalog was missing. The catalog was
  built from an older copy of the game bundle; the live bundle now lists 308 character skins
  across the four evolutions, and 22 of them were absent here. All 22 are now selectable and
  animated from their own artwork: 14 Grim Reaper skins (abyss, azureKnight, darkKnight, failed,
  halloween2026, lion, mysteriousKnight, nightOwl, nightWolf, oppressed, photon,
  polarBearFroster, skullExecutioner, spectralViking), 3 Pumpkin Ghost skins (halloween2026,
  halloween2026_quest, headless_2), 2 Ghostly Reaper skins (evilRabbit, halloween2026) and 3
  Ghosts collection (halloween2026, lunarPriestess, pureSoul).
- Every added skin was scanned on the CDN for the frames it really has, and each one already
  matches the engine's fixed slot count for its evolution, so the motion plays in full without
  being cut short.
- Note on leg animations: EvoWorld has no separate leg or limb animation. A character is a
  single sprite sequence per state, and the only states the game plays are idle, flying and
  attack. There is no scorpion creature in the game, its skin lists, its string tables or on the
  CDN, so no skin has independently animated legs to reproduce.

WHAT IS NEW IN 0.8.0
- New Pets section with all 41 pets the game can load. Pets are not characters: the game keeps
  them in their own namespace (/sprites/pets/<id>/<frame>.png), they have a single flapping
  animation instead of idle/flying/attack, and the number of artwork frames differs from the
  number of animation slots the game plays (pet_2 plays 6 slots over 4 frames, pet_40 plays 42
  slots over 8 frames). The Pets tab lists every pet with a real thumbnail, and selecting one
  redirects that pet's own frames, so it keeps its own artwork and animates. The frame list for
  every pet was taken from the game's own definitions and confirmed against the CDN.
- The popup has five tabs: Ghosts, Grim Reaper, Pumpkin Ghost, Ghostly Reaper, Pets.
- Pet redirect rules live in the same rule builder as the characters, but match the pet path and
  can never match a character folder (and the reverse), so the two namespaces cannot collide.

WHAT IS NEW IN 0.7.1
- Fixed a start-up bug introduced in 0.7.0: removing the language switcher left a call to the
  deleted setLanguage() function in the popup. That threw during start-up and stopped the skin
  catalog from loading, so the popup showed no skins at all. The call is gone and
  tools/test-popup.js now runs the popup's start-up against a stubbed browser, so a removed
  function, a missing element or a broken start-up fails the tests instead of reaching a release.
- The Ghosts section is the first tab and opens by default.
- The Ghosts section holds the game's own Halloween ghost skins, each animated from its
  real 7 flying frames: halloween2021 to halloween2025, screamingGhost, witch, dapper and the
  rest of the ghost evolution (43 skins). Every ghost skin was verified to have exactly 7 frames
  on the CDN, which is the number of slots the game plays for that evolution.

WHAT IS NEW IN 0.7.0
- The user interface is English only. The language buttons are gone; the extension is a public
  tool for an international audience.
- New collection: Ghosts (43 ghost skins). The game animates these with 7 flying frames;
  the CDN has no idle or attack folder for them, so those states reuse the flying frames exactly
  as the game does.
- Fixed the movement of six skins whose artwork cycles over more frames than the game has
  animation slots, so the game was cutting the motion short and never showing its end:
    grimReaper/halloween2020 idle   (7-frame cycle in 6 slots)  <- the reported skin
    grimReaper/imperial     idle   (7-frame cycle in 6 slots)
    pumpkinGhost/standard   flying (17-frame cycle in 9 slots)
    pumpkinGhost/bomb       flying (17-frame cycle in 9 slots)
    ghostlyReaper/demonic   attack (20-frame cycle in 16 slots)
    ghostlyReaper/pirate    attack (20-frame cycle in 16 slots)
  Each was thinned to the slot count by dropping its least-moving frames while keeping the first
  and last frame of the cycle, so the character now reaches the full extent of its motion and
  the step sizes stay even. No other skin was touched.

WHAT WAS BROKEN IN 0.6.1
The game plays a fixed number of animation slots per evolution and state (grimReaper: 6 idle,
5 flying, 8 attack) and reverses them, ping-pong. The extension maps the requested slot to the
Nth entry of the catalog list. When a skin's artwork cycle was longer than the slot count, the
tail of its motion was simply never played, so the character looked like it stopped short.

WHAT WAS BROKEN
1. page-bridge.js read the frame number with /(\\d+)/ instead of /(\d+)/, so every sprite
   request was treated as frame 1. The game received the same image for every frame, which is
   exactly what "the skin is frozen" looked like.
2. The redirect rule copied the requested frame number straight onto the replacement. Skins do
   not all have the same number of frames, so requests such as flying/6.png became a 404 and the
   character stopped animating. pumpkinGhost and ghostlyReaper have no idle folder at all.
3. Many catalog folder names did not match the live CDN (for example "gryphone" instead of
   "gryphon", "thumb_pharaoh" instead of "pharaoh", "fallenNight" instead of "fallenKnight").

WHAT IS FIXED
- The frame number is parsed correctly, so frames really change during movement.
- frames-catalog.json records the real frames of all 291 skins, generated from the live CDN by
  tools/build-frame-catalog.js. Redirect rules are built from it, so every requested frame
  resolves to a frame the replacement skin actually has, and a state that does not exist falls
  back to one that does.
- 22 folder names were corrected to their real CDN spelling.
- 84 skins the game uses were missing from the catalog and have been added, each with its own
  thumbnail cropped from its real sprite and its real frame counts. 12 skins that had no sprite
  folder on the CDN at all were removed instead of showing a preview that could never work.
- Each skin keeps its own artwork. Nothing is shared between skins.

INSTALL / UPDATE IN CHROME
1. Extract this ZIP completely to a normal folder.
2. Open chrome://extensions in Chrome.
3. Turn on Developer mode.
4. If an older FLAME DRAGON HUB unpacked extension is loaded, keep a backup of its folder.
5. Click Load unpacked and select the extracted FLAME_DRAGON_HUB_Chrome_Extension folder (the folder containing manifest.json).
6. Open the extension popup. Choose an evolution, select an original folder and replacement, then click “Add / Update Active Skin”.
7. For a custom upload, save the image in Add Your Skin, press Use on its saved card, choose the original skin folder, then click Add / Update Active Skin. Repeat with different original folders. The Active Skins list shows each mapping; Remove deletes only that mapping.
8. Open/reload EvoWorld to test. Use “Restore original sprites” to remove all active mappings.

MULTI-SKIN MANAGER
- Active mappings are stored locally and restored when Chrome starts.
- Each original folder can have one replacement per evolution. Adding another replacement for the same original folder updates that mapping instead of creating a conflict.
- The extension allows up to 900 active mappings as a safety cap under Chrome's regular-expression rule quota. This is not an unlimited number, and Chrome or browser policy may impose additional limits.
- A mapping is a URL-folder redirect, not a per-account change. Other players requesting the exact same source URL may also be affected.
- If two different source folders point to the same replacement folder, both use that replacement. You cannot map one exact source folder to multiple different replacements at the same time.

IMPORTANT FUNCTIONAL LIMITS
- This package contains 313 character catalog records: Grim Reaper 165, Pumpkin Ghost 55,
  Ghostly Reaper 47, and Ghosts 46, plus 42 pet records. The supplied archive includes 355
  PNG skin image assets. The catalogs and animation frame data are preserved from v0.9.1.
- Catalog names are taken from the skin lists inside the game bundle and verified against the live
  CDN, so every offered skin is one the game itself can request.
- Frame lists are contiguous 1..N. The game plays a fixed number of frames per evolution and state
  (Grim Reaper: 6 idle, 5 flying, 8 attack), and the extension maps requested frame N to the Nth
  entry of the list. A hole in the list shifted every later frame by one and played the wrong pose.
  Ten skins were affected, including grimReaper/halloween2020, whose flying list was missing
  frame 3 so it played 1,2,4,5,6 instead of 1,2,3,4,5.
- The redirect rules handle PNG frame URLs on all EvoWorld CDN hosts (cdn.eu, cdn.na, cdn1.as, cdn1.sa, cdn1.aus). Actual behaviour still needs testing in a live EvoWorld session.
- Uploaded custom images can be saved, then selected with the new Use button. Choose an original skin folder and click Add / Update Active Skin. The custom image bridge replaces matching HTML image elements with the uploaded image. A single still image does not become a real character animation. Animated GIFs may animate if EvoWorld renders the data URL as an animated image. It may not affect game renderers that load textures without HTMLImageElement.src.
- The skin catalog accepts source folder names containing spaces (for example, “dragon lord”); earlier validation rejected these names and could prevent those mappings from being added.
- This is an experimental local extension package, not a Chrome Web Store listing.

TEST CHECKLIST
- Check all three evolution tabs and skin counts.
- Add two different mappings, close/reopen the popup, and confirm both remain in Active Skins.
- Remove one mapping and confirm the other remains.
- Test a known valid original folder/replacement in EvoWorld.
- Use Restore original sprites and reload EvoWorld.
- If a skin fails, record the evolution, original folder, replacement folder, and console/network error; preview success alone does not prove the CDN redirect works.


Version 0.4.5: custom upload accepts GIF files and page bridge passes animated GIF data URLs. A still image does not gain animation; use an animated GIF for motion. In-game GIF rendering can depend on EvoWorld's sprite renderer.


Version 0.4.7 — custom multi-frame animation folder support
- In Add Your Skin, use the second folder picker to choose a folder containing idle/, flying/, and attack/ subfolders.
- Put numbered images in each state folder, e.g. idle/1.png, idle/2.png, flying/1.png, attack/1.png. Frame numbers should start at 1.
- The extension uses the requested EvoWorld animation state and frame number to choose the corresponding uploaded frame. If a requested frame is missing, it falls back to the first frame for that state, then the skin preview image.
- Limit: up to 90 frames total, each at most 2 MB, with a combined source size at most 20 MB.
- This works only where EvoWorld requests frames through matching HTML image URLs intercepted by page-bridge.js. If the game renders sprites through a different texture/canvas pipeline, the in-game behavior may require a different integration and must be tested.


Version 0.4.9 — removed synthetic fake motion frames. Uploaded still images are no longer distorted into invented poses; true custom animation requires real, separate frame artwork for idle/, flying/, and attack/.


Version 0.5.0 — repaired custom multi-frame animation upload
- Restored the animation-folder picker in Add Your Skin.
- Select a base image as before, then optionally select a folder tree containing idle/, flying/, and attack/ subfolders with numbered PNG/JPG/WebP frames (e.g. idle/1.png, flying/1.png, attack/1.png).
- Real frame images are stored with the custom skin and routed according to the requested animation state and frame number. No artificial zoom/rotation frames are generated.
- The bundled skin library is unchanged. Existing single-image custom skins remain supported and stay still (except animated GIFs where the game renderer honors GIF animation).
- Limits: 90 frames total, 2 MB per frame, 20 MB total. A complete animation needs actual artwork for all three states. Missing frame numbers fall back to the first frame of that state.
- The bridge intercepts HTMLImageElement src and setAttribute("src") requests only. If EvoWorld uses canvas/WebGL textures or another loading path for sprites, true in-game animation may still not be intercepted and must be tested in a live session.


Version 0.5.1 — automatic Grim Reaper frame sequence
- Removed the second animation-folder picker. The user chooses one custom image, then selects the target skin as before.
- For custom mappings in the Grim Reaper evolution only, the bridge automatically selects the supplied Purple Grim Reaper CDN frame sequences: attack 1–8, flying 1–5, idle 1–6. Pumpkin Ghost and Ghostly Reaper are not changed.
- Important visual limitation: these are full original Purple Grim Reaper images. They do not automatically transform a user's still image into the same poses, so while these source frames are used the in-game appearance is Purple Grim Reaper artwork rather than a faithful animated version of the uploaded skin. Genuine custom-looking animation requires matching artwork for each pose or a purpose-built sprite/texture rig.
- No bundled skin image files or skins.json entries were modified.
