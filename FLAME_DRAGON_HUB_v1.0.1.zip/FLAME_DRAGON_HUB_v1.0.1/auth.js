(() => {
  const config = window.FDH_FIREBASE_CONFIG || {};
  const localKey = "fdhAuthSession";
  const sessionKey = "fdhAuthSession";
  const $ = id => document.getElementById(id);
  let currentUser = null;

  function configured() {
    return typeof config.apiKey === "string" &&
      config.apiKey.length > 20 &&
      !config.apiKey.includes("PASTE_") &&
      typeof config.projectId === "string" &&
      config.projectId.length > 3 &&
      !config.projectId.includes("PASTE_");
  }
  function status(message, error=false) {
    const el = $("authStatus");
    if (!el) return;
    el.textContent = message || "";
    el.classList.toggle("error", !!error);
  }
  function showView(id) {
    document.querySelectorAll(".auth-view").forEach(v => v.classList.toggle("hidden", v.id !== id));
    status("");
  }
  function showApp(user) {
    currentUser = user;
    $("authScreen").classList.add("hidden");
    $("appShell").classList.remove("hidden");
    $("accountEmail").textContent = user.email || "Signed in";
    $("accountEmail").title = user.email || "";
  }
  function showLogin(message="") {
    currentUser = null;
    $("appShell").classList.add("hidden");
    $("authScreen").classList.remove("hidden");
    showView("loginView");
    status(message, !!message);
  }
  async function request(path, body, host="identitytoolkit.googleapis.com") {
    const response = await fetch(`https://${host}/v1/${path}?key=${encodeURIComponent(config.apiKey)}`, {
      method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)
    });
    const data = await response.json().catch(()=>({}));
    if (!response.ok) {
      const code = data?.error?.message || "UNKNOWN_ERROR";
      const messages = {
        EMAIL_EXISTS:"This email already has an account. Try signing in.",
        INVALID_EMAIL:"Enter a valid email address.",
        WEAK_PASSWORD:"Choose a stronger password (at least 6 characters).",
        EMAIL_NOT_FOUND:"No account was found for this email.",
        INVALID_PASSWORD:"The email or password is incorrect.",
        INVALID_LOGIN_CREDENTIALS:"The email or password is incorrect.",
        USER_DISABLED:"This account has been disabled.",
        TOO_MANY_ATTEMPTS_TRY_LATER:"Too many attempts. Please wait and try again.",
        OPERATION_NOT_ALLOWED:"Email/password sign-in is not enabled in Firebase Authentication.",
        API_KEY_INVALID:"The Firebase API key is invalid. Check firebase-config.js.",
        PROJECT_NOT_FOUND:"The Firebase project could not be found. Check the project settings."
      };
      throw new Error(messages[code] || `Authentication error: ${code.replaceAll("_"," ").toLowerCase()}`);
    }
    return data;
  }
  async function saveSession(data, remember) {
    const value = {refreshToken:data.refreshToken,email:data.email||"",localId:data.localId||"",remember:!!remember};
    await chrome.storage.session.set({[sessionKey]:value});
    if (remember) await chrome.storage.local.set({[localKey]:value});
    else await chrome.storage.local.remove(localKey);
  }
  async function clearSession() {
    await chrome.storage.local.remove(localKey);
    await chrome.storage.session.remove(sessionKey);
  }
  async function acceptAuth(data, remember) {
    await saveSession(data, remember);
    showApp({email:data.email, uid:data.localId});
  }
  async function refreshStoredSession() {
    const transient = await chrome.storage.session.get(sessionKey);
    const persistent = await chrome.storage.local.get(localKey);
    const saved = transient[sessionKey] || persistent[localKey];
    if (!saved?.refreshToken) return false;
    try {
      const data = await request("token", {
        grant_type:"refresh_token", refresh_token:saved.refreshToken
      }, "securetoken.googleapis.com");
      const renewed = {
        refreshToken:data.refresh_token,
        email:data.user_email || saved.email,
        localId:data.user_id || saved.localId,
        remember:!!saved.remember
      };
      await chrome.storage.session.set({[sessionKey]:renewed});
      if (saved.remember) await chrome.storage.local.set({[localKey]:renewed});
      showApp({email:renewed.email,uid:renewed.localId});
      return true;
    } catch (e) {
      await clearSession();
      showLogin("Your saved session expired. Please sign in again.");
      return false;
    }
  }
  async function bootstrap() {
    showLogin();
    if (!configured()) {
      status("Firebase is not configured yet. Add your Firebase Web App apiKey and projectId in firebase-config.js.", true);
      return;
    }
    await refreshStoredSession();
  }
  function busy(button, busy, label) {
    if (!button) return;
    button.disabled = busy;
    if (busy) { button.dataset.oldLabel=button.textContent; button.textContent=label||"Please wait…"; }
    else if (button.dataset.oldLabel) { button.textContent=button.dataset.oldLabel; delete button.dataset.oldLabel; }
  }

  document.querySelectorAll("[data-view]").forEach(button => button.addEventListener("click",()=>showView(button.dataset.view)));
  document.querySelectorAll("[data-toggle]").forEach(button => button.addEventListener("click",()=>{
    const input=$(button.dataset.toggle);
    input.type=input.type==="password"?"text":"password";
    button.textContent=input.type==="password"?"Show":"Hide";
  }));

  $("loginForm").addEventListener("submit", async event => {
    event.preventDefault();
    if (!configured()) { status("Set up Firebase first (see firebase-config.js).",true); return; }
    const button=$("signInButton"); busy(button,true,"Signing in…");
    try {
      const data=await request("accounts:signInWithPassword",{
        email:$("loginEmail").value.trim(),
        password:$("loginPassword").value,
        returnSecureToken:true
      });
      await acceptAuth(data,$("rememberMe").checked);
    } catch(e) { status(e.message,true); }
    finally { busy(button,false); }
  });

  $("signupForm").addEventListener("submit",async event=>{
    event.preventDefault();
    if (!configured()) { status("Set up Firebase first (see firebase-config.js).",true); return; }
    const password=$("signupPassword").value;
    if(password!==$("confirmPassword").value){status("The passwords do not match.",true);return;}
    if(password.length<6){status("Password must contain at least 6 characters.",true);return;}
    const button=$("createAccountButton");busy(button,true,"Creating account…");
    try {
      const data=await request("accounts:signUp",{email:$("signupEmail").value.trim(),password,returnSecureToken:true});
      await acceptAuth(data,true);
    } catch(e){status(e.message,true);}
    finally{busy(button,false);}
  });

  $("forgotForm").addEventListener("submit",async event=>{
    event.preventDefault();
    if (!configured()) { status("Set up Firebase first (see firebase-config.js).",true); return; }
    const button=$("resetPasswordButton");busy(button,true,"Sending…");
    try {
      await request("accounts:sendOobCode",{requestType:"PASSWORD_RESET",email:$("forgotEmail").value.trim()});
      status("Password reset email sent. Check your inbox and follow its link.");
    } catch(e){status(e.message,true);}
    finally{busy(button,false);}
  });

  $("signOutButton").addEventListener("click",async()=>{
    await clearSession();
    $("loginPassword").value="";
    showLogin("You have been signed out.");
  });

  // Google sign-in intentionally remains disabled until an OAuth client is configured
  // for this exact Chrome extension ID and Firebase project.
  $("googleSignIn").addEventListener("click",()=>status("Google sign-in is not configured. Email/password authentication is available after Firebase setup.",true));

  window.FDHAuth={bootstrap,get currentUser(){return currentUser;},isConfigured:configured};
  bootstrap().catch(e=>showLogin(`Could not restore your session: ${e.message}`));
})();
