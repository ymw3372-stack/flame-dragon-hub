const skinsData = {
  "grim-reaper": {
    "title": "Grim Reaper",
    "folder": "grim-reaper",
    "skins": [
      {
        "file": "alien.png",
        "name": "alien"
      },
      {
        "file": "archangel.webp",
        "name": "archangel"
      },
      {
        "file": "assasin.png",
        "name": "assasin"
      },
      {
        "file": "avocado.png",
        "name": "avocado"
      },
      {
        "file": "aztec.png",
        "name": "aztec"
      },
      {
        "file": "barbarianReaper.webp",
        "name": "barbarianReaper"
      },
      {
        "file": "basilic.webp",
        "name": "basilic"
      },
      {
        "file": "bear.png",
        "name": "bear"
      },
      {
        "file": "bee.png",
        "name": "bee"
      },
      {
        "file": "biohazard.png",
        "name": "biohazard"
      },
      {
        "file": "black.png",
        "name": "black"
      },
      {
        "file": "bony.png",
        "name": "bony"
      },
      {
        "file": "boss-old.png",
        "name": "boss-old"
      },
      {
        "file": "boss.png",
        "name": "boss"
      },
      {
        "file": "botAi.png",
        "name": "botAi"
      },
      {
        "file": "bunny.png",
        "name": "bunny"
      },
      {
        "file": "cactus.png",
        "name": "cactus"
      },
      {
        "file": "captain.png",
        "name": "captain"
      },
      {
        "file": "caveman.png",
        "name": "caveman"
      },
      {
        "file": "clownPierce.webp",
        "name": "clownPierce"
      },
      {
        "file": "cow.png",
        "name": "cow"
      },
      {
        "file": "cowboy.png",
        "name": "cowboy"
      },
      {
        "file": "cryptlord.png",
        "name": "cryptlord"
      },
      {
        "file": "cultist.png",
        "name": "cultist"
      },
      {
        "file": "cyber.png",
        "name": "cyber"
      },
      {
        "file": "cyborg.png",
        "name": "cyborg"
      },
      {
        "file": "cyclops.png",
        "name": "cyclops"
      },
      {
        "file": "darkgladiator.png",
        "name": "darkgladiator"
      },
      {
        "file": "dinosaur.png",
        "name": "dinosaur"
      },
      {
        "file": "doctor.png",
        "name": "doctor"
      },
      {
        "file": "dragon lord.png",
        "name": "dragon lord"
      },
      {
        "file": "easter.png",
        "name": "easter"
      },
      {
        "file": "emeraldgolem.png",
        "name": "emeraldgolem"
      },
      {
        "file": "evilsamurai.png",
        "name": "evilsamurai"
      },
      {
        "file": "faceless.png",
        "name": "faceless"
      },
      {
        "file": "fallen night.png",
        "name": "fallen night"
      },
      {
        "file": "farmer.png",
        "name": "farmer"
      },
      {
        "file": "frosty.png",
        "name": "frosty"
      },
      {
        "file": "goblin.png",
        "name": "goblin"
      },
      {
        "file": "goldenKnight.png",
        "name": "goldenKnight"
      },
      {
        "file": "grassgrower.png",
        "name": "grassgrower"
      },
      {
        "file": "green.png",
        "name": "green"
      },
      {
        "file": "gryphon.webp",
        "name": "gryphon"
      },
      {
        "file": "gryphone.png",
        "name": "gryphone"
      },
      {
        "file": "headless.png",
        "name": "headless"
      },
      {
        "file": "heart.png",
        "name": "heart"
      },
      {
        "file": "horn.png",
        "name": "horn"
      },
      {
        "file": "imperial.png",
        "name": "imperial"
      },
      {
        "file": "imperialDestroyer.png",
        "name": "imperialDestroyer"
      },
      {
        "file": "infernalbaron.png",
        "name": "infernalbaron"
      },
      {
        "file": "infernalblacksmith.png",
        "name": "infernalblacksmith"
      },
      {
        "file": "jester.png",
        "name": "jester"
      },
      {
        "file": "king.webp",
        "name": "king"
      },
      {
        "file": "kraken.webp",
        "name": "kraken"
      },
      {
        "file": "laser.png",
        "name": "laser"
      },
      {
        "file": "leopard.png",
        "name": "leopard"
      },
      {
        "file": "leprechuan.png",
        "name": "leprechuan"
      },
      {
        "file": "magmaReaper.webp",
        "name": "magmaReaper"
      },
      {
        "file": "maskednight.png",
        "name": "maskednight"
      },
      {
        "file": "mechaMinotaur.webp",
        "name": "mechaMinotaur"
      },
      {
        "file": "miner.png",
        "name": "miner"
      },
      {
        "file": "moaReaper.webp",
        "name": "moaReaper"
      },
      {
        "file": "mouseReaper.webp",
        "name": "mouseReaper"
      },
      {
        "file": "mummy.png",
        "name": "mummy"
      },
      {
        "file": "mysterious.png",
        "name": "mysterious"
      },
      {
        "file": "nebula.png",
        "name": "nebula"
      },
      {
        "file": "neko.png",
        "name": "neko"
      },
      {
        "file": "night.png",
        "name": "night"
      },
      {
        "file": "nightmare.png",
        "name": "nightmare"
      },
      {
        "file": "ninga.png",
        "name": "ninga"
      },
      {
        "file": "orange.png",
        "name": "orange"
      },
      {
        "file": "owl.png",
        "name": "owl"
      },
      {
        "file": "pharaoh.png",
        "name": "pharaoh"
      },
      {
        "file": "pig.png",
        "name": "pig"
      },
      {
        "file": "pineapple.png",
        "name": "pineapple"
      },
      {
        "file": "pirate.png",
        "name": "pirate"
      },
      {
        "file": "pixelvoices.png",
        "name": "pixelvoices"
      },
      {
        "file": "policeman.png",
        "name": "policeman"
      },
      {
        "file": "prehistoric.png",
        "name": "prehistoric"
      },
      {
        "file": "premuim.png",
        "name": "premuim"
      },
      {
        "file": "primitivewarrior.png",
        "name": "primitivewarrior"
      },
      {
        "file": "purple.png",
        "name": "purple"
      },
      {
        "file": "puzzle.png",
        "name": "puzzle"
      },
      {
        "file": "ragged.png",
        "name": "ragged"
      },
      {
        "file": "rainbow.webp",
        "name": "rainbow"
      },
      {
        "file": "raven.png",
        "name": "raven"
      },
      {
        "file": "red.png",
        "name": "red"
      },
      {
        "file": "retro.png",
        "name": "retro"
      },
      {
        "file": "retroKnight.png",
        "name": "retroKnight"
      },
      {
        "file": "robberReaper.webp",
        "name": "robberReaper"
      },
      {
        "file": "rockstar.png",
        "name": "rockstar"
      },
      {
        "file": "sakuraOniReaper.webp",
        "name": "sakuraOniReaper"
      },
      {
        "file": "samurai.webp",
        "name": "samurai"
      },
      {
        "file": "santa.png",
        "name": "santa"
      },
      {
        "file": "shamanReaper.webp",
        "name": "shamanReaper"
      },
      {
        "file": "shark.png",
        "name": "shark"
      },
      {
        "file": "sheep.png",
        "name": "sheep"
      },
      {
        "file": "skullwarrior.png",
        "name": "skullwarrior"
      },
      {
        "file": "soldier.png",
        "name": "soldier"
      },
      {
        "file": "split face.png",
        "name": "split face"
      },
      {
        "file": "star.png",
        "name": "star"
      },
      {
        "file": "steampunk.png",
        "name": "steampunk"
      },
      {
        "file": "swamp.png",
        "name": "swamp"
      },
      {
        "file": "thumb_ladyhell.webp",
        "name": "thumb_ladyhell"
      },
      {
        "file": "thumb_pharaoh.webp",
        "name": "thumb_pharaoh"
      },
      {
        "file": "thunderbolt.png",
        "name": "thunderbolt"
      },
      {
        "file": "tiger.png",
        "name": "tiger"
      },
      {
        "file": "toxicreaper.png",
        "name": "toxicreaper"
      },
      {
        "file": "tree.png",
        "name": "tree"
      },
      {
        "file": "twinbladeEvil.png",
        "name": "twinbladeEvil"
      },
      {
        "file": "unicorn.png",
        "name": "unicorn"
      },
      {
        "file": "valentines2022.png",
        "name": "valentines2022"
      },
      {
        "file": "valkyire.png",
        "name": "valkyire"
      },
      {
        "file": "vampire.png",
        "name": "vampire"
      },
      {
        "file": "viking.png",
        "name": "viking"
      },
      {
        "file": "voidEye.png",
        "name": "voidEye"
      },
      {
        "file": "watermelon.png",
        "name": "watermelon"
      },
      {
        "file": "whisperer.png",
        "name": "whisperer"
      },
      {
        "file": "wizard.png",
        "name": "wizard"
      },
      {
        "file": "X4PqpkR.png",
        "name": "X4PqpkR"
      },
      {
        "file": "zeus.webp",
        "name": "zeus"
      },
      {
        "file": "Zombie.png",
        "name": "Zombie"
      }
    ]
  },
  "ghostly-reaper": {
    "title": "Ghostly Reaper",
    "folder": "ghostly-reaper",
    "skins": [
      {
        "file": "angry.png",
        "name": "angry"
      },
      {
        "file": "astronaut.png",
        "name": "astronaut"
      },
      {
        "file": "chain.png",
        "name": "chain"
      },
      {
        "file": "coconut.png",
        "name": "coconut"
      },
      {
        "file": "crybaby.png",
        "name": "crybaby"
      },
      {
        "file": "cultist.png",
        "name": "cultist"
      },
      {
        "file": "cute.png",
        "name": "cute"
      },
      {
        "file": "cyborg.png",
        "name": "cyborg"
      },
      {
        "file": "demonic.png",
        "name": "demonic"
      },
      {
        "file": "dragon lord.png",
        "name": "dragon lord"
      },
      {
        "file": "fallen knight.png",
        "name": "fallen knight"
      },
      {
        "file": "king justice.png",
        "name": "king justice"
      },
      {
        "file": "kitty.png",
        "name": "kitty"
      },
      {
        "file": "ladybug.png",
        "name": "ladybug"
      },
      {
        "file": "laser.png",
        "name": "laser"
      },
      {
        "file": "leprechaun.png",
        "name": "leprechaun"
      },
      {
        "file": "mafioso.png",
        "name": "mafioso"
      },
      {
        "file": "mummy.png",
        "name": "mummy"
      },
      {
        "file": "nightmare.png",
        "name": "nightmare"
      },
      {
        "file": "pirate.png",
        "name": "pirate"
      },
      {
        "file": "policeman.png",
        "name": "policeman"
      },
      {
        "file": "samurai.png",
        "name": "samurai"
      },
      {
        "file": "shadow.png",
        "name": "shadow"
      },
      {
        "file": "soul divider.png",
        "name": "soul divider"
      },
      {
        "file": "standard.png",
        "name": "standard"
      }
    ]
  },
  "pumpkin-ghost": {
    "title": "Pumpkin Ghost",
    "folder": "pumpkin-ghost",
    "skins": [
      {
        "file": "anarchess.png",
        "name": "anarchess"
      },
      {
        "file": "bomb.png",
        "name": "bomb"
      },
      {
        "file": "chef.png",
        "name": "chef"
      },
      {
        "file": "cool.png",
        "name": "cool"
      },
      {
        "file": "cultist.png",
        "name": "cultist"
      },
      {
        "file": "cyborg.png",
        "name": "cyborg"
      },
      {
        "file": "darkmatter.png",
        "name": "darkmatter"
      },
      {
        "file": "demonic.png",
        "name": "demonic"
      },
      {
        "file": "dragon Lord.png",
        "name": "dragon Lord"
      },
      {
        "file": "fallen knigt.png",
        "name": "fallen knigt"
      },
      {
        "file": "farmer.png",
        "name": "farmer"
      },
      {
        "file": "frosty.png",
        "name": "frosty"
      },
      {
        "file": "ghostly.png",
        "name": "ghostly"
      },
      {
        "file": "headless.png",
        "name": "headless"
      },
      {
        "file": "hooded.png",
        "name": "hooded"
      },
      {
        "file": "jungle.png",
        "name": "jungle"
      },
      {
        "file": "knight.png",
        "name": "knight"
      },
      {
        "file": "laser.png",
        "name": "laser"
      },
      {
        "file": "leprechaun.png",
        "name": "leprechaun"
      },
      {
        "file": "mummy.png",
        "name": "mummy"
      },
      {
        "file": "nightmare.png",
        "name": "nightmare"
      },
      {
        "file": "ninja.png",
        "name": "ninja"
      },
      {
        "file": "owl.png",
        "name": "owl"
      },
      {
        "file": "pirate.png",
        "name": "pirate"
      },
      {
        "file": "pirate_2.png",
        "name": "pirate_2"
      },
      {
        "file": "policeman.png",
        "name": "policeman"
      },
      {
        "file": "rebellious.png",
        "name": "rebellious"
      },
      {
        "file": "robber.png",
        "name": "robber"
      },
      {
        "file": "samurai.png",
        "name": "samurai"
      },
      {
        "file": "split face.png",
        "name": "split face"
      },
      {
        "file": "standard.png",
        "name": "standard"
      },
      {
        "file": "waiter.png",
        "name": "waiter"
      }
    ]
  }
};
