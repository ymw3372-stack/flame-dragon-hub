const CACHE_NAME = "flame-dragon-hub-v3";
const FILES_TO_CACHE = [
  "./", "./index.html", "./welcome.html", "./evolutions.html", "./skins.html",
  "./favorites.html", "./guide.html", "./profile.html", "./settings.html", "./about.html",
  "./style.css", "./script.js", "./preferences.js", "./settings.js", "./favorites.js",
  "./skins-data.js", "./manifest.json", "./assets/logo.png"
];
self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(FILES_TO_CACHE)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", event => {
  if (event.request.method !== "GET" || new URL(event.request.url).origin !== self.location.origin) return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
    if (response && response.ok) { const copy = response.clone(); caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy)); }
    return response;
  }).catch(() => caches.match("./index.html"))));
});
