// FLAME DRAGON HUB: no in-page status badge is injected.
