FLAME DRAGON HUB — Chrome Extension test build (0.2.0)

Included: all skin image files bundled in FLAME DRAGON HUB V6 from grim-reaper, pumpkin-ghost, and ghostly-reaper, plus selectors for an original EvoWorld skin folder and a replacement skin.

INSTALL (Chrome):
1. Extract this ZIP to a normal folder.
2. Open chrome://extensions
3. Turn on Developer mode.
4. Click Load unpacked.
5. Select the extracted FLAME_DRAGON_HUB_Chrome_Extension folder (the one containing manifest.json).
6. Open EvoWorld, click the extension icon, select the evolution, choose the original skin folder to replace, choose the new skin, then apply. Reload the game to test.

IMPORTANT LIMITATIONS:
- This is an experimental local browser prototype, not published on Chrome Web Store.
- The redirect now matches only the selected original skin folder and evolution, rather than every skin in that evolution. It can still affect other visible players using that exact same original skin/evolution, because URL redirection cannot identify which sprite belongs to your own account. It does not change server-side identity.
- Skin folder names must exactly match EvoWorld's sprite CDN names. The website image filenames are used as initial guesses, so some choices may not exist on the CDN.
- This only redirects PNG frame URLs for the exact selected original skin folder that match the expected CDN pattern. It has not been verified against a live EvoWorld session. If the game's renderer uses a different CDN, asset format, or URL pattern, it will not work until adapted.
- Restore original sprites using the extension's button and reload EvoWorld.
