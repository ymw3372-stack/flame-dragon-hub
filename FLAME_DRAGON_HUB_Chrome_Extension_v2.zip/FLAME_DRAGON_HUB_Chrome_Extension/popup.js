const $ = id => document.getElementById(id);
let catalog = [];
function slugFromFilename(name) { return name.replace(/\.[^.]+$/, '').replace(/\s+([a-z])/g, (_, c) => c.toUpperCase()); }
function currentItems() {
  const seen = new Set();
  return catalog.filter(x => {
    if (x.evolution !== $('evolution').value || seen.has(x.slug)) return false;
    seen.add(x.slug); return true;
  });
}
function refreshSourceSkins(preferred) {
  const select = $('sourceSkin');
  const old = preferred || select.value;
  select.replaceChildren();
  const placeholder = document.createElement('option');
  placeholder.value = ''; placeholder.textContent = 'Choose the current skin…';
  select.appendChild(placeholder);
  for (const item of currentItems()) {
    const opt = document.createElement('option');
    opt.value = item.slug; opt.textContent = item.name;
    select.appendChild(opt);
  }
  if (old && [...select.options].some(o => o.value === old)) select.value = old;
}
function refreshSkins(preferred) {
  const items = currentItems();
  $('skin').replaceChildren();
  for (const item of items) {
    const opt = document.createElement('option');
    opt.value = item.slug; opt.textContent = item.name; opt.dataset.image = item.image;
    $('skin').appendChild(opt);
  }
  if (preferred && [...$('skin').options].some(o => o.value === preferred)) $('skin').value = preferred;
  if (![...$('skin').options].some(o => o.selected)) $('skin').selectedIndex = 0;
  showPreview();
}
function showPreview() {
  const opt = $('skin').selectedOptions[0];
  if (!opt) { $('preview').removeAttribute('src'); $('skinName').textContent = 'No skins found'; return; }
  $('preview').src = opt.dataset.image;
  $('skinName').textContent = `${opt.textContent} · ${opt.value}`;
}
function message(type, settings) {
  return new Promise(resolve => chrome.runtime.sendMessage({type, settings}, resolve));
}
$('evolution').addEventListener('change', () => { refreshSourceSkins(); refreshSkins(); });
$('skin').addEventListener('change', showPreview);
$('apply').addEventListener('click', async () => {
  if (!$('sourceSkin').value || !$('skin').value) { $('status').textContent = 'Choose the original skin and the replacement first.'; return; }
  const settings = { enabled: true, evolution: $('evolution').value, sourceSkin: $('sourceSkin').value, skin: $('skin').value };
  $('status').textContent = 'Applying…';
  const result = await message('FDH_APPLY', settings);
  $('status').textContent = result?.ok ? 'Enabled. Reload EvoWorld to test.' : `Could not apply: ${result?.error || 'unknown error'}`;
});
$('reset').addEventListener('click', async () => {
  $('status').textContent = 'Restoring original…';
  const result = await message('FDH_RESET');
  $('status').textContent = result?.ok ? 'Original sprite requests restored. Reload EvoWorld.' : `Could not reset: ${result?.error || 'unknown error'}`;
});
(async () => {
  try {
    const response = await fetch(chrome.runtime.getURL('skins.json'));
    catalog = await response.json();
    for (const item of catalog) item.image = chrome.runtime.getURL(item.image);
    const saved = (await chrome.storage.local.get('fdhSettings')).fdhSettings;
    if (saved?.evolution) $('evolution').value = saved.evolution;
    refreshSourceSkins(saved?.sourceSkin);
    refreshSkins(saved?.skin);
    $('status').textContent = `${catalog.length} skins loaded`;
  } catch (e) { $('status').textContent = 'Could not load skin catalog.'; }
})();
