const RULE_ID = 70101;
const EVOLUTIONS = new Set(["grimReaper", "pumpkinGhost", "ghostlyReaper"]);
function validSlug(s) { return typeof s === "string" && /^[A-Za-z0-9_-]{1,60}$/.test(s); }
async function applySettings(settings) {
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [RULE_ID], addRules: [] });
  if (!settings || !settings.enabled) return { enabled: false };
  const evolution = settings.evolution;
  const skin = settings.skin;
  const sourceSkin = settings.sourceSkin;
  if (!EVOLUTIONS.has(evolution) || !validSlug(skin) || !validSlug(sourceSkin)) throw new Error("Choose both the original skin and the replacement skin.");
  const rule = {
    id: RULE_ID,
    priority: 1,
    action: { type: "redirect", redirect: { regexSubstitution: `https://cdn.eu.evoworld.io/sprites/characters/${evolution}/${skin}/\\1/\\2.png` } },
    condition: {
      regexFilter: `^https://cdn\\.eu\\.evoworld\\.io/sprites/characters/${evolution}/${sourceSkin}/([^/]+)/([0-9]+)\\.png(?:\\?.*)?$`,
      resourceTypes: ["image"],
      requestDomains: ["cdn.eu.evoworld.io"]
    }
  };
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [], addRules: [rule] });
  return { enabled: true, evolution, sourceSkin, skin };
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "FDH_APPLY") {
    applySettings(message.settings).then(async result => {
      await chrome.storage.local.set({ fdhSettings: message.settings });
      sendResponse({ ok: true, result });
    }).catch(error => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === "FDH_RESET") {
    applySettings({ enabled: false }).then(async () => {
      const old = (await chrome.storage.local.get("fdhSettings")).fdhSettings || {};
      const settings = { ...old, enabled: false };
      await chrome.storage.local.set({ fdhSettings: settings });
      sendResponse({ ok: true });
    }).catch(error => sendResponse({ ok: false, error: error.message }));
    return true;
  }
});
chrome.runtime.onInstalled.addListener(async () => {
  const { fdhSettings } = await chrome.storage.local.get("fdhSettings");
  if (fdhSettings?.enabled) {
    try { await applySettings(fdhSettings); } catch (e) { console.warn("FDH rule not restored", e); }
  }
});
