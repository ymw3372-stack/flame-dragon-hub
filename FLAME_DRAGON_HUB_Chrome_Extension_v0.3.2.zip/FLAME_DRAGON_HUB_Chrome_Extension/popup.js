const $ = id => document.getElementById(id);
let catalog = [];
let evolution = "ghostlyReaper";
let selectedItem = null;
let customDraft = null;
let showCustomOnly = false;
let customSkins = [];
const evolutionLabel = {grimReaper:"Grim Reaper", pumpkinGhost:"Pumpkin Ghost", ghostlyReaper:"Ghostly Reaper"};
const keys = ["fdhSettings","fdhCustomSkins","fdhUiState"];

let currentLanguage = "en";
const translations = {
  en: {
    note: "<b>Important:</b> replacement targets one original skin folder and evolution. Other players using that same original sprite may also be affected. This extension cannot identify your player account.",
    previewEyebrow: "LIVE PREVIEW · HOVER OR SELECT", subtitle: "EvoWorld Skin Studio · v0.3.2",
    replacementHelp: "The selected original folder is the target. Sprite names must match EvoWorld's real CDN folder names. Reload EvoWorld after applying changes.",
    customHelp: "The uploaded image is previewed here. You can keep it locally or choose another image later.",
    customNotice: "Custom images can be previewed and stored locally. This version's network redirect only supports bundled library images; a custom upload is not yet a live in-game replacement.",
    sections: ["1 · Choose a skin collection","2 · Choose the original skin to replace","3 · Add Your Skin"],
    allSkins:"All skins", mySkins:"My custom skins", sourceLabel:"Original EvoWorld skin folder", replacementLabel:"Replacement skin from library",
    apply:"Apply replacement", reset:"Restore original sprites", addSkin:"Choose PNG, JPG, or WebP image", saveSkin:"Save custom skin",
    targetLabel:"ORIGINAL TARGET", replacementPreviewLabel:"WILL BE REPLACED WITH", search:"Search skins by name…"
  },
  ar: {
    note: "<b>مهم:</b> الاستبدال بيستهدف فولدر سكن أصلي وتطور محددين. ممكن يأثر على لاعبين تانيين بيستخدموا نفس الصورة الأصلية. الإضافة مش بتقدر تحدد حسابك داخل اللعبة.",
    previewEyebrow: "معاينة مباشرة · مرّر أو اختار", subtitle: "استوديو سكنات EvoWorld · v0.3.2",
    replacementHelp: "الفولدر الأصلي المحدد هو المستهدف. لازم أسماء الصور تطابق أسماء فولدرات EvoWorld الحقيقية. أعد تحميل اللعبة بعد تطبيق التغيير.",
    customHelp: "الصورة المرفوعة بتظهر هنا للمعاينة. تقدر تحفظها محليًا أو تختار صورة تانية بعدين.",
    customNotice: "تقدر تعاين الصور المخصصة وتحفظها محليًا. تحويل الشبكة في النسخة دي بيدعم صور المكتبة المرفقة فقط؛ الصورة المخصصة لسه مش استبدال مباشر داخل اللعبة.",
    sections: ["١ · اختار مجموعة السكنات","٢ · اختار السكن الأصلي اللي هتستبدله","٣ · أضف سكنك"],
    allSkins:"كل السكنات", mySkins:"سكناتي المخصصة", sourceLabel:"السكن الأصلي في EvoWorld", replacementLabel:"السكن البديل من المكتبة",
    apply:"تطبيق الاستبدال", reset:"استعادة الصور الأصلية", addSkin:"اختار صورة PNG أو JPG أو WebP", saveSkin:"حفظ السكن المخصص",
    targetLabel:"السكن الأصلي المستهدف", replacementPreviewLabel:"هيتبدل بالسكن ده", search:"ابحث عن سكن بالاسم…"
  },
  de: {
    note: "<b>Hinweis:</b> Ersetzt einen bestimmten Original-Skin-Ordner und eine Evolution. Andere Spieler mit demselben Sprite können ebenfalls betroffen sein.",
    previewEyebrow: "LIVE-VORSCHAU · HOVER ODER AUSWÄHLEN", subtitle: "EvoWorld Skin Studio · v0.3.2",
    replacementHelp: "Der ausgewählte Originalordner ist das Ziel. Nach dem Anwenden EvoWorld neu laden.",
    customHelp: "Das hochgeladene Bild wird hier angezeigt. Du kannst es lokal speichern oder später ein anderes wählen.",
    customNotice: "Eigene Bilder können angezeigt und lokal gespeichert werden. Die aktuelle Spielumleitung unterstützt nur mitgelieferte Bibliotheksbilder.",
    sections: ["1 · Skin-Sammlung wählen","2 · Zu ersetzenden Original-Skin wählen","3 · Eigenen Skin hinzufügen"],
    allSkins:"Alle Skins", mySkins:"Meine eigenen Skins", sourceLabel:"Original-Skin-Ordner", replacementLabel:"Ersatz-Skin aus der Bibliothek",
    apply:"Ersetzung anwenden", reset:"Originalbilder wiederherstellen", addSkin:"PNG-, JPG- oder WebP-Bild wählen", saveSkin:"Eigenen Skin speichern",
    targetLabel:"ORIGINAL-ZIEL", replacementPreviewLabel:"WIRD ERSETZT DURCH", search:"Skins nach Namen suchen…"
  },
  ru: {
    note: "<b>Важно:</b> заменяется выбранная папка оригинального скина и эволюция. Это может затронуть других игроков с тем же спрайтом.",
    previewEyebrow: "ПРЕДПРОСМОТР · НАВЕДИТЕ ИЛИ ВЫБЕРИТЕ", subtitle: "EvoWorld Skin Studio · v0.3.2",
    replacementHelp: "Выбранная папка оригинала будет заменена. После применения перезагрузите EvoWorld.",
    customHelp: "Загруженное изображение показывается здесь. Его можно сохранить локально или выбрать другое позже.",
    customNotice: "Пользовательские изображения можно просматривать и сохранять локально. Текущая замена в игре поддерживает только встроенные изображения библиотеки.",
    sections: ["1 · Выберите коллекцию скинов","2 · Выберите оригинальный скин для замены","3 · Добавить свой скин"],
    allSkins:"Все скины", mySkins:"Мои скины", sourceLabel:"Папка оригинального скина", replacementLabel:"Скин для замены из библиотеки",
    apply:"Применить замену", reset:"Восстановить оригиналы", addSkin:"Выбрать PNG, JPG или WebP", saveSkin:"Сохранить свой скин",
    targetLabel:"ОРИГИНАЛЬНАЯ ЦЕЛЬ", replacementPreviewLabel:"БУДЕТ ЗАМЕНЁН НА", search:"Поиск скина по имени…"
  },
  hi: {
    note: "<b>ध्यान दें:</b> चुने गए मूल स्किन फ़ोल्डर और इवोल्यूशन को बदला जाएगा। उसी स्प्राइट का उपयोग करने वाले अन्य खिलाड़ी भी प्रभावित हो सकते हैं।",
    previewEyebrow: "लाइव प्रीव्यू · होवर करें या चुनें", subtitle: "EvoWorld Skin Studio · v0.3.2",
    replacementHelp: "चुना गया मूल फ़ोल्डर लक्ष्य है। बदलाव लागू करने के बाद EvoWorld को फिर से लोड करें।",
    customHelp: "अपलोड की गई छवि यहाँ दिखाई देगी। आप इसे स्थानीय रूप से सहेज सकते हैं या बाद में दूसरी चुन सकते हैं।",
    customNotice: "कस्टम छवियों का प्रीव्यू और स्थानीय सेव संभव है। मौजूदा गेम रीडायरेक्ट केवल लाइब्रेरी में शामिल छवियों का समर्थन करता है।",
    sections: ["1 · स्किन संग्रह चुनें","2 · बदलने के लिए मूल स्किन चुनें","3 · अपनी स्किन जोड़ें"],
    allSkins:"सभी स्किन", mySkins:"मेरी कस्टम स्किन", sourceLabel:"मूल EvoWorld स्किन फ़ोल्डर", replacementLabel:"लाइब्रेरी से रिप्लेसमेंट स्किन",
    apply:"बदलाव लागू करें", reset:"मूल स्प्राइट वापस लाएँ", addSkin:"PNG, JPG या WebP छवि चुनें", saveSkin:"कस्टम स्किन सहेजें",
    targetLabel:"मूल लक्ष्य", replacementPreviewLabel:"इससे बदला जाएगा", search:"नाम से स्किन खोजें…"
  }
};
function setLanguage(lang) {
  currentLanguage = translations[lang] ? lang : "en";
  const t = translations[currentLanguage];
  document.documentElement.lang = currentLanguage;
  document.body.classList.toggle("rtl", currentLanguage === "ar");
  document.querySelectorAll("[data-en][data-ar]").forEach(el => {
    el.textContent = currentLanguage === "ar" ? el.dataset.ar : el.dataset.en;
  });
  $("search").placeholder = t.search;
  $("search").setAttribute("aria-label", t.search);
  $("note").innerHTML = t.note;
  $("previewEyebrow").textContent = t.previewEyebrow;
  $("subtitle").textContent = t.subtitle;
  $("replacementHelp").textContent = t.replacementHelp;
  $("customHelp").textContent = t.customHelp;
  $("customNotice").textContent = t.customNotice;
  const sections = document.querySelectorAll(".section-title");
  t.sections.forEach((s,i)=>{if(sections[i])sections[i].textContent=s;});
  $("showAll").textContent=t.allSkins;
  $("showCustom").textContent=t.mySkins;
  document.querySelector('label[for="sourceSkin"]').textContent=t.sourceLabel;
  document.querySelector('label[for="replacement"]').textContent=t.replacementLabel;
  document.querySelector('label[for="customFile"]').textContent=t.addSkin;
  $("apply").textContent=t.apply;
  $("reset").textContent=t.reset;
  $("saveCustom").textContent=t.saveSkin;
  $("targetPreviewLabel").textContent=t.targetLabel;
  $("replacementPreviewLabel").textContent=t.replacementPreviewLabel;
  ["langEn","langAr","langDe","langRu","langHi"].forEach(id=>$(id).classList.toggle("active",id.toLowerCase().endsWith(currentLanguage)));
  chrome.storage.local.set({fdhLanguage:currentLanguage});
}
$("langEn").addEventListener("click",()=>setLanguage("en"));
$("langAr").addEventListener("click",()=>setLanguage("ar"));
$("langDe").addEventListener("click",()=>setLanguage("de"));
$("langRu").addEventListener("click",()=>setLanguage("ru"));
$("langHi").addEventListener("click",()=>setLanguage("hi"));

function itemsForCurrent() {
  return catalog.filter(x => x.evolution === evolution);
}
function uniqueBySlug(items) {
  const seen = new Set();
  return items.filter(x => {
    if (!x.slug || seen.has(x.slug)) return false;
    seen.add(x.slug); return true;
  });
}
function setStatus(s) { $("status").textContent = s; }
function itemImage(item) {
  if (item?.dataUrl) return item.dataUrl;
  if (item?.image && item.image.startsWith("data:")) return item.image;
  return item?.image ? chrome.runtime.getURL(item.image) : "";
}
function updateReplacementPreview() {
  const sourceSlug = $("sourceSkin")?.value || "";
  const replaceSlug = $("replacement")?.value || "";
  const sourceItem = catalog.find(x => x.slug === sourceSlug && x.evolution === evolution);
  const replacementItem = catalog.find(x => x.slug === replaceSlug && x.evolution === evolution);
  const sourceImg = $("targetPreviewImage");
  const replacementImg = $("replacementPreviewImage");
  sourceImg.src = sourceItem ? itemImage(sourceItem) : "";
  replacementImg.src = replacementItem ? itemImage(replacementItem) : "";
  $("targetPreviewName").textContent = sourceItem ? sourceItem.name : (currentLanguage==="ar" ? "اختار السكن الأصلي" : "Choose original skin");
  $("replacementPreviewName").textContent = replacementItem ? replacementItem.name : (currentLanguage==="ar" ? "اختار السكن البديل" : "Choose replacement skin");
}
function setPreview(item, kind="Library skin") {
  if (!item) {
    $("preview").removeAttribute("src");
    $("skinName").textContent = "No skin selected";
    $("skinInfo").textContent = "Choose a skin tile below.";
    return;
  }
  const src = itemImage(item);
  if (src) $("preview").src = src; else $("preview").removeAttribute("src");
  $("skinName").textContent = item.name || "Unnamed skin";
  $("skinInfo").textContent = `${kind} · ${item.evolution ? evolutionLabel[item.evolution] || item.evolution : "Custom"}`;
}
function fillSourceSkins(preferred) {
  const select = $("sourceSkin");
  const old = preferred || select.value;
  select.replaceChildren();
  const placeholder = new Option("Choose the original skin…", "");
  select.add(placeholder);
  const list = uniqueBySlug(itemsForCurrent()).sort((a,b)=>a.name.localeCompare(b.name));
  for (const item of list) select.add(new Option(item.name, item.slug));
  if (old && [...select.options].some(o=>o.value===old)) select.value=old;
}
function fillReplacementSelect(preferred) {
  const select=$("replacement"), old=preferred || select.value;
  select.replaceChildren();
  const list=uniqueBySlug(itemsForCurrent()).sort((a,b)=>a.name.localeCompare(b.name));
  select.add(new Option("Choose a replacement…",""));
  for (const item of list) select.add(new Option(item.name,item.slug));
  if (old && [...select.options].some(o=>o.value===old)) select.value=old;
  if (!select.value && list.length) select.value=list[0].slug;
}
function renderGrid() {
  const grid=$("skinGrid"), query=$("search").value.trim().toLowerCase();
  grid.replaceChildren();
  const items=(showCustomOnly ? customSkins.map((x,i)=>({...x,_customIndex:i,_custom:true})) : itemsForCurrent())
    .filter(x => (x.name||"").toLowerCase().includes(query) || (x.slug||"").toLowerCase().includes(query))
    .sort((a,b)=>(a.name||"").localeCompare(b.name||""));
  for (const item of items) {
    const btn=document.createElement("button");
    btn.type="button";
    btn.className="tile"+(selectedItem && selectedItem.id===item.id && selectedItem._custom===item._custom ? " selected":"");
    btn.title=item.name || item.slug;
    const img=document.createElement("img"); img.alt=""; img.loading="lazy"; img.src=itemImage(item);
    img.addEventListener("error",()=>{img.style.opacity=".25";});
    const label=document.createElement("span"); label.textContent=item.name || item.slug || "Custom skin";
    btn.append(img,label);
    btn.addEventListener("mouseenter",()=>setPreview(item,item._custom?"Custom skin":"Library skin"));
    btn.addEventListener("focus",()=>setPreview(item,item._custom?"Custom skin":"Library skin"));
    btn.addEventListener("mouseleave",()=>{ if(selectedItem) setPreview(selectedItem,selectedItem._custom?"Custom skin":"Library skin"); });
    btn.addEventListener("click",()=>{
      selectedItem=item;
      setPreview(item,item._custom?"Custom skin":"Library skin");
      renderGrid();
      if (!item._custom && item.evolution===evolution && [...$("replacement").options].some(o=>o.value===item.slug)) $("replacement").value=item.slug;
      saveUiState();
    });
    grid.append(btn);
  }
  $("count").textContent = `${items.length} ${showCustomOnly?"custom skins":"skins shown"} · ${showCustomOnly?"saved locally":evolutionLabel[evolution]}`;
  if (!items.length) {
    const empty=document.createElement("div"); empty.className="small"; empty.textContent="No matching skins. Try another search or collection."; grid.append(empty);
  }
}
async function saveUiState() {
  await chrome.storage.local.set({fdhUiState:{evolution,showCustomOnly,selectedId:selectedItem?.id || null,selectedCustom:!!selectedItem?._custom}});
}
function message(type, settings) {
  return new Promise(resolve => chrome.runtime.sendMessage({type, settings}, response => {
    if (chrome.runtime.lastError) resolve({ok:false,error:chrome.runtime.lastError.message});
    else resolve(response || {ok:false,error:"No response from extension background."});
  }));
}
function switchEvolution(next) {
  evolution=next; showCustomOnly=false;
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.evolution===evolution));
  fillSourceSkins(); fillReplacementSelect();
  const first=itemsForCurrent()[0] || null;
  selectedItem=first;
  setPreview(first);
  renderGrid(); updateReplacementPreview(); saveUiState();
}
function renderCustomList() {
  const root=$("customList"); root.replaceChildren();
  if (!customSkins.length) { const p=document.createElement("p");p.className="small";p.textContent="No saved custom skins yet.";root.append(p);return; }
  customSkins.forEach((item,index)=>{
    const row=document.createElement("div");row.className="bundle-preview";
    const img=document.createElement("img");img.src=item.dataUrl;img.alt="";
    const info=document.createElement("div");
    const title=document.createElement("div");title.className="skin-title";title.textContent=item.name;
    const del=document.createElement("button");del.className="btn danger";del.textContent="Delete";del.style.marginTop="4px";
    del.addEventListener("click",async()=>{customSkins.splice(index,1);await chrome.storage.local.set({fdhCustomSkins:customSkins});if(selectedItem?._custom)selectedItem=null;renderCustomList();renderGrid();setStatus("Custom skin deleted from local storage.");});
    info.append(title,del);row.append(img,info);root.append(row);
  });
}
$("customFile").addEventListener("change",()=>{
  const file=$("customFile").files?.[0]; if(!file){customDraft=null;$("saveCustom").disabled=true;return;}
  if(!/^image\/(png|jpeg|webp)$/.test(file.type)){setStatus("Please choose a PNG, JPG, or WebP image.");return;}
  if(file.size>5*1024*1024){setStatus("Image is too large. Choose an image under 5 MB.");return;}
  const reader=new FileReader();
  reader.onload=async()=>{
    customDraft={name:file.name.replace(/\.[^.]+$/,""),dataUrl:reader.result,type:file.type};
    $("customPreview").src=reader.result;
    $("customName").textContent=customDraft.name;
    $("replacementPreviewImage").src=reader.result;
    $("replacementPreviewName").textContent=customDraft.name + (currentLanguage==="ar" ? " (مخصص)" : " (custom)");
    $("saveCustom").disabled=false;
    setPreview({...customDraft,id:"upload-preview",_custom:true},"Custom upload preview");
    try {
      const existing=customSkins.findIndex(x=>x.name===customDraft.name && x.type===customDraft.type);
      const saved={id:existing>=0?customSkins[existing].id:("custom-"+Date.now()+"-"+Math.random().toString(36).slice(2,7)),...customDraft,createdAt:Date.now()};
      if(existing>=0) customSkins[existing]=saved; else customSkins.push(saved);
      await chrome.storage.local.set({fdhCustomSkins:customSkins});
      selectedItem={...saved,_custom:true};
      renderCustomList(); renderGrid(); saveUiState();
      setStatus("Custom image previewed and saved locally automatically. It will remain available next time.");
    } catch(e) { setStatus("Image preview works, but automatic local saving failed. Try Save custom skin."); }
  };
  reader.onerror=()=>setStatus("Could not read this image.");
  reader.readAsDataURL(file);
});
$("saveCustom").addEventListener("click",async()=>{
  if(!customDraft)return;
  const id="custom-"+Date.now()+"-"+Math.random().toString(36).slice(2,7);
  const existing=customSkins.findIndex(x=>x.name===customDraft.name && x.type===customDraft.type);
  const saved={id,name:customDraft.name,dataUrl:customDraft.dataUrl,type:customDraft.type,createdAt:Date.now()};
  if(existing>=0) customSkins[existing]=saved; else customSkins.push(saved);
  try{await chrome.storage.local.set({fdhCustomSkins:customSkins});selectedItem={...saved,_custom:true};renderCustomList();renderGrid();setPreview(selectedItem,"Custom skin");setStatus("Custom skin saved locally and ready to preview.");$("saveCustom").disabled=true;customDraft=null;}
  catch(e){setStatus("Could not save custom skin. Browser storage may be full.");}
});
$("search").addEventListener("input",renderGrid);
$("showAll").addEventListener("click",()=>{showCustomOnly=false;renderGrid();});
$("showCustom").addEventListener("click",()=>{showCustomOnly=true;renderGrid();});
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>switchEvolution(b.dataset.evolution)));
$("sourceSkin").addEventListener("change",()=>{updateReplacementPreview();saveUiState();});
$("replacement").addEventListener("change",()=>{
  const item=itemsForCurrent().find(x=>x.slug===$("replacement").value);
  if(item){selectedItem=item;setPreview(item);renderGrid();}
  updateReplacementPreview();
});
$("apply").addEventListener("click",async()=>{
  if(selectedItem?._custom || (showCustomOnly && selectedItem?.dataUrl)) {
    setStatus("Custom image is saved and previewable, but this extension's current game redirect only supports bundled library skins. Choose a bundled skin for in-game replacement.");
    return;
  }
  if(!$("sourceSkin").value||!$("replacement").value){setStatus("Choose both the original skin and a replacement first.");return;}
  const settings={enabled:true,evolution,sourceSkin:$("sourceSkin").value,skin:$("replacement").value};
  setStatus("Applying replacement rule…");
  const result=await message("FDH_APPLY",settings);
  setStatus(result?.ok?`Replacement enabled for ${settings.sourceSkin}. Reload EvoWorld to test.`:`Could not apply: ${result?.error||"unknown error"}`);
});
$("reset").addEventListener("click",async()=>{
  setStatus("Restoring original sprites…");
  const result=await message("FDH_RESET");
  setStatus(result?.ok?"Original sprite requests restored. Reload EvoWorld.":`Could not reset: ${result?.error||"unknown error"}`);
});
(async()=>{
  try{
    const response=await fetch(chrome.runtime.getURL("skins.json"));
    if(!response.ok)throw new Error("Skin catalog file not found.");
    catalog=await response.json();
    if(!Array.isArray(catalog))throw new Error("Skin catalog format is invalid.");
    catalog=catalog.filter(x=>x && x.slug && x.evolution && x.image);
    const stored=await chrome.storage.local.get(keys);
    customSkins=Array.isArray(stored.fdhCustomSkins)?stored.fdhCustomSkins:[];
    renderCustomList();
    const ui=stored.fdhUiState||{};
    const settings=stored.fdhSettings||{};
    setLanguage(stored.fdhLanguage === "ar" ? "ar" : "en");
    evolution=ui.evolution||settings.evolution||"ghostlyReaper";
    if(!evolutionLabel[evolution])evolution="ghostlyReaper";
    document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.evolution===evolution));
    showCustomOnly=!!ui.showCustomOnly;
    fillSourceSkins(settings.sourceSkin);
    fillReplacementSelect(settings.skin);
    let selected=catalog.find(x=>x.id===ui.selectedId);
    if(ui.selectedCustom){const found=customSkins.find(x=>x.id===ui.selectedId);if(found)selected={...found,_custom:true};}
    selectedItem=selected||itemsForCurrent()[0]||null;
    if(selectedItem)setPreview(selectedItem,selectedItem.dataUrl?"Custom skin":"Library skin");
    renderGrid();
    updateReplacementPreview();
    setStatus(`${catalog.length} bundled skin files loaded.`);
  }catch(e){setStatus(`Could not load skin catalog: ${e.message}`);$("skinName").textContent="Skin library unavailable";}
})();
