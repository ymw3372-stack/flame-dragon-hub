FLAME DRAGON HUB — Chrome Extension v0.3.2

This package preserves the existing 184 bundled skin image files and the current Manifest V3 sprite-redirect mechanism.

INSTALL / UPDATE IN CHROME
1. Extract this ZIP completely to a normal folder.
2. Open chrome://extensions in Chrome.
3. Turn on Developer mode.
4. If an older FLAME DRAGON HUB unpacked extension is loaded, note its folder first. Do not delete your backup.
5. Click Load unpacked and select the extracted FLAME_DRAGON_HUB_Chrome_Extension folder (the folder containing manifest.json).
6. Open the extension popup and test the tabs, search, previews, target selection, and restore button.
7. Open EvoWorld and test only after selecting a real original sprite folder and replacement skin.

ABOUT WEBSITE VS EXTENSION
GitHub Pages is the website. Updating its HTML does not automatically update a locally loaded Chrome extension. A downloadable extension ZIP must be published separately and the website download link must point to that ZIP.

IMPORTANT FUNCTIONAL LIMITS
- This package includes 184 catalog records/image files: Grim Reaper 127, Pumpkin Ghost 32, Ghostly Reaper 25.
- The current redirect rule targets a single original skin folder and evolution. It may also affect other players requesting that exact sprite URL, because URL redirection cannot identify the user's account/player.
- Sprite folder names must match real EvoWorld CDN names. The catalog names are not guaranteed to match all live CDN folders.
- Redirect behavior has not been verified against a live EvoWorld session. It only handles matching PNG frame URLs on cdn.eu.evoworld.io in the expected path format.
- Add Your Skin stores and previews an uploaded image locally in Chrome storage. The current redirect mechanism cannot redirect EvoWorld requests to a data URL stored in Chrome storage; custom uploads are therefore NOT applied in-game by this build.
- Skin Studio Bundle JSON can be previewed and stored locally. Importing a bundle does not itself change game sprites.
- This is an experimental local extension package, not a Chrome Web Store listing.

TEST BEFORE REPLACING A PUBLIC DOWNLOAD
Verify all three collection tabs and counts, search, hover/selected preview, local custom-image persistence, JSON bundle import/clear, applying a known valid original target, restoring originals, and the actual sprite URL behavior in EvoWorld. Do not describe custom skin replacement as game-working until a compatible mechanism is implemented and tested.


Version 0.3.2 notes:
- Added English/Arabic interface toggle.
- Removed Skin Studio Bundle import UI as requested.
- Custom image upload now previews and auto-saves locally for later use.
- Custom uploads are not claimed as in-game replacements; live replacement currently supports bundled library images only.


Version 0.3.2 notes:
- Added English, Arabic, German, Russian, and Hindi language controls.
- Added side-by-side preview of the selected original target and bundled replacement skin.
- Uploaded custom image is shown in the replacement preview for inspection.
- Important: current declarativeNetRequest redirect still only redirects to bundled CDN skin paths; uploaded custom images are not yet live in-game replacements.
