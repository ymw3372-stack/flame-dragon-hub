// Publishes custom skin mappings. Grim Reaper gets the built-in Purple Grim Reaper frame sequence automatically.
const FDH_REAPER_FRAMES = {
  attack: [
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/attack/1.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/attack/2.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/attack/3.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/attack/4.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/attack/5.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/attack/6.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/attack/7.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/attack/8.png',
  ],
  flying: [
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/flying/1.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/flying/2.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/flying/3.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/flying/4.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/flying/5.png',
  ],
  idle: [
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/idle/1.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/idle/2.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/idle/3.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/idle/4.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/idle/5.png',
    'https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/idle/6.png',
  ]
};
async function publishCustomMappings() {
  try {
    const stored = await chrome.storage.local.get(["fdhMappings", "fdhCustomSkins"]);
    const mappings = Array.isArray(stored.fdhMappings) ? stored.fdhMappings : [];
    const customSkins = Array.isArray(stored.fdhCustomSkins) ? stored.fdhCustomSkins : [];
    const custom = mappings.filter(m => m.customId).map(m => {
      const skin = customSkins.find(x => x.id === m.customId);
      if (!skin?.dataUrl) return null;
      // Do not affect Pumpkin Ghost or Ghostly Reaper: those frame sets will be added separately.
      const frames = m.evolution === "grimReaper" ? FDH_REAPER_FRAMES : (skin.frames && typeof skin.frames === "object" ? skin.frames : {});
      return { evolution: m.evolution, sourceSkin: m.sourceSkin, dataUrl: skin.dataUrl, frames };
    }).filter(Boolean);
    window.postMessage({ type: "FDH_CUSTOM_SKIN_MAPPINGS", mappings: custom }, "*");
  } catch (e) { console.warn("FLAME DRAGON HUB: could not load custom mappings", e); }
}
publishCustomMappings();
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.fdhMappings || changes.fdhCustomSkins)) publishCustomMappings();
});
