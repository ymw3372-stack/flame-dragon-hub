const $ = id => document.getElementById(id);
let catalog = [];
let evolution = "ghostlyReaper";
let selectedItem = null;
let customDraft = null;
let showCustomOnly = false;
let customSkins = [];
let activeMappings = [];
const evolutionLabel = {grimReaper:"Grim Reaper", pumpkinGhost:"Pumpkin Ghost", ghostlyReaper:"Ghostly Reaper"};
const keys = ["fdhSettings","fdhMappings","fdhCustomSkins","fdhUiState"];

let currentLanguage = "en";
const translations = {
  en: {
    note: "<b>Important:</b> each mapping targets one original skin folder and evolution. Other players using that same original sprite may also be affected. This extension cannot identify your player account.",
    previewEyebrow: "LIVE PREVIEW · HOVER OR SELECT", subtitle: "EvoWorld Skin Studio · v0.5.0",
    replacementHelp: "The selected original folder is the target. Sprite names must match EvoWorld's real CDN folder names. Reload EvoWorld after applying changes.",
    customHelp: "Upload one image. Grim Reaper animation frames are loaded automatically; Pumpkin Ghost and Ghostly Reaper are unchanged.",
    customNotice: "Grim Reaper animation frames load automatically. The linked frames are original Purple Grim Reaper artwork, not generated poses for your uploaded image.",
    sections: ["1 · Choose a skin collection","2 · Choose the original skin to replace","3 · Active Skins","4 · Add Your Skin"],
    allSkins:"All skins", mySkins:"My custom skins", sourceLabel:"Original EvoWorld skin folder", replacementLabel:"Replacement skin from library",
    apply:"Apply replacement", reset:"Restore original sprites", addSkin:"Choose PNG, JPG, WebP, or animated GIF", saveSkin:"Save custom skin",
    targetLabel:"ORIGINAL TARGET", replacementPreviewLabel:"WILL BE REPLACED WITH", search:"Search skins by name…"
  },
  ar: {
    note: "<b>مهم:</b> كل تحويل بيستهدف فولدر سكن أصلي وتطور محددين. ممكن يأثر على لاعبين تانيين بيستخدموا نفس الصورة الأصلية. الإضافة مش بتقدر تحدد حسابك داخل اللعبة.",
    previewEyebrow: "معاينة مباشرة · مرّر أو اختار", subtitle: "استوديو سكنات EvoWorld · v0.5.0",
    replacementHelp: "الفولدر الأصلي المحدد هو المستهدف. لازم أسماء الصور تطابق أسماء فولدرات EvoWorld الحقيقية. أعد تحميل اللعبة بعد تطبيق التغيير.",
    customHelp: "اختار صورتك مرة واحدة. إطارات حركة Grim Reaper بتتحمل تلقائيًا؛ باقي التطورات بدون تغيير.",
    customNotice: "إطارات Grim Reaper بتتحمل تلقائيًا. الإطارات دي صور Purple Grim Reaper الأصلية، ومش بتتحول تلقائيًا لشكل صورتك.",
    sections: ["١ · اختار مجموعة السكنات","٢ · اختار السكن الأصلي اللي هتستبدله","٣ · السكنات المفعّلة","٤ · أضف سكنك"],
    allSkins:"كل السكنات", mySkins:"سكناتي المخصصة", sourceLabel:"السكن الأصلي في EvoWorld", replacementLabel:"السكن البديل من المكتبة",
    apply:"تطبيق الاستبدال", reset:"استعادة الصور الأصلية", addSkin:"اختار صورة PNG أو JPG أو WebP أو GIF متحرك", saveSkin:"حفظ السكن المخصص",
    targetLabel:"السكن الأصلي المستهدف", replacementPreviewLabel:"هيتبدل بالسكن ده", search:"ابحث عن سكن بالاسم…"
  },
  de: {
    note: "<b>Hinweis:</b> Ersetzt einen bestimmten Original-Skin-Ordner und eine Evolution. Andere Spieler mit demselben Sprite können ebenfalls betroffen sein.",
    previewEyebrow: "LIVE-VORSCHAU · HOVER ODER AUSWÄHLEN", subtitle: "EvoWorld Skin Studio · v0.5.0",
    replacementHelp: "Der ausgewählte Originalordner ist das Ziel. Nach dem Anwenden EvoWorld neu laden.",
    customHelp: "Das hochgeladene Bild wird hier angezeigt. Du kannst es lokal speichern oder später ein anderes wählen.",
    customNotice: "Für Bewegung ein animiertes GIF hochladen. Ein einzelnes Standbild kann nicht von selbst animiert werden.",
    sections: ["1 · Skin-Sammlung wählen","2 · Zu ersetzenden Original-Skin wählen","3 · Aktive Skins","4 · Eigenen Skin hinzufügen"],
    allSkins:"Alle Skins", mySkins:"Meine eigenen Skins", sourceLabel:"Original-Skin-Ordner", replacementLabel:"Ersatz-Skin aus der Bibliothek",
    apply:"Ersetzung anwenden", reset:"Originalbilder wiederherstellen", addSkin:"PNG-, JPG- oder WebP-Bild wählen", saveSkin:"Eigenen Skin speichern",
    targetLabel:"ORIGINAL-ZIEL", replacementPreviewLabel:"WIRD ERSETZT DURCH", search:"Skins nach Namen suchen…"
  },
  ru: {
    note: "<b>Важно:</b> заменяется выбранная папка оригинального скина и эволюция. Это может затронуть других игроков с тем же спрайтом.",
    previewEyebrow: "ПРЕДПРОСМОТР · НАВЕДИТЕ ИЛИ ВЫБЕРИТЕ", subtitle: "EvoWorld Skin Studio · v0.5.0",
    replacementHelp: "Выбранная папка оригинала будет заменена. После применения перезагрузите EvoWorld.",
    customHelp: "Загруженное изображение показывается здесь. Его можно сохранить локально или выбрать другое позже.",
    customNotice: "Сохраните изображение, нажмите Use, выберите оригинальный скин и примените. Это первая версия; кадры анимации могут показывать одно статичное изображение.",
    sections: ["1 · Выберите коллекцию скинов","2 · Выберите оригинальный скин для замены","3 · Активные скины","4 · Добавить свой скин"],
    allSkins:"Все скины", mySkins:"Мои скины", sourceLabel:"Папка оригинального скина", replacementLabel:"Скин для замены из библиотеки",
    apply:"Применить замену", reset:"Восстановить оригиналы", addSkin:"Выбрать PNG, JPG или WebP", saveSkin:"Сохранить свой скин",
    targetLabel:"ОРИГИНАЛЬНАЯ ЦЕЛЬ", replacementPreviewLabel:"БУДЕТ ЗАМЕНЁН НА", search:"Поиск скина по имени…"
  },
  hi: {
    note: "<b>ध्यान दें:</b> चुने गए मूल स्किन फ़ोल्डर और इवोल्यूशन को बदला जाएगा। उसी स्प्राइट का उपयोग करने वाले अन्य खिलाड़ी भी प्रभावित हो सकते हैं।",
    previewEyebrow: "लाइव प्रीव्यू · होवर करें या चुनें", subtitle: "EvoWorld Skin Studio · v0.5.0",
    replacementHelp: "चुना गया मूल फ़ोल्डर लक्ष्य है। बदलाव लागू करने के बाद EvoWorld को फिर से लोड करें।",
    customHelp: "अपलोड की गई छवि यहाँ दिखाई देगी। आप इसे स्थानीय रूप से सहेज सकते हैं या बाद में दूसरी चुन सकते हैं।",
    customNotice: "कस्टम छवियों का प्रीव्यू और स्थानीय सेव संभव है। मौजूदा गेम रीडायरेक्ट केवल लाइब्रेरी में शामिल छवियों का समर्थन करता है।",
    sections: ["1 · स्किन संग्रह चुनें","2 · बदलने के लिए मूल स्किन चुनें","3 · सक्रिय स्किन","4 · अपनी स्किन जोड़ें"],
    allSkins:"सभी स्किन", mySkins:"मेरी कस्टम स्किन", sourceLabel:"मूल EvoWorld स्किन फ़ोल्डर", replacementLabel:"लाइब्रेरी से रिप्लेसमेंट स्किन",
    apply:"बदलाव लागू करें", reset:"मूल स्प्राइट वापस लाएँ", addSkin:"PNG, JPG या WebP छवि चुनें", saveSkin:"कस्टम स्किन सहेजें",
    targetLabel:"मूल लक्ष्य", replacementPreviewLabel:"इससे बदला जाएगा", search:"नाम से स्किन खोजें…"
  }
};
function setLanguage(lang) {
  currentLanguage = translations[lang] ? lang : "en";
  const t = translations[currentLanguage];
  document.documentElement.lang = currentLanguage;
  document.body.classList.toggle("rtl", currentLanguage === "ar");
  document.querySelectorAll("[data-en][data-ar]").forEach(el => {
    el.textContent = currentLanguage === "ar" ? el.dataset.ar : el.dataset.en;
  });
  $("search").placeholder = t.search;
  const customNameInput=$("customNameInput"); if(customNameInput) customNameInput.placeholder=currentLanguage==="ar"?"اسم السكن المخصص":"My custom skin";
  $("search").setAttribute("aria-label", t.search);
  $("note").innerHTML = t.note;
  if ($("previewEyebrow")) $("previewEyebrow").textContent = t.previewEyebrow;
  $("subtitle").textContent = t.subtitle;
  $("replacementHelp").textContent = t.replacementHelp;
  $("customHelp").textContent = t.customHelp;
  $("customNotice").textContent = t.customNotice;
  const sections = document.querySelectorAll(".section-title");
  t.sections.forEach((s,i)=>{if(sections[i])sections[i].textContent=s;});
  $("showAll").textContent=t.allSkins;
  $("showCustom").textContent=t.mySkins;
  document.querySelector('label[for="sourceSkin"]').textContent=t.sourceLabel;
  document.querySelector('label[for="replacement"]').textContent=t.replacementLabel;
  document.querySelector('label[for="customFile"]').textContent=t.addSkin;
  $("apply").textContent=currentLanguage==="ar" ? "＋ إضافة / تحديث السكن المفعّل" : (currentLanguage==="de" ? "＋ Aktiven Skin hinzufügen / ändern" : currentLanguage==="ru" ? "＋ Добавить / обновить активный скин" : currentLanguage==="hi" ? "＋ सक्रिय स्किन जोड़ें / обновить" : "＋ Add / Update Active Skin");
  $("reset").textContent=t.reset;
  $("saveCustom").textContent=t.saveSkin;
  $("targetPreviewLabel").textContent=t.targetLabel;
  $("replacementPreviewLabel").textContent=t.replacementPreviewLabel;
  ["langEn","langAr","langDe","langRu","langHi"].forEach(id=>$(id).classList.toggle("active",id.toLowerCase().endsWith(currentLanguage)));
  chrome.storage.local.set({fdhLanguage:currentLanguage});
}
$("langEn").addEventListener("click",()=>setLanguage("en"));
$("langAr").addEventListener("click",()=>setLanguage("ar"));
$("langDe").addEventListener("click",()=>setLanguage("de"));
$("langRu").addEventListener("click",()=>setLanguage("ru"));
$("langHi").addEventListener("click",()=>setLanguage("hi"));

function itemsForCurrent() {
  return catalog.filter(x => x.evolution === evolution);
}
function uniqueBySlug(items) {
  const seen = new Set();
  return items.filter(x => {
    if (!x.slug || seen.has(x.slug)) return false;
    seen.add(x.slug); return true;
  });
}
function setStatus(s) { $("status").textContent = s; }
function itemImage(item) {
  if (item?.dataUrl) return item.dataUrl;
  if (item?.image && item.image.startsWith("data:")) return item.image;
  return item?.image ? chrome.runtime.getURL(item.image) : "";
}
function updateReplacementPreview() {
  const sourceSlug = $("sourceSkin")?.value || "";
  const replaceSlug = $("replacement")?.value || "";
  const sourceItem = catalog.find(x => x.slug === sourceSlug && x.evolution === evolution);
  const customId = replaceSlug.startsWith("custom:") ? replaceSlug.slice(7) : "";
  const customItem = customId ? customSkins.find(x => x.id === customId) : null;
  const replacementItem = customItem || catalog.find(x => x.slug === replaceSlug && x.evolution === evolution);
  const sourceImg = $("targetPreviewImage");
  const replacementImg = $("replacementPreviewImage");
  sourceImg.src = sourceItem ? itemImage(sourceItem) : "";
  replacementImg.src = replacementItem ? itemImage(replacementItem) : "";
  $("targetPreviewName").textContent = sourceItem ? sourceItem.name : (currentLanguage==="ar" ? "اختار السكن الأصلي" : "Choose original skin");
  $("replacementPreviewName").textContent = replacementItem ? replacementItem.name + (customItem ? (currentLanguage==="ar" ? " (مخصص)" : " (custom)") : "") : (currentLanguage==="ar" ? "اختار السكن البديل" : "Choose replacement skin");
}
function setPreview(item, kind="Library skin") {
  if (!item) return;
  // The selected tile is now the visual preview; avoid the old oversized duplicate preview.
}
function fillSourceSkins(preferred) {
  const select = $("sourceSkin");
  const old = preferred || select.value;
  select.replaceChildren();
  const placeholder = new Option("Choose the original skin…", "");
  select.add(placeholder);
  const list = uniqueBySlug(itemsForCurrent()).sort((a,b)=>a.name.localeCompare(b.name));
  for (const item of list) select.add(new Option(item.name, item.slug));
  if (old && [...select.options].some(o=>o.value===old)) select.value=old;
}
function fillReplacementSelect(preferred) {
  const select=$("replacement"), old=preferred || select.value;
  select.replaceChildren();
  const list=uniqueBySlug(itemsForCurrent()).sort((a,b)=>a.name.localeCompare(b.name));
  select.add(new Option("Choose a replacement…",""));
  for (const item of list) select.add(new Option(item.name,item.slug));
  if (old && [...select.options].some(o=>o.value===old)) select.value=old;
  if (!select.value && list.length) select.value=list[0].slug;
}
function renderGrid() {
  const grid=$("skinGrid"), query=$("search").value.trim().toLowerCase();
  grid.replaceChildren();
  // Keep the gallery in one-to-one sync with the replacement dropdown.
  // Some skins ship as both PNG and WebP with the same folder slug; showing
  // both made the tile preview differ from the actual selected replacement.
  const baseItems = uniqueBySlug(itemsForCurrent());
  const items=baseItems
    .filter(x => (x.name||"").toLowerCase().includes(query) || (x.slug||"").toLowerCase().includes(query))
    .sort((a,b)=>(a.name||"").localeCompare(b.name||""));
  for (const item of items) {
    const btn=document.createElement("button");
    btn.type="button";
    btn.className="tile"+(selectedItem && selectedItem.id===item.id && selectedItem._custom===item._custom ? " selected":"");
    btn.title=item.name || item.slug;
    const img=document.createElement("img"); img.alt=""; img.loading="lazy"; img.src=itemImage(item);
    img.addEventListener("error",()=>{img.style.opacity=".25";});
    const label=document.createElement("span"); label.textContent=item.name || item.slug || "Custom skin";
    btn.append(img,label);
    btn.addEventListener("mouseenter",()=>setPreview(item,item._custom?"Custom skin":"Library skin"));
    btn.addEventListener("focus",()=>setPreview(item,item._custom?"Custom skin":"Library skin"));
    btn.addEventListener("mouseleave",()=>{ if(selectedItem) setPreview(selectedItem,selectedItem._custom?"Custom skin":"Library skin"); });
    btn.addEventListener("click",()=>{
      selectedItem=item;
      setPreview(item,item._custom?"Custom skin":"Library skin");
      renderGrid();
      const replacementValue = item._custom ? "custom:" + item.id : item.slug;
      if ((item._custom || item.evolution===evolution) && [...$("replacement").options].some(o=>o.value===replacementValue)) { $("replacement").value=replacementValue; }
      updateReplacementPreview();
      saveUiState();
    });
    grid.append(btn);
  }
  $("count").textContent = `${items.length} ${showCustomOnly?"custom skins":"skins shown"} · ${showCustomOnly?"saved locally":evolutionLabel[evolution]}`;
  if (!items.length) {
    const empty=document.createElement("div"); empty.className="small"; empty.textContent="No matching skins. Try another search or collection."; grid.append(empty);
  }
}
async function saveUiState() {
  await chrome.storage.local.set({fdhUiState:{evolution,showCustomOnly,selectedId:selectedItem?.id || null,selectedCustom:!!selectedItem?._custom}});
}
function message(type, settings) {
  return new Promise(resolve => chrome.runtime.sendMessage({type, settings}, response => {
    if (chrome.runtime.lastError) resolve({ok:false,error:chrome.runtime.lastError.message});
    else resolve(response || {ok:false,error:"No response from extension background."});
  }));
}
function switchEvolution(next) {
  evolution=next; showCustomOnly=false;
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.evolution===evolution));
  fillSourceSkins(); fillReplacementSelect();
  const first=itemsForCurrent()[0] || null;
  selectedItem=first;
  setPreview(first);
  renderGrid(); updateReplacementPreview(); saveUiState();
}
function displaySkinName(evo, slug) {
  const item = catalog.find(x => x.evolution === evo && x.slug === slug);
  return item?.name || slug || "Unknown skin";
}
function renderActiveMappings() {
  const root = $("activeSkins");
  root.replaceChildren();
  $("activeCount").textContent = `${activeMappings.length} active mapping${activeMappings.length===1?"":"s"} · up to 900`;
  if (!activeMappings.length) {
    const p=document.createElement("p"); p.className="small";
    p.textContent=currentLanguage==="ar"?"مفيش سكنات مفعّلة لسه. اختار الأصلي والبديل واضغط إضافة.":"No active skins yet. Choose an original folder and replacement, then add it.";
    root.append(p); return;
  }
  activeMappings.forEach((mapping,index)=>{
    const row=document.createElement("div"); row.className="active-mapping";
    const info=document.createElement("div"); info.className="mapping-info";
    const title=document.createElement("div"); title.className="mapping-title";
    const sourceName = displaySkinName(mapping.evolution, mapping.sourceSkin);
    const customReplacement = mapping.customId ? customSkins.find(x=>x.id===mapping.customId) : null;
    const replacementName = customReplacement?.name || displaySkinName(mapping.evolution, mapping.skin);
    title.textContent=`${evolutionLabel[mapping.evolution]||mapping.evolution}: ${sourceName} → ${replacementName}`;
    const sub=document.createElement("div"); sub.className="mapping-sub";
    sub.textContent=`${index+1}. Folder: ${mapping.sourceSkin} → ${customReplacement ? "Custom image" : mapping.skin}`;
    const visual=document.createElement("div"); visual.className="mapping-visual";
    const originalImg=document.createElement("img"); originalImg.alt="Original skin";
    const originalItem=catalog.find(x=>x.evolution===mapping.evolution && x.slug===mapping.sourceSkin); if(originalItem) originalImg.src=itemImage(originalItem);
    const arrow=document.createElement("span"); arrow.textContent="→"; arrow.style.color="var(--orange2)";
    const replacementImg=document.createElement("img"); replacementImg.alt="Replacement skin";
    const replacementItem=customReplacement || catalog.find(x=>x.evolution===mapping.evolution && x.slug===mapping.skin); if(replacementItem) replacementImg.src=itemImage(replacementItem);
    visual.append(originalImg,arrow,replacementImg);
    const remove=document.createElement("button"); remove.className="remove-mapping";
    remove.type="button"; remove.textContent=currentLanguage==="ar"?"إلغاء":"Remove";
    remove.title=currentLanguage==="ar"?"إلغاء هذا التحويل فقط":"Remove this mapping only";
    remove.addEventListener("click",async()=>{
      const next=activeMappings.filter((_,i)=>i!==index);
      await syncActiveMappings(next);
      setStatus(currentLanguage==="ar"?"تم إلغاء السكن المحدد فقط.":"Removed this mapping only.");
    });
    info.append(title,sub); row.append(visual,info,remove); root.append(row);
  });
}
async function syncActiveMappings(next) {
  setStatus("Updating active skins…");
  const result=await new Promise(resolve=>chrome.runtime.sendMessage({type:"FDH_SYNC",mappings:next},response=>{
    if(chrome.runtime.lastError) resolve({ok:false,error:chrome.runtime.lastError.message});
    else resolve(response||{ok:false,error:"No response from background."});
  }));
  if(!result.ok) { setStatus(`Could not update active skins: ${result.error||"unknown error"}`); return false; }
  activeMappings=next;
  renderActiveMappings();
  return true;
}
function renderCustomList() {
  const root=$("customList"); root.replaceChildren();
  if (!customSkins.length) { const p=document.createElement("p");p.className="small";p.textContent=currentLanguage==="ar"?"لسه مفيش سكنات مخصصة محفوظة. ارفع صورة واضغط حفظ.":"No saved custom skins yet. Upload an image and click Save.";root.append(p);return; }
  customSkins.forEach((item,index)=>{
    const row=document.createElement("div");row.className="bundle-preview";
    const img=document.createElement("img");img.src=item.dataUrl;img.alt="";
    const info=document.createElement("div");
    const title=document.createElement("div");title.className="skin-title";title.textContent=item.name;
    const actions=document.createElement("div");actions.className="custom-row-actions";
    const use=document.createElement("button");use.className="btn";use.textContent=currentLanguage==="ar"?"Use · استعمل":"Use";use.title="Use this custom skin as the replacement";
    use.addEventListener("click",()=>{
      selectedItem={...item,_custom:true}; showCustomOnly=true; $("search").value="";
      $("customPreview").src=item.dataUrl; $("customName").textContent=item.name; $("customNameInput").value=item.name;
      fillReplacementSelect("custom:"+item.id); $("replacement").value="custom:"+item.id;
      renderGrid(); updateReplacementPreview(); saveUiState();
      $("skinGrid").scrollIntoView({behavior:"smooth",block:"start"});
      $("sourceSkin").focus();
      setStatus(currentLanguage==="ar"?`تم اختيار «${item.name}» كالسكن البديل. اختار السكن الأصلي من القائمة فوق، ثم اضغط إضافة / تحديث.`:`“${item.name}” is now selected as the replacement. Choose the original skin folder above, then click Add / Update.`);
    });
    const del=document.createElement("button");del.className="btn danger";del.textContent=currentLanguage==="ar"?"حذف":"Delete";
    del.addEventListener("click",async()=>{customSkins.splice(index,1);await chrome.storage.local.set({fdhCustomSkins:customSkins});if(selectedItem?._custom&&selectedItem.id===item.id)selectedItem=null;fillReplacementSelect();renderCustomList();renderGrid();updateReplacementPreview();setStatus("Custom skin deleted from local storage.");});
    actions.append(use,del);info.append(title,actions);row.append(img,info);root.append(row);
  });
}
function readFileAsDataURL(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(new Error("Could not read image: "+file.name));reader.readAsDataURL(file);});}
function previewCustomDraft(draft, message){
  customDraft=draft; $("customNameInput").value=draft.name; $("customPreview").src=draft.dataUrl;
  $("customName").textContent=draft.name; $("replacementPreviewImage").src=draft.dataUrl;
  $("replacementPreviewName").textContent=draft.name+(currentLanguage==="ar"?" (مخصص)":" (custom)");
  $("saveCustom").disabled=false; setPreview({...draft,id:"upload-preview",_custom:true},"Custom upload preview");
  selectedItem={...draft,id:"upload-preview",_custom:true}; renderGrid(); saveUiState(); setStatus(message);
}
$("customFile").addEventListener("change",async()=>{
  const file=$("customFile").files?.[0]; if(!file)return;
  const ext=(file.name.split(".").pop()||"").toLowerCase();
  const allowed=/^image\/(png|jpeg|webp|gif)$/.test(file.type)||["png","jpg","jpeg","webp","gif"].includes(ext);
  if(!allowed){setStatus(currentLanguage==="ar"?"اختار صورة PNG أو JPG أو WebP أو GIF.":"Please choose a PNG, JPG, WebP, or GIF image.");return;}
  if(file.size>5*1024*1024){setStatus(currentLanguage==="ar"?"حجم الصورة أكبر من 5 ميجابايت.":"Image is too large. Choose an image under 5 MB.");return;}
  try {
    const dataUrl=await readFileAsDataURL(file);
    // Verify that Chrome can decode the selected Desktop image before enabling Save.
    await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve();img.onerror=()=>reject(new Error("Image format could not be decoded. Try saving it as PNG or JPG."));img.src=dataUrl;});
    const name=$("customNameInput").value.trim()||file.name.replace(/\.[^.]+$/,"");
    const type=file.type||({jpg:"image/jpeg",jpeg:"image/jpeg",png:"image/png",webp:"image/webp",gif:"image/gif"}[ext]||"image/png");
    previewCustomDraft({name,dataUrl,type},currentLanguage==="ar"?"الصورة ظهرت. الصورة الثابتة مش هتتحرك لوحدها؛ اضغط حفظ السكن المخصص.":"Image preview loaded. A still image will not animate by itself; click Save custom skin.");
  } catch(e){setStatus(e.message||"Could not read this image.");}
});

// Grim Reaper animation is loaded automatically by the page bridge; no second picker.

$("customNameInput").addEventListener("input",()=>{
  if(!customDraft)return;
  const name=$("customNameInput").value.trim() || "Unnamed custom skin";
  customDraft.name=name; $("customName").textContent=name;
  $("replacementPreviewName").textContent=name+(currentLanguage==="ar"?" (مخصص)":" (custom)");
});
$("clearCustomDraft").addEventListener("click",()=>{
  customDraft=null; $("customFile").value=""; if($("framesStatus"))$("framesStatus").textContent="حركة الريبر تُحمّل تلقائيًا عند اختيار Grim Reaper."; $("customNameInput").value=""; $("customPreview").removeAttribute("src"); $("customName").textContent=currentLanguage==="ar"?"مفيش سكن مخصص متحدد":"No custom skin selected"; $("saveCustom").disabled=true;
  setStatus(currentLanguage==="ar"?"تم مسح المعاينة الحالية فقط.":"Current custom preview cleared.");
});
$("saveCustom").addEventListener("click",async()=>{
  if(!customDraft)return;
  customDraft.name=$("customNameInput").value.trim() || customDraft.name || "Custom skin";
  const existing=customSkins.findIndex(x=>x.name===customDraft.name && x.type===customDraft.type);
  const id=existing>=0?customSkins[existing].id:("custom-"+Date.now()+"-"+Math.random().toString(36).slice(2,7));
  const saved={id,name:customDraft.name,dataUrl:customDraft.dataUrl,type:customDraft.type,...(customDraft.frames?{frames:customDraft.frames}:{}),createdAt:Date.now()};
  if(existing>=0) customSkins[existing]=saved; else customSkins.push(saved);
  try{await chrome.storage.local.set({fdhCustomSkins:customSkins});selectedItem={...saved,_custom:true};fillReplacementSelect("custom:"+saved.id);renderCustomList();renderGrid();setPreview(selectedItem,"Custom skin");updateReplacementPreview();setStatus("Custom skin saved locally. Press Use on its card to select it for replacement.");$("saveCustom").disabled=true;customDraft=null;}
  catch(e){setStatus("Could not save custom skin. Browser storage may be full.");}
});
$("search").addEventListener("input",renderGrid);
$("showAll").addEventListener("click",()=>{showCustomOnly=false;renderGrid();});
$("showCustom").addEventListener("click",()=>{showCustomOnly=true;renderGrid();});
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>switchEvolution(b.dataset.evolution)));
$("sourceSkin").addEventListener("change",()=>{updateReplacementPreview();saveUiState();});
$("replacement").addEventListener("change",()=>{
  const value=$("replacement").value;
  const item=value.startsWith("custom:") ? customSkins.find(x=>x.id===value.slice(7)) : itemsForCurrent().find(x=>x.slug===value);
  if(item){selectedItem={...item,...(value.startsWith("custom:")?{_custom:true}:{})};setPreview(selectedItem);showCustomOnly=!!selectedItem._custom;renderGrid();}
  updateReplacementPreview(); saveUiState();
});
$("apply").addEventListener("click",async()=>{
  const sourceSkin=$("sourceSkin").value, replacementValue=$("replacement").value;
  if(!sourceSkin||!replacementValue){setStatus("Choose both the original skin folder and a replacement first.");return;}
  const isCustom=replacementValue.startsWith("custom:");
  const customId=isCustom?replacementValue.slice(7):null;
  const customItem=isCustom?customSkins.find(x=>x.id===customId):null;
  if(isCustom&&!customItem){setStatus("That custom skin was not found. Press Use again.");return;}
  const skin=isCustom?("custom-"+customId):replacementValue;
  const key=`${evolution}::${sourceSkin}`;
  const next=activeMappings.filter(x=>`${x.evolution}::${x.sourceSkin}`!==key);
  if(next.length>=900){setStatus("You reached the safe limit of 900 active mappings. Remove one before adding another.");return;}
  next.push({id:`${evolution}-${sourceSkin}`,evolution,sourceSkin,skin,...(isCustom?{customId}: {})});
  const ok=await syncActiveMappings(next);
  if(ok) setStatus(isCustom ? (evolution === "grimReaper" ? `Custom image “${customItem.name}” assigned to ${sourceSkin}. Grim Reaper frame sequence is loaded automatically. Note: these linked frames are the original Purple Grim Reaper artwork; they do not automatically reshape your uploaded image into matching poses. Reload EvoWorld to test.` : `Custom image “${customItem.name}” assigned to ${sourceSkin}. Automatic Reaper frames are limited to Grim Reaper; this evolution uses your uploaded image as a static replacement. Reload EvoWorld to test.`) : `Active: ${sourceSkin} → ${skin}. Reload EvoWorld to test. Other active mappings were kept.`);
});
$("reset").addEventListener("click",async()=>{
  const ok=await syncActiveMappings([]);
  if(ok) setStatus("All active replacements removed. Reload EvoWorld to restore original sprites.");
});
(async()=>{
  try{
    const response=await fetch(chrome.runtime.getURL("skins.json"));
    if(!response.ok)throw new Error("Skin catalog file not found.");
    catalog=await response.json();
    if(!Array.isArray(catalog))throw new Error("Skin catalog format is invalid.");
    catalog=catalog.filter(x=>x && x.slug && x.evolution && x.image);
    const stored=await chrome.storage.local.get(keys);
    customSkins=Array.isArray(stored.fdhCustomSkins)?stored.fdhCustomSkins:[];
    renderCustomList();
    const ui=stored.fdhUiState||{};
    const settings=stored.fdhSettings||{};
    activeMappings=Array.isArray(stored.fdhMappings)?stored.fdhMappings:(Array.isArray(settings.mappings)?settings.mappings:(settings.enabled&&settings.evolution&&settings.sourceSkin&&settings.skin?[{id:"legacy",evolution:settings.evolution,sourceSkin:settings.sourceSkin,skin:settings.skin}]:[]));
    renderActiveMappings();
    setLanguage(stored.fdhLanguage === "ar" ? "ar" : "en");
    evolution=ui.evolution||settings.evolution||"ghostlyReaper";
    if(!evolutionLabel[evolution])evolution="ghostlyReaper";
    document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.evolution===evolution));
    showCustomOnly=!!ui.showCustomOnly;
    fillSourceSkins(settings.sourceSkin);
    fillReplacementSelect(settings.skin || (settings.customId ? "custom:"+settings.customId : undefined));
    let selected=catalog.find(x=>x.id===ui.selectedId);
    if(ui.selectedCustom){const found=customSkins.find(x=>x.id===ui.selectedId);if(found)selected={...found,_custom:true};}
    selectedItem=selected||itemsForCurrent()[0]||null;
    if(selectedItem)setPreview(selectedItem,selectedItem.dataUrl?"Custom skin":"Library skin");
    renderGrid();
    if(ui.selectedCustom && selectedItem?._custom) { fillReplacementSelect("custom:"+selectedItem.id); $("replacement").value="custom:"+selectedItem.id; }
    updateReplacementPreview();
    setStatus(`${catalog.length} bundled skin files loaded · ${activeMappings.length} active mappings.`);
  }catch(e){setStatus(`Could not load skin catalog: ${e.message}`);}
})();
