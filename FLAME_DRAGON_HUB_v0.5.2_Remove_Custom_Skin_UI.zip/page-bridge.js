// Page-world bridge: redirects real EvoWorld frame requests to user-provided artwork.
(() => {
  let mappings = [];
  const originalUrls = new WeakMap();
  const originalSetAttribute = Element.prototype.setAttribute;
  const imageSrcDescriptor = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, "src");
  function rewrite(value) {
    if (typeof value !== "string" || !value) return value;
    let url;
    try { url = new URL(value, location.href); } catch { return value; }
    if (url.hostname !== "cdn.eu.evoworld.io") return value;
    const parts = url.pathname.split("/");
    // /sprites/characters/{evolution}/{sourceSkin}/{state}/{number}.png
    if (parts.length < 7 || parts[1] !== "sprites" || parts[2] !== "characters") return value;
    const evolution = parts[3], sourceSkin = parts[4];
    const mapping = mappings.find(m => m.evolution === evolution && m.sourceSkin === sourceSkin);
    if (!mapping) return value;
    const state = parts[5] || "idle";
    const filename = parts[6] || "1.png";
    const frameNumber = Number((filename.match(/(\\d+)/) || [])[1] || 1);
    const frames = mapping.frames?.[state];
    if (Array.isArray(frames) && frames.length) {
      const frame = frames[frameNumber - 1] || frames[0];
      if (typeof frame === "string" && (frame.startsWith("data:image/") || (frame.startsWith("https://cdn.eu.evoworld.io/sprites/characters/grimReaper/purple/") && /^https:\/\/cdn\.eu\.evoworld\.io\/sprites\/characters\/grimReaper\/purple\/(?:idle|flying|attack)\/\d+\.png$/.test(frame)))) return frame;
    }
    return mapping.dataUrl || value;
  }
  if (imageSrcDescriptor?.get && imageSrcDescriptor?.set) {
    Object.defineProperty(HTMLImageElement.prototype, "src", {
      configurable: true,
      enumerable: imageSrcDescriptor.enumerable,
      get: imageSrcDescriptor.get,
      set(value) {
        const raw = String(value), next = rewrite(raw);
        if (next !== raw) originalUrls.set(this, raw);
        else if (!raw.startsWith("data:")) originalUrls.delete(this);
        imageSrcDescriptor.set.call(this, next);
      }
    });
  }
  Element.prototype.setAttribute = function(name, value) {
    if (this instanceof HTMLImageElement && String(name).toLowerCase() === "src") {
      const raw = String(value), next = rewrite(raw);
      if (next !== raw) originalUrls.set(this, raw);
      else if (!raw.startsWith("data:")) originalUrls.delete(this);
      return originalSetAttribute.call(this, name, next);
    }
    return originalSetAttribute.call(this, name, value);
  };
  function applyToExistingImages() {
    for (const img of document.images) {
      const current = img.getAttribute("src") || img.src;
      const base = originalUrls.get(img) || current;
      const replacement = rewrite(base);
      if (replacement && replacement !== current) img.src = replacement;
      if (replacement === base && originalUrls.has(img)) originalUrls.delete(img);
    }
  }
  window.addEventListener("message", event => {
    if (event.source !== window || event.data?.type !== "FDH_CUSTOM_SKIN_MAPPINGS" || !Array.isArray(event.data.mappings)) return;
    mappings = event.data.mappings.filter(m =>
      typeof m?.evolution === "string" && typeof m?.sourceSkin === "string" &&
      typeof m?.dataUrl === "string" && /^data:image\/(png|jpeg|webp|gif);base64,/.test(m.dataUrl) &&
      (!m.frames || typeof m.frames === "object")
    );
    applyToExistingImages();
  });
})();
