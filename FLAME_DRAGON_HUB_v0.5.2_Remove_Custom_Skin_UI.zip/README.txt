FLAME DRAGON HUB — Chrome Extension v0.5.0

This package preserves all 184 bundled skin image files and adds a persistent multi-mapping manager.

INSTALL / UPDATE IN CHROME
1. Extract this ZIP completely to a normal folder.
2. Open chrome://extensions in Chrome.
3. Turn on Developer mode.
4. If an older FLAME DRAGON HUB unpacked extension is loaded, keep a backup of its folder.
5. Click Load unpacked and select the extracted FLAME_DRAGON_HUB_Chrome_Extension folder (the folder containing manifest.json).
6. Open the extension popup. Choose an evolution, select an original folder and replacement, then click “Add / Update Active Skin”.
7. For a custom upload, save the image in Add Your Skin, press Use on its saved card, choose the original skin folder, then click Add / Update Active Skin. Repeat with different original folders. The Active Skins list shows each mapping; Remove deletes only that mapping.
8. Open/reload EvoWorld to test. Use “Restore original sprites” to remove all active mappings.

MULTI-SKIN MANAGER
- Active mappings are stored locally and restored when Chrome starts.
- Each original folder can have one replacement per evolution. Adding another replacement for the same original folder updates that mapping instead of creating a conflict.
- The extension allows up to 900 active mappings as a safety cap under Chrome's regular-expression rule quota. This is not an unlimited number, and Chrome or browser policy may impose additional limits.
- A mapping is a URL-folder redirect, not a per-account change. Other players requesting the exact same source URL may also be affected.
- If two different source folders point to the same replacement folder, both use that replacement. You cannot map one exact source folder to multiple different replacements at the same time.

IMPORTANT FUNCTIONAL LIMITS
- This package includes 184 catalog image files: Grim Reaper 127, Pumpkin Ghost 32, Ghostly Reaper 25.
- Catalog names are not guaranteed to match all live EvoWorld CDN folder names. If a replacement folder does not exist on the live CDN, it may not work in-game even though its preview image appears in the extension.
- The redirect rule currently handles matching PNG frame URLs on cdn.eu.evoworld.io in the expected path format. Actual behavior still needs testing in a live EvoWorld session.
- Uploaded custom images can be saved, then selected with the new Use button. Choose an original skin folder and click Add / Update Active Skin. The custom image bridge replaces matching HTML image elements with the uploaded image. A single still image does not become a real character animation. Animated GIFs may animate if EvoWorld renders the data URL as an animated image. It may not affect game renderers that load textures without HTMLImageElement.src.
- The skin catalog accepts source folder names containing spaces (for example, “dragon lord”); earlier validation rejected these names and could prevent those mappings from being added.
- This is an experimental local extension package, not a Chrome Web Store listing.

TEST CHECKLIST
- Check all three evolution tabs and skin counts.
- Add two different mappings, close/reopen the popup, and confirm both remain in Active Skins.
- Remove one mapping and confirm the other remains.
- Test a known valid original folder/replacement in EvoWorld.
- Use Restore original sprites and reload EvoWorld.
- If a skin fails, record the evolution, original folder, replacement folder, and console/network error; preview success alone does not prove the CDN redirect works.


Version 0.4.5: custom upload accepts GIF files and page bridge passes animated GIF data URLs. A still image does not gain animation; use an animated GIF for motion. In-game GIF rendering can depend on EvoWorld's sprite renderer.


Version 0.4.7 — custom multi-frame animation folder support
- In Add Your Skin, use the second folder picker to choose a folder containing idle/, flying/, and attack/ subfolders.
- Put numbered images in each state folder, e.g. idle/1.png, idle/2.png, flying/1.png, attack/1.png. Frame numbers should start at 1.
- The extension uses the requested EvoWorld animation state and frame number to choose the corresponding uploaded frame. If a requested frame is missing, it falls back to the first frame for that state, then the skin preview image.
- Limit: up to 90 frames total, each at most 2 MB, with a combined source size at most 20 MB.
- This works only where EvoWorld requests frames through matching HTML image URLs intercepted by page-bridge.js. If the game renders sprites through a different texture/canvas pipeline, the in-game behavior may require a different integration and must be tested.


Version 0.4.9 — removed synthetic fake motion frames. Uploaded still images are no longer distorted into invented poses; true custom animation requires real, separate frame artwork for idle/, flying/, and attack/.


Version 0.5.0 — repaired custom multi-frame animation upload
- Restored the animation-folder picker in Add Your Skin.
- Select a base image as before, then optionally select a folder tree containing idle/, flying/, and attack/ subfolders with numbered PNG/JPG/WebP frames (e.g. idle/1.png, flying/1.png, attack/1.png).
- Real frame images are stored with the custom skin and routed according to the requested animation state and frame number. No artificial zoom/rotation frames are generated.
- The bundled skin library is unchanged. Existing single-image custom skins remain supported and stay still (except animated GIFs where the game renderer honors GIF animation).
- Limits: 90 frames total, 2 MB per frame, 20 MB total. A complete animation needs actual artwork for all three states. Missing frame numbers fall back to the first frame of that state.
- The bridge intercepts HTMLImageElement src and setAttribute("src") requests only. If EvoWorld uses canvas/WebGL textures or another loading path for sprites, true in-game animation may still not be intercepted and must be tested in a live session.


Version 0.5.1 — automatic Grim Reaper frame sequence
- Removed the second animation-folder picker. The user chooses one custom image, then selects the target skin as before.
- For custom mappings in the Grim Reaper evolution only, the bridge automatically selects the supplied Purple Grim Reaper CDN frame sequences: attack 1–8, flying 1–5, idle 1–6. Pumpkin Ghost and Ghostly Reaper are not changed.
- Important visual limitation: these are full original Purple Grim Reaper images. They do not automatically transform a user's still image into the same poses, so while these source frames are used the in-game appearance is Purple Grim Reaper artwork rather than a faithful animated version of the uploaded skin. Genuine custom-looking animation requires matching artwork for each pose or a purpose-built sprite/texture rig.
- No bundled skin image files or skins.json entries were modified.
