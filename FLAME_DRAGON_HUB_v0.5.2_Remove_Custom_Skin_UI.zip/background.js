const FIRST_RULE_ID = 70101;
const MAX_MAPPINGS = 900;
const EVOLUTIONS = new Set(["grimReaper", "pumpkinGhost", "ghostlyReaper"]);
function validSlug(s) { return typeof s === "string" && /^[A-Za-z0-9 _-]{1,60}$/.test(s) && s.trim() === s; }
function normalizeMappings(settings) {
  if (Array.isArray(settings?.mappings)) return settings.mappings;
  if (settings?.enabled && settings.evolution && settings.sourceSkin && settings.skin) {
    return [{ id: "legacy-" + settings.evolution + "-" + settings.sourceSkin, evolution: settings.evolution, sourceSkin: settings.sourceSkin, skin: settings.skin }];
  }
  return [];
}
async function syncMappings(mappings) {
  if (!Array.isArray(mappings)) throw new Error("Mappings list is invalid.");
  if (mappings.length > MAX_MAPPINGS) throw new Error(`Chrome rule safety limit: maximum ${MAX_MAPPINGS} active mappings.`);
  const seen = new Set();
  const rules = [];
  mappings.forEach((item, index) => {
    const evolution = item?.evolution, sourceSkin = item?.sourceSkin, skin = item?.skin;
    if (!EVOLUTIONS.has(evolution) || !validSlug(sourceSkin) || !validSlug(skin)) {
      throw new Error(`Mapping ${index + 1} has an invalid evolution or skin folder name.`);
    }
    const key = `${evolution}::${sourceSkin}`;
    if (seen.has(key)) throw new Error(`The original folder "${sourceSkin}" is already mapped for this evolution. Remove it first to avoid conflicts.`);
    seen.add(key);
    // Custom images are handled by page-bridge.js because DNR cannot redirect to chrome.storage data URLs.
    if (item.customId) return;
    rules.push({
      id: FIRST_RULE_ID + rules.length,
      priority: 1,
      action: { type: "redirect", redirect: { regexSubstitution: `https://cdn.eu.evoworld.io/sprites/characters/${evolution}/${skin}/\\1/\\2.png` } },
      condition: {
        regexFilter: `^https://cdn\\.eu\\.evoworld\\.io/sprites/characters/${evolution}/${sourceSkin}/([^/]+)/([0-9]+)\\.png(?:\\?.*)?$`,
        resourceTypes: ["image"],
        requestDomains: ["cdn.eu.evoworld.io"]
      }
    });
  });
  const removeRuleIds = Array.from({length: MAX_MAPPINGS}, (_, i) => FIRST_RULE_ID + i);
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules: rules });
  return { enabled: rules.length > 0, count: rules.length };
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "FDH_SYNC") {
    const mappings = message.mappings;
    syncMappings(mappings).then(async result => {
      await chrome.storage.local.set({
        fdhMappings: mappings,
        fdhSettings: { enabled: mappings.length > 0, mappings }
      });
      sendResponse({ ok: true, result });
    }).catch(error => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === "FDH_APPLY") {
    const old = message.settings || {};
    chrome.storage.local.get(["fdhMappings", "fdhSettings"]).then(async stored => {
      const mappings = Array.isArray(stored.fdhMappings) ? stored.fdhMappings : normalizeMappings(stored.fdhSettings);
      const key = `${old.evolution}::${old.sourceSkin}`;
      const next = mappings.filter(x => `${x.evolution}::${x.sourceSkin}` !== key);
      next.push({ id: `${old.evolution}-${old.sourceSkin}`, evolution: old.evolution, sourceSkin: old.sourceSkin, skin: old.skin });
      const result = await syncMappings(next);
      await chrome.storage.local.set({ fdhMappings: next, fdhSettings: { enabled: true, mappings: next } });
      sendResponse({ ok: true, result, mappings: next });
    }).catch(error => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === "FDH_RESET") {
    syncMappings([]).then(async () => {
      await chrome.storage.local.set({ fdhMappings: [], fdhSettings: { enabled: false, mappings: [] } });
      sendResponse({ ok: true });
    }).catch(error => sendResponse({ ok: false, error: error.message }));
    return true;
  }
});
chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get(["fdhMappings", "fdhSettings"]);
  const mappings = Array.isArray(stored.fdhMappings) ? stored.fdhMappings : normalizeMappings(stored.fdhSettings);
  try {
    await syncMappings(mappings);
    await chrome.storage.local.set({ fdhMappings: mappings, fdhSettings: { enabled: mappings.length > 0, mappings } });
  } catch (e) { console.warn("FDH mappings not restored", e); }
});
