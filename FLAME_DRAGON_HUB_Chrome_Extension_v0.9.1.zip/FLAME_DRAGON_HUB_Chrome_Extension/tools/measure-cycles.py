"""Measures the motion of every animation state that is longer than the engine's slots.

The engine plays a fixed number of slots, ping-pong. A skin whose artwork cycles over more frames
than there are slots is cut short, so the artwork must be thinned to fit. To thin it well we need
two things per state:

  animation-cycles.json  the frame at which the forward cycle ends
  frame-motion.json      the movement between each frame and the one before it

The cycle ends at the frame furthest from the first one, unless the motion returns close to its
start, in which case the return is the cycle end. Motion is the distance between consecutive
frames, which identifies the near-duplicate frames that can be dropped.

Both files are consumed by tools/fit-frames-to-engine.js.
"""
import json
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
from PIL import Image, ImageChops

BASE = "https://cdn.eu.evoworld.io/sprites/characters"
ROOT = "/tmp/work/FLAME_DRAGON_HUB_Chrome_Extension"

SLOTS = {
    "grimReaper": {"idle": 6, "flying": 5, "attack": 8},
    "pumpkinGhost": {"flying": 9, "attack": 5},
    "ghostlyReaper": {"flying": 17, "attack": 16},
    "ghost": {"flying": 7},
}


def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=25) as r:
        return r.read()


def load(evo, slug, state, n):
    return Image.open(BytesIO(get(f"{BASE}/{evo}/{slug}/{state}/{n}.png"))).convert("RGBA")


def centre(im):
    bb = im.getbbox()
    return ((bb[0] + bb[2]) / 2, (bb[1] + bb[3]) / 2)


def measure(job):
    key, state, n = job
    evo, slug = key.split("/", 1)
    imgs = [load(evo, slug, state, i) for i in range(1, n + 1)]
    pts = [centre(im) for im in imgs]
    dist = [((p[0] - pts[0][0]) ** 2 + (p[1] - pts[0][1]) ** 2) ** 0.5 for p in pts]
    apex = max(range(n), key=lambda i: dist[i])
    returns = dist[-1] < max(dist) * 0.5
    cycle = apex + 1 if (apex + 1 < n and returns) else n
    # Motion is the real pixel change between consecutive frames: the sum of absolute channel
    # differences. This identifies near-duplicate frames far more reliably than the bounding box
    # centre, which barely moves for a subtle idle.
    motion = []
    for i in range(1, n):
        diff = ImageChops.difference(imgs[i], imgs[i - 1])
        motion.append(round(sum(diff.convert("L").get_flattened_data()) / 1000, 1))
    return f"{key}/{state}", cycle, motion


catalog = json.load(open(f"{ROOT}/frames-catalog.json"))
jobs = []
for key, states in catalog.items():
    evo = key.split("/", 1)[0]
    for state, want in SLOTS.get(evo, {}).items():
        n = len(states.get(state, []))
        if n > want:
            jobs.append((key, state, n))

print(f"measuring {len(jobs)} states longer than the engine's slots")
with ThreadPoolExecutor(max_workers=5) as ex:
    rows = list(ex.map(measure, jobs))

cycles, motions = {}, {}
for name, cycle, motion in sorted(rows):
    cycles[name] = cycle
    motions[name] = motion
    print(f"   {name:<40} cycle={cycle:<3} motion={motion}")

for path, data in ((f"{ROOT}/tools/animation-cycles.json", cycles),
                   (f"{ROOT}/tools/frame-motion.json", motions)):
    json.dump(data, open(path, "w"), indent=1, sort_keys=True)
    open(path, "a").write("\n")
print(f"\nwrote {len(cycles)} cycles and {len(motions)} motion rows")
