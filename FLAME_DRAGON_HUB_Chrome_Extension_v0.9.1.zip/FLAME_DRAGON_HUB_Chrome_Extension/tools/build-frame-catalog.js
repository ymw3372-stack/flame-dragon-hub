#!/usr/bin/env node
/*
 * Regenerates frames-catalog.json from the live EvoWorld CDN.
 *
 * The extension needs to know which animation frames really exist for each skin, because the
 * frame counts differ per skin (grimReaper flying has 5 to 8 frames, ghostlyReaper attack has
 * 16, pumpkinGhost attack has 5) and two evolutions have no idle folder at all. Guessing the
 * counts is what made skins freeze before.
 *
 * Usage:
 *   node tools/build-frame-catalog.js [--out frames-catalog.json]
 *
 * Output shape:
 *   { "grimReaper/black": { "idle": [1,2,3,4,5,6], "flying": [...], "attack": [...] }, ... }
 */
const fs = require("fs");
const path = require("path");

const CDN = "https://cdn.eu.evoworld.io/sprites/characters";
const STATES = ["idle", "flying", "attack"];
const MAX_FRAME = 24;
const CONCURRENCY = 6;

const root = path.resolve(__dirname, "..");
const outArgIndex = process.argv.indexOf("--out");
const outFile = path.resolve(
  root,
  outArgIndex !== -1 ? process.argv[outArgIndex + 1] : "frames-catalog.json"
);

// skins.json now stores the real CDN folder names, so no slug rewriting is needed here.
// The corrections that used to live in this table are applied permanently in skins.json.

async function frameExists(evolution, slug, state, frame) {
  const url = `${CDN}/${evolution}/${slug}/${state}/${frame}.png`;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const response = await fetch(url, { method: "HEAD" });
      if (response.ok) return true;
      if (response.status === 404) return false;
      await new Promise(r => setTimeout(r, 300 * (attempt + 1)));
    } catch {
      await new Promise(r => setTimeout(r, 300 * (attempt + 1)));
    }
  }
  // Do not report a network failure as a missing frame: that would silently truncate the
  // catalog and make the animation play the wrong poses.
  throw new Error(`Could not determine whether ${url} exists`);
}

async function scanSkin(evolution, slug) {
  const row = {};
  for (const state of STATES) {
    const frames = [];
    // Stop at the first missing frame. The catalog list must be a contiguous 1..N run: the
    // extension maps requested frame index N to the Nth entry, so a hole would shift every
    // later frame and play the wrong pose.
    for (let frame = 1; frame <= MAX_FRAME; frame++) {
      if (await frameExists(evolution, slug, state, frame)) {
        frames.push(frame);
      } else {
        break;
      }
    }
    if (frames.length) row[state] = frames;
  }
  return row;
}

async function pool(items, worker, limit) {
  const results = [];
  let index = 0;
  async function run() {
    while (index < items.length) {
      const current = items[index++];
      results.push([current, await worker(current)]);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, run));
  return results;
}

async function main() {
  const catalog = JSON.parse(fs.readFileSync(path.join(root, "skins.json"), "utf8"));
  const targets = [];
  const seen = new Set();
  for (const entry of catalog) {
    const slug = entry.slug;
    const dedupe = `${entry.evolution}/${slug}`;
    if (seen.has(dedupe)) continue;
    seen.add(dedupe);
    targets.push([entry.evolution, slug]);
  }

  console.error(`Scanning ${targets.length} skins on ${CDN} ...`);
  const results = await pool(targets, ([e, s]) => scanSkin(e, s), CONCURRENCY);

  const output = {};
  let animated = 0;
  for (const [[evolution, slug], row] of results) {
    output[`${evolution}/${slug}`] = row;
    if (Object.keys(row).length) animated++;
  }

  fs.writeFileSync(outFile, JSON.stringify(output, null, 1) + "\n");
  console.error(`Wrote ${outFile}: ${animated}/${targets.length} skins have animation frames.`);
}

main().catch(error => {
  console.error(error);
  process.exit(1);
});
