"""Adds the ghost evolution's 43 skins to skins.json and scans their frames into the catalog.

The ghost evolution exists in the game bundle and on the CDN but was never in our catalog. It is
flying-only: the game loads only characters/ghost/<skin>/flying/N.png with 7 slots, and the CDN
has no idle or attack folder for it.
"""
import json
import urllib.request
from concurrent.futures import ThreadPoolExecutor

ROOT = "/tmp/work/FLAME_DRAGON_HUB_Chrome_Extension"
BASE = "https://cdn.eu.evoworld.io/sprites/characters"
MAX_FRAME = 24

GHOST_SKINS = ("standard demon ice enamored toxic halloween2021 xmas2021 leprechaun easter2022 "
               "pirate halloween2022 xmas2022 police dapper shadow patrick2023 easter2023 "
               "halloween2023 xmas2023v2 witch patrick2024 easter2024 halloween2024 xmas2024 "
               "patrick2025 easter2025 halloween2025 nightmare dragonLord xmas2025 xmas2025_2 "
               "fallenKnight laser cultist cyborg mummy patrick2026 easter2026 easter2026_free "
               "shark samurai screamingGhost owl").split()


def exists(url, tries=3):
    for _ in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=25) as r:
                return r.status == 200
        except urllib.error.HTTPError:
            return False
        except Exception:
            pass
    raise RuntimeError(f"could not determine existence of {url}")


def scan(slug):
    row = {}
    for state in ("idle", "flying", "attack"):
        frames = []
        for n in range(1, MAX_FRAME + 1):
            if exists(f"{BASE}/ghost/{slug}/{state}/{n}.png"):
                frames.append(n)
            else:
                break
        if frames:
            row[state] = frames
    return f"ghost/{slug}", row


def pretty(slug):
    """standard -> Ghost: Standard; screamingGhost -> Ghost: Screaming Ghost"""
    import re
    words = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", slug).replace("_", " ").split()
    return "Ghost: " + " ".join(w.capitalize() for w in words)


catalog = json.load(open(f"{ROOT}/skins.json"))
existing = {f"{e['evolution']}/{e['slug']}" for e in catalog}

added = []
for slug in GHOST_SKINS:
    key = f"ghost/{slug}"
    if key in existing:
        continue
    added.append({
        "evolution": "ghost",
        "slug": slug,
        "name": pretty(slug)
    })

catalog.extend(added)
json.dump(catalog, open(f"{ROOT}/skins.json", "w"), indent=1)
open(f"{ROOT}/skins.json", "a").write("\n")
print(f"added {len(added)} ghost skins to skins.json (total {len(catalog)})")

with ThreadPoolExecutor(max_workers=5) as ex:
    rows = list(ex.map(scan, GHOST_SKINS))

frames = json.load(open(f"{ROOT}/frames-catalog.json"))
for key, row in rows:
    frames[key] = row

json.dump(frames, open(f"{ROOT}/frames-catalog.json", "w"), indent=1, sort_keys=True)
open(f"{ROOT}/frames-catalog.json", "a").write("\n")

ok = sum(1 for _, r in rows if r)
print(f"ghost catalog entries: {len(rows)} ({ok} with frames)")
print("states seen:", sorted({s for _, r in rows for s in r}))
print("flying counts:", sorted({len(r.get('flying', [])) for _, r in rows}))
