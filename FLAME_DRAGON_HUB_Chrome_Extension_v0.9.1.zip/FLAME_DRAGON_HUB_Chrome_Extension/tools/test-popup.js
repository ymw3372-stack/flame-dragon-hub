#!/usr/bin/env node
/*
 * Loads popup.js against a stubbed popup and Chrome, then runs its init exactly as the browser
 * would. This catches the failures that a syntax check cannot see: a call to a function that was
 * removed, a missing element id, a selector that matches nothing, or an init that throws before
 * the catalog is loaded.
 *
 * Run: node tools/test-popup.js
 */
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const html = fs.readFileSync(path.join(root, "popup.html"), "utf8");
const source = fs.readFileSync(path.join(root, "popup.js"), "utf8");
const skins = JSON.parse(fs.readFileSync(path.join(root, "skins.json"), "utf8"));
const frames = JSON.parse(fs.readFileSync(path.join(root, "frames-catalog.json"), "utf8"));
const pets = JSON.parse(fs.readFileSync(path.join(root, "pets.json"), "utf8"));
const petFrames = JSON.parse(fs.readFileSync(path.join(root, "pets-catalog.json"), "utf8"));

let pass = 0;
const failures = [];
const check = (ok, label) => (ok ? pass++ : failures.push(label));

// --- a DOM element that tolerates everything popup.js does to it -------------------------------
function element(id = "") {
  const el = {
    id, tagName: "DIV", textContent: "", innerHTML: "", value: "", title: "", src: "", alt: "",
    loading: "", disabled: false, className: "", style: {}, dataset: {}, children: [],
    options: [], selectedIndex: -1,
    classList: {
      _set: new Set(),
      add(c) { this._set.add(c); }, remove(c) { this._set.delete(c); },
      contains(c) { return this._set.has(c); },
      toggle(c, on) { on === undefined ? (this._set.has(c) ? this._set.delete(c) : this._set.add(c)) : (on ? this._set.add(c) : this._set.delete(c)); }
    },
    append(...kids) { el.children.push(...kids); },
    appendChild(k) { el.children.push(k); return k; },
    replaceChildren(...kids) { el.children = kids; },
    // <select> elements are populated with add()/remove() rather than appendChild().
    add(opt) { el.options.push(opt); return opt; },
    remove() {},
    _listeners: {},
    addEventListener(type, fn) { (el._listeners[type] ||= []).push(fn); },
    dispatch(type, event = {}) { for (const fn of el._listeners[type] || []) fn(event); },
    removeEventListener() {},
    setAttribute(k, v) { el[k] = v; },
    getAttribute(k) { return el[k]; },
    removeAttribute(k) { delete el[k]; },
    focus() {}, blur() {}, click() {},
    querySelector() { return null; }, querySelectorAll() { return []; },
    closest() { return null; }, insertBefore() {}, removeChild() {}
  };
  return el;
}

const ids = [...html.matchAll(/id="([^"]+)"/g)].map(m => m[1]);
const byId = {};
for (const id of ids) byId[id] = element(id);

// The source-skin and replacement controls are real <select> elements: give them addable options.
for (const id of ["sourceSkin", "replacement"]) {
  byId[id].options = [];
  byId[id].appendChild = function (opt) { this.options.push(opt); return opt; };
  byId[id].replaceChildren = function (...opts) { this.options = opts; };
}

const tabs = [...html.matchAll(/<button class="tab[^"]*" data-evolution="([^"]+)"/g)]
  .map(m => { const t = element(); t.dataset.evolution = m[1]; return t; });

const document = {
  getElementById: id => byId[id] ?? null,
  createElement: tag => { const e = element(); e.tagName = tag.toUpperCase(); return e; },
  querySelector: () => null,
  querySelectorAll: sel => (sel === ".tab" ? tabs : []),
  addEventListener() {}, body: element(), documentElement: element()
};

let stored = { fdhUiState: {}, fdhSettings: {}, fdhMappings: [], fdhCustomSkins: [] };
let sentMessages = [];

const chrome = {
  runtime: {
    getURL: p => "chrome-extension://test/" + p,
    lastError: null,
    sendMessage: (msg, cb) => { sentMessages.push(msg); cb && cb({ ok: true }); },
    onMessage: { addListener() {} }
  },
  storage: {
    local: {
      get: keys => Promise.resolve(keys && typeof keys === "object" && !Array.isArray(keys)
        ? Object.fromEntries(Object.keys(keys).map(k => [k, stored[k]]))
        : { ...stored }),
      set: obj => { Object.assign(stored, obj); return Promise.resolve(); },
      remove: () => Promise.resolve()
    }
  }
};

const sandbox = {
  console, setTimeout, clearTimeout, Promise, JSON, Math, Date, Object, Array, String, Number,
  Boolean, Set, Map, RegExp, Error, parseInt, parseFloat, isNaN, URL, Blob, Image: class {},
  document, chrome,
  // popup.js builds dropdown entries with the browser's Option constructor.
  Option: class { constructor(text = "", value = "") { this.textContent = text; this.value = value; this.text = text; } },
  fetch: url => {
    const name = String(url).split("/").pop();
    if (name === "skins.json") return Promise.resolve({ ok: true, json: () => Promise.resolve(skins) });
    if (name === "frames-catalog.json") return Promise.resolve({ ok: true, json: () => Promise.resolve(frames) });
    if (name === "pets.json") return Promise.resolve({ ok: true, json: () => Promise.resolve(pets) });
    if (name === "pets-catalog.json") return Promise.resolve({ ok: true, json: () => Promise.resolve(petFrames) });
    return Promise.resolve({ ok: false, json: () => Promise.resolve(null) });
  },
  window: { addEventListener() {} }
};
sandbox.globalThis = sandbox;

vm.createContext(sandbox);
try {
  vm.runInContext(source, sandbox, { filename: "popup.js" });
  check(true, "popup.js loads without a syntax or reference error");
} catch (e) {
  check(false, `popup.js threw on load: ${e.message}`);
}

// Init runs asynchronously; let its promise chain settle.
setTimeout(() => {
  const status = byId.status.textContent;
  check(!/Could not load skin catalog/.test(status), `init did not report a load failure (status: ${status})`);
  check(/bundled skin files loaded/.test(status), `init finished and reported the catalog (status: ${status})`);
  check(byId.count.textContent.length > 0, "the grid reported a skin count");

  // The Ghosts section must be the one on screen at start.
  const active = tabs.filter(t => t.classList.contains("active")).map(t => t.dataset.evolution);
  check(active.length === 1, `exactly one tab is active (got ${JSON.stringify(active)})`);
  check(active[0] === "ghost", `the Ghosts tab is the active one (got ${active[0]})`);

  // Every tab the HTML offers must have a label and a non-empty catalog.
  for (const t of tabs) {
    const evo = t.dataset.evolution;
    const n = skins.filter(s => s.evolution === evo).length + pets.filter(s => s.evolution === evo).length;
    check(n > 0, `tab ${evo} has skins (${n})`);
  }

  // The Pets tab must hold every pet the game can load, each with a real thumbnail.
  const petTab = tabs.find(t => t.dataset.evolution === "pets");
  check(!!petTab, "the Pets tab exists");
  check(pets.length === 42, `the Pets tab lists all 42 pets (got ${pets.length})`);
  const petSlugs = new Set(pets.map(p => p.slug));
  for (let i = 1; i <= 42; i++) {
    check(petSlugs.has(String(i)), `the Pets tab contains pet ${i}`);
  }
  for (const p of pets) {
    check(!!petFrames[`pets/${p.slug}`]?.flying?.length, `pet ${p.slug} has a frame list`);
  }

  // The Ghosts tab must hold the game's Halloween skins.
  const ghostSlugs = new Set(skins.filter(s => s.evolution === "ghost").map(s => s.slug));
  for (const want of ["halloween2021", "halloween2022", "halloween2023", "halloween2024", "halloween2025", "screamingGhost", "dapper", "witch"]) {
    check(ghostSlugs.has(want), `Ghosts contains ${want}`);
  }

  // Skins the live game build has but an older catalog missed. Each must be selectable, animated,
  // and must fit the engine's fixed slot count for its evolution, or the motion would be cut short.
  const LIVE_SLOTS = {
    grimReaper: { idle: 6, flying: 5, attack: 8 },
    pumpkinGhost: { flying: 9, attack: 5 },
    ghostlyReaper: { flying: 17, attack: 16 },
    ghost: { flying: 7 },
  };
  const LIVE_SKINS = {
    grimReaper: ["abyss", "azureKnight", "darkKnight", "failed", "halloween2026", "lion",
      "mysteriousKnight", "nightOwl", "nightWolf", "oppressed", "photon", "polarBearFroster",
      "skullExecutioner", "spectralViking"],
    pumpkinGhost: ["halloween2026", "halloween2026_quest", "headless_2"],
    ghostlyReaper: ["evilRabbit", "halloween2026"],
    ghost: ["halloween2026", "lunarPriestess", "pureSoul"],
  };
  for (const [evolution, slugs] of Object.entries(LIVE_SKINS)) {
    const present = new Set(skins.filter(s => s.evolution === evolution).map(s => s.slug));
    for (const slug of slugs) {
      check(present.has(slug), `${evolution} contains the live skin ${slug}`);
      const row = frames[`${evolution}/${slug}`];
      check(!!row && Object.keys(row).length > 0, `${evolution}/${slug} is animated`);
      for (const [state, frames_] of Object.entries(row || {})) {
        const slots = LIVE_SLOTS[evolution][state];
        check(frames_.length === slots,
          `${evolution}/${slug} ${state} fills ${slots} engine slots (got ${frames_.length})`);
      }
    }
  }

  // Each catalog entry must point at a thumbnail that exists on disk.
  for (const s of [...skins, ...pets]) {
    if (!fs.existsSync(path.join(root, s.image))) { check(false, `missing thumbnail ${s.image}`); break; }
  }
  check(true, "every catalog entry has its thumbnail file");

  // Functionally switch to the Pets tab and confirm it renders the pets, then apply a mapping.
  petTab.dispatch("click");
  const petTiles = byId.skinGrid.children.filter(c => c.tagName === "BUTTON");
  check(petTiles.length === 42, `the Pets tab renders 42 pet tiles (got ${petTiles.length})`);
  const petImgs = petTiles.map(t => (t.children.find(c => c.tagName === "IMG") || {}).src || "");
  check(petImgs.every(s => s.includes("skins/pets/")), "every pet tile shows a pet thumbnail");
  check(petImgs.length === new Set(petImgs).size, "no two pet tiles share a thumbnail");

  byId.sourceSkin.value = "1";
  byId.replacement.value = "22";
  byId.apply.dispatch("click");
  const applied = sentMessages.filter(m => m.type === "FDH_SYNC").pop();
  const petMapping = applied?.mappings?.find(m => m.evolution === "pets");
  check(!!petMapping, "applying on the Pets tab sends a pet mapping");
  check(petMapping?.sourceSkin === "1" && petMapping?.skin === "22",
    `the pet mapping is pet 1 -> pet 22 (got ${JSON.stringify(petMapping)})`);

  console.log(`${pass} passed, ${failures.length} failed`);
  for (const f of failures) console.log("FAIL  " + f);
  process.exit(failures.length ? 1 : 0);
}, 250);
