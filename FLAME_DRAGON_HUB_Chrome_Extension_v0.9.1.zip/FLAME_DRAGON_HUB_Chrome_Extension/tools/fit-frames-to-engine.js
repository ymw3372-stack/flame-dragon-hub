#!/usr/bin/env node
/*
 * Rewrites frames-catalog.json so every state fits the engine's fixed number of animation slots.
 *
 * The game plays a fixed slot count per evolution+state, ping-pong (grimReaper idle = slots
 * 1..6 played as 1,2,3,4,5,6,5,4,3,2,1). The extension maps requested slot N to catalog[N-1].
 *
 * When a skin's artwork cycles over more frames than there are slots, the engine cuts the motion
 * short and the character never reaches the end of its animation.
 *
 * Such a state is thinned by dropping the frames that move the least (the artwork's near
 * duplicates) and always keeping the first and last frame of the cycle, so the motion still
 * covers its full range and the step sizes stay even. A state that already fits is left alone.
 *
 * Run: node tools/fit-frames-to-engine.js
 */
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const catalogPath = path.join(root, "frames-catalog.json");

// Animation slots the engine has, per evolution+state.
const SLOTS = {
  grimReaper: { idle: 6, flying: 5, attack: 8 },
  pumpkinGhost: { flying: 9, attack: 5 },
  ghostlyReaper: { flying: 17, attack: 16 },
  ghost: { flying: 7 }
};

// The frame at which each longer artwork's motion cycle ends, measured from the CDN by
// tools/measure-cycles.py. Absent means the whole list is already the cycle.
const CYCLES = JSON.parse(fs.readFileSync(path.join(__dirname, "animation-cycles.json"), "utf8"));

// Per-frame movement, measured the same way: the distance between each frame and the one before
// it. tools/measure-cycles.py writes these; without them a state is thinned evenly instead.
const MOTION = JSON.parse(fs.readFileSync(path.join(__dirname, "frame-motion.json"), "utf8"));

function thin(frames, count, motion) {
  // `motion[i]` is the movement between frame i and frame i+1. A frame matters when it moves a
  // lot both into and out of itself, so its importance is the sum of those two steps.
  const importance = frames.map((_, i) => {
    const inStep = i > 0 ? (motion?.[i - 1] ?? 0) : 0;
    const outStep = i < frames.length - 1 ? (motion?.[i] ?? 0) : 0;
    return inStep + outStep;
  });

  // Never drop the first or last frame of the cycle: they bound the motion. Drop the least
  // important of the rest until the list is down to the slot count.
  const drop = new Set();
  const interior = [];
  for (let i = 1; i < frames.length - 1; i++) interior.push(i);
  interior.sort((a, b) => importance[a] - importance[b]);
  for (const i of interior) {
    if (frames.length - drop.size <= count) break;
    drop.add(i);
  }
  return frames.filter((_, i) => !drop.has(i));
}

const catalog = JSON.parse(fs.readFileSync(catalogPath, "utf8"));
let changed = 0;
const report = [];

for (const [key, states] of Object.entries(catalog)) {
  const evolution = key.split("/")[0];
  const slots = SLOTS[evolution];
  if (!slots) continue;

  for (const [state, want] of Object.entries(slots)) {
    const frames = states[state];
    if (!Array.isArray(frames) || !frames.length) continue;

    const cycle = CYCLES[`${key}/${state}`];
    if (!cycle || cycle <= want) continue;      // already fits the slots

    const cycleFrames = frames.slice(0, cycle);
    const fitted = thin(cycleFrames, want, MOTION[`${key}/${state}`]);
    states[state] = fitted;
    changed++;
    report.push(`${key} / ${state}: cycle ${cycle} -> ${want} slots  ${JSON.stringify(cycleFrames)} => ${JSON.stringify(fitted)}`);
  }
}

fs.writeFileSync(catalogPath, JSON.stringify(catalog, null, 1) + "\n");
console.log(`states refitted: ${changed}`);
for (const line of report) console.log("  " + line);
