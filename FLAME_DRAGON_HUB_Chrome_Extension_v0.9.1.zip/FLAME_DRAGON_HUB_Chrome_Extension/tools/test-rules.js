#!/usr/bin/env node
/*
 * Tests the redirect rules background.js generates.
 *
 * The rules are evaluated the way Chrome evaluates them: every rule whose regexFilter matches is
 * a candidate, and the highest priority wins. This proves that the frame the game asks for is
 * always redirected to a frame the replacement skin really has, which is what stopped the
 * characters freezing.
 *
 * Run: node tools/test-rules.js
 */
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const source = fs.readFileSync(path.join(root, "background.js"), "utf8");

let failures = 0;
function check(label, actual, expected) {
  const ok = actual === expected;
  if (!ok) failures++;
  console.log(`${ok ? "PASS" : "FAIL"}  ${label}`);
  if (!ok) console.log(`        expected: ${expected}\n        actual:   ${actual}`);
}

// Minimal chrome stub. updateDynamicRules records the rules that would be installed.
// fetch returns the real frames-catalog.json so the rules use the true CDN frame counts.
const catalogJson = fs.readFileSync(path.join(root, "frames-catalog.json"), "utf8");
const petCatalogJson = fs.readFileSync(path.join(root, "pets-catalog.json"), "utf8");
let installed = [];
const sandbox = {
  console,
  URL,
  // background.js fetches both catalogs; serve the matching one for each request.
  fetch: url => Promise.resolve({
    ok: true,
    json: () => Promise.resolve(JSON.parse(String(url).includes("pets-catalog") ? petCatalogJson : catalogJson))
  }),
  setTimeout,
  chrome: {
    runtime: {
      getURL: p => p,
      onMessage: { addListener() {} },
      onInstalled: { addListener() {} }
    },
    storage: { local: { get: async () => ({}), set: async () => {} } },
    declarativeNetRequest: {
      updateDynamicRules: async ({ addRules }) => { installed = addRules || []; }
    }
  }
};
sandbox.self = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
// background.js is a classic service worker script; expose its helpers for the test.
vm.runInContext(source + "\n;globalThis.__bg = { buildRules, syncMappings, validateMappings, STATES, catalogReady };",
  sandbox);
const bg = sandbox.__bg;

// The rules depend on the catalog being loaded, so the checks run after it resolves.
async function main() {
await bg.catalogReady;

// Evaluate the rule set exactly as Chrome would.
function resolve(rules, url) {
  let winner = null;
  for (const rule of rules) {
    if (!new RegExp(rule.condition.regexFilter).test(url)) continue;
    if (!winner || rule.priority > winner.priority) winner = rule;
  }
  if (!winner) return null;
  // The substitution is the target URL because the filter has no capture groups.
  return winner.action.redirect.regexSubstitution;
}

const CDN = "https://cdn.eu.evoworld.io/sprites/characters";

console.log("--- grimReaper flying has 5 frames: the game asks for 6 or 7 ---");
let rules = bg.buildRules({ evolution: "grimReaper", sourceSkin: "black", skin: "purple" }, 70101);
check("flying 1 maps to purple flying 1",
  resolve(rules, `${CDN}/grimReaper/black/flying/1.png`), `${CDN}/grimReaper/purple/flying/1.png`);
check("flying 5 maps to purple flying 5",
  resolve(rules, `${CDN}/grimReaper/black/flying/5.png`), `${CDN}/grimReaper/purple/flying/5.png`);
check("flying 6 clamps to the last real frame (5)",
  resolve(rules, `${CDN}/grimReaper/black/flying/6.png`), `${CDN}/grimReaper/purple/flying/5.png`);
check("flying 7 clamps to the last real frame (5)",
  resolve(rules, `${CDN}/grimReaper/black/flying/7.png`), `${CDN}/grimReaper/purple/flying/5.png`);

console.log("--- grimReaper attack has 8 frames ---");
check("attack 8 maps to purple attack 8",
  resolve(rules, `${CDN}/grimReaper/black/attack/8.png`), `${CDN}/grimReaper/purple/attack/8.png`);
check("attack 12 clamps to attack 8",
  resolve(rules, `${CDN}/grimReaper/black/attack/12.png`), `${CDN}/grimReaper/purple/attack/8.png`);

console.log("--- a skin with no idle folder reuses a state it has ---");
rules = bg.buildRules({ evolution: "pumpkinGhost", sourceSkin: "standard", skin: "cool" }, 70101);
check("idle 3 falls back to cool flying 1",
  resolve(rules, `${CDN}/pumpkinGhost/standard/idle/3.png`), `${CDN}/pumpkinGhost/cool/flying/1.png`);
check("flying 17 clamps to cool flying 9 (its real last frame)",
  resolve(rules, `${CDN}/pumpkinGhost/standard/flying/17.png`), `${CDN}/pumpkinGhost/cool/flying/9.png`);
check("attack 5 maps to cool attack 5",
  resolve(rules, `${CDN}/pumpkinGhost/standard/attack/5.png`), `${CDN}/pumpkinGhost/cool/attack/5.png`);

console.log("--- ghostlyReaper attack has 16 frames ---");
rules = bg.buildRules({ evolution: "ghostlyReaper", sourceSkin: "standard", skin: "astronaut" }, 70101);
check("attack 16 maps to astronaut attack 16",
  resolve(rules, `${CDN}/ghostlyReaper/standard/attack/16.png`),
  `${CDN}/ghostlyReaper/astronaut/attack/16.png`);
check("attack 20 clamps to astronaut attack 16",
  resolve(rules, `${CDN}/ghostlyReaper/standard/attack/20.png`),
  `${CDN}/ghostlyReaper/astronaut/attack/16.png`);

console.log("--- pets live in their own namespace and play one flapping animation ---");
const PET_CDN = "https://cdn.eu.evoworld.io/sprites/pets";
rules = bg.buildRules({ evolution: "pets", sourceSkin: "1", skin: "22" }, 70101);
check("pet 1 frame 1 maps to pet 22 frame 1",
  resolve(rules, `${PET_CDN}/1/1.png`), `${PET_CDN}/22/1.png`);
check("pet 1 frame 8 maps to pet 22 frame 8",
  resolve(rules, `${PET_CDN}/1/8.png`), `${PET_CDN}/22/8.png`);
check("pet 1 frame 9 maps to pet 22 frame 9",
  resolve(rules, `${PET_CDN}/1/9.png`), `${PET_CDN}/22/9.png`);
check("pet 1 frame 11 clamps to pet 22 last frame (10)",
  resolve(rules, `${PET_CDN}/1/11.png`), `${PET_CDN}/22/10.png`);

console.log("--- a pet rule never matches a character and the reverse ---");
rules = bg.buildRules({ evolution: "pets", sourceSkin: "1", skin: "22" }, 70101);
check("a character URL is untouched by a pet rule",
  resolve(rules, `${CDN}/grimReaper/black/attack/1.png`), null);
rules = bg.buildRules({ evolution: "grimReaper", sourceSkin: "black", skin: "purple" }, 70101);
check("a pet URL is untouched by a character rule",
  resolve(rules, `${PET_CDN}/1/1.png`), null);

console.log("--- an unrelated skin is never touched ---");
rules = bg.buildRules({ evolution: "ghostlyReaper", sourceSkin: "standard", skin: "astronaut" }, 70101);
check("unmapped folder is not redirected",
  resolve(rules, `${CDN}/grimReaper/black/attack/1.png`), null);

console.log("--- rule ids are unique ---");
rules = bg.buildRules({ evolution: "grimReaper", sourceSkin: "black", skin: "purple" }, 70101);
const ids = rules.map(r => r.id);
check("no duplicate rule ids", new Set(ids).size, ids.length);

console.log("");
console.log(failures === 0 ? "ALL RULE TESTS PASSED" : `${failures} TEST(S) FAILED`);
process.exit(failures === 0 ? 0 : 1);
}

main();
