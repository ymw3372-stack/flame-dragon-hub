#!/usr/bin/env node
/*
 * Validates the extension before packaging.
 *
 * Run: node tools/validate.js
 */
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
let failures = 0;
const MAX_FRAME = 24;
const fail = m => { failures++; console.log("FAIL  " + m); };
const pass = m => console.log("PASS  " + m);

// 1. manifest.json
let manifest;
try {
  manifest = JSON.parse(fs.readFileSync(path.join(root, "manifest.json"), "utf8"));
  pass("manifest.json is valid JSON");
} catch (e) {
  fail("manifest.json is invalid JSON: " + e.message);
  process.exit(1);
}
if (manifest.manifest_version === 3) pass("manifest_version is 3");
else fail("manifest_version is not 3");

// 2. every file the manifest names exists
const referenced = new Set();
for (const cs of manifest.content_scripts || []) (cs.js || []).forEach(f => referenced.add(f));
for (const war of manifest.web_accessible_resources || []) (war.resources || []).forEach(f => referenced.add(f));
if (manifest.background?.service_worker) referenced.add(manifest.background.service_worker);
if (manifest.action?.default_popup) referenced.add(manifest.action.default_popup);
for (const icon of Object.values(manifest.icons || {})) referenced.add(icon);
for (const f of referenced) {
  if (fs.existsSync(path.join(root, f))) pass(`referenced file exists: ${f}`);
  else fail(`referenced file is missing: ${f}`);
}

// 3. every JS file parses
const jsFiles = ["background.js", "content.js", "page-bridge.js", "popup.js"];
for (const f of jsFiles) {
  try {
    new vm.Script(fs.readFileSync(path.join(root, f), "utf8"), { filename: f });
    pass(`${f} parses`);
  } catch (e) {
    fail(`${f} does not parse: ${e.message}`);
  }
}

// 4. catalogs are valid and consistent
const skins = JSON.parse(fs.readFileSync(path.join(root, "skins.json"), "utf8"));
const frames = JSON.parse(fs.readFileSync(path.join(root, "frames-catalog.json"), "utf8"));
if (Array.isArray(skins)) pass(`skins.json is an array of ${skins.length} skins`);
else fail("skins.json is not an array");

const seenKeys = new Set();
let dupes = 0;
for (const skin of skins) {
  const key = `${skin.evolution}/${skin.slug}`;
  if (seenKeys.has(key)) { dupes++; fail(`duplicate catalog entry: ${key}`); }
  seenKeys.add(key);
  if (!frames[key]) fail(`no frame catalog entry for ${key}`);
}
if (!dupes) pass("no duplicate catalog entries");

// 5. every frame URL is a real EvoWorld CDN URL
const FRAME_RE = /^https:\/\/cdn[0-9]*\.[a-z]+\.evoworld\.io\/sprites\/characters\/[^/]+\/[^/]+\/(idle|flying|attack)\/\d+\.png$/;
let badFrames = 0;
for (const [key, states] of Object.entries(frames)) {
  for (const [state, list] of Object.entries(states)) {
    if (!Array.isArray(list) || !list.length) { badFrames++; fail(`${key} ${state} is empty`); continue; }
    for (const n of list) {
      const url = `https://cdn.eu.evoworld.io/sprites/characters/${key}/${state}/${n}.png`;
      if (!FRAME_RE.test(url)) { badFrames++; fail(`bad frame url: ${url}`); }
    }
  }
}
if (!badFrames) pass("all frame URLs are well formed EvoWorld CDN URLs");

// 5b. The engine's slot count must be able to cover each state's real motion cycle.
// The engine plays exactly N slots (grimReaper idle 6, flying 5, attack 8), ping-pong, and maps
// requested slot N to catalog[N-1]. A list longer than N is fine when the artwork's cycle ends
// within N slots (the extra entries are the mirror tail the engine never requests). It is a
// defect when the cycle is longer than N: the tail of the motion is then never played and the
// character looks like it cuts off.
const SLOTS = {
  grimReaper: { idle: 6, flying: 5, attack: 8 },
  pumpkinGhost: { flying: 9, attack: 5 },
  ghostlyReaper: { flying: 17, attack: 16 },
  ghost: { flying: 7 }
};
const CYCLES = JSON.parse(fs.readFileSync(path.join(__dirname, "animation-cycles.json"), "utf8"));
let unfit = 0;
for (const [key, states] of Object.entries(frames)) {
  const evolution = key.split("/")[0];
  const slots = SLOTS[evolution];
  if (!slots) continue;
  for (const [state, list] of Object.entries(states)) {
    const want = slots[state];
    if (!want) { unfit++; fail(`${key} ${state} is not a state this evolution has`); continue; }
    // A list longer than the slot count is only acceptable when the artwork's own cycle ends
    // within the slots (the extra entries are the mirror tail the engine never requests).
    // A longer list whose cycle overruns the slots means the motion is cut off.
    if (list.length > want) {
      const cycle = CYCLES[`${key}/${state}`] ?? list.length;
      if (cycle > want) {
        unfit++;
        fail(`${key} ${state} cycles over ${cycle} frames but the engine plays only ${want}`);
      }
    }
    const ascending = list.every((n, i) => i === 0 || n > list[i - 1]);
    if (!ascending) { unfit++; fail(`${key} ${state} is not in ascending frame order: ${list}`); }
    if (list[list.length - 1] > MAX_FRAME) { unfit++; fail(`${key} ${state} frame beyond ${MAX_FRAME}`); }
  }
}
if (!unfit) pass("every state's motion cycle fits the engine's slot count");

// 6. the skin slugs that the popup offers must exist in the frame catalog
const animated = Object.values(frames).filter(v => Object.keys(v).length).length;
pass(`${animated}/${Object.keys(frames).length} skins have animation frames`);
const still = Object.entries(frames).filter(([, v]) => !Object.keys(v).length).map(([k]) => k);
if (still.length) {
  console.log("      (no frames on the CDN, these show as still sprites)");
  still.forEach(k => console.log("        - " + k));
}

// 7. pets are validated against their own namespace
const pets = JSON.parse(fs.readFileSync(path.join(root, "pets.json"), "utf8"));
const petFrames = JSON.parse(fs.readFileSync(path.join(root, "pets-catalog.json"), "utf8"));
if (Array.isArray(pets)) pass(`pets.json is an array of ${pets.length} pets`);
else fail("pets.json is not an array");

const petSlugs = new Set();
for (const pet of pets) {
  if (pet.evolution !== "pets") { fail(`pet entry ${pet.slug} is not in the pets evolution`); continue; }
  if (!/^\d{1,3}$/.test(pet.slug)) { fail(`pet entry ${pet.slug} is not a numeric pet id`); continue; }
  if (petSlugs.has(pet.slug)) fail(`duplicate pet entry: ${pet.slug}`);
  petSlugs.add(pet.slug);
  if (!petFrames[`pets/${pet.slug}`]) fail(`no pet frame catalog entry for pet ${pet.slug}`);
  if (!fs.existsSync(path.join(root, pet.image))) fail(`pet thumbnail is missing: ${pet.image}`);
}
if (petSlugs.size === pets.length) pass("every pet id is unique and has a frame list and thumbnail");

const PET_FRAME_RE = /^https:\/\/cdn[0-9]*\.[a-z]+\.evoworld\.io\/sprites\/pets\/\d+\/\d+\.png$/;
let badPetFrames = 0;
for (const [key, states] of Object.entries(petFrames)) {
  if (!/^pets\/\d+$/.test(key)) { badPetFrames++; fail(`pet catalog key is malformed: ${key}`); continue; }
  for (const [state, list] of Object.entries(states)) {
    if (state !== "flying") { badPetFrames++; fail(`pet ${key} has a state it does not have: ${state}`); continue; }
    if (!Array.isArray(list) || !list.length) { badPetFrames++; fail(`${key} ${state} is empty`); continue; }
    for (const n of list) {
      if (!PET_FRAME_RE.test(`https://cdn.eu.evoworld.io/sprites/pets/${key.split("/")[1]}/${n}.png`)) {
        badPetFrames++; fail(`bad pet frame: ${key} ${state} ${n}`);
      }
    }
  }
}
if (!badPetFrames) pass("all pet frame URLs are well formed EvoWorld CDN URLs");

console.log("");
console.log(failures === 0 ? "VALIDATION PASSED" : `VALIDATION FAILED (${failures} problem(s))`);
process.exit(failures === 0 ? 0 : 1);
