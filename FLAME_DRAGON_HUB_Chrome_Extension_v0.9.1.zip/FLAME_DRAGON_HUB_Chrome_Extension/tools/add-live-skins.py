#!/usr/bin/env python3
"""
Adds skins that exist in the live EvoWorld build but are missing from our catalog.

The catalog was built from an older copy of the game bundle. The live bundle at
https://evoworld.io/cdn/js/game_init.js now lists 22 more character skins across the four
evolutions we support. This script adds them: it scans the CDN for the frames each skin really
has, writes the thumbnail, and appends the entry to skins.json.

Frame scanning stops at the first missing frame so every state stays a contiguous 1..N run,
which is what the extension's slot mapping depends on.

Thumbnail convention (matches the existing artwork):
  * grimReaper / pumpkinGhost / ghostlyReaper: crop to the artwork's bounding box, scale to fit
    a 128x128 box, centre it on a transparent square.
  * ghost: scale to 128 px tall, keep the aspect ratio, no padding.

Usage:
    python3 tools/add-live-skins.py [--dry-run]
"""
import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO

from PIL import Image

BASE = "https://cdn.eu.evoworld.io/sprites/characters"
HEADERS = {"User-Agent": "Mozilla/5.0"}
MAX_FRAME = 24
BOX = 128
STATES = ("idle", "flying", "attack")

# evolution -> category folder / label / the display style its existing entries use.
# grimReaper and pumpkinGhost and ghostlyReaper use the raw slug as the label; ghost uses a
# capitalised, spaced label.
EVOLUTIONS = {
    "grimReaper": {"category": "grim-reaper", "label": "Grim Reaper", "title": "slug"},
    "pumpkinGhost": {"category": "pumpkin-ghost", "label": "Pumpkin Ghost", "title": "slug"},
    "ghostlyReaper": {"category": "ghostly-reaper", "label": "Ghostly Reaper", "title": "slug"},
    "ghost": {"category": "ghost", "label": "Halloween 2026", "title": "title"},
}

# Skins present in the live bundle that our catalog is missing.
NEW_SKINS = {
    "grimReaper": [
        "abyss", "azureKnight", "darkKnight", "failed", "halloween2026", "lion",
        "mysteriousKnight", "nightOwl", "nightWolf", "oppressed", "photon",
        "polarBearFroster", "skullExecutioner", "spectralViking",
    ],
    "pumpkinGhost": ["halloween2026", "halloween2026_quest", "headless_2"],
    "ghostlyReaper": ["evilRabbit", "halloween2026"],
    "ghost": ["halloween2026", "lunarPriestess", "pureSoul"],
}


def exists(url):
    request = urllib.request.Request(url, headers=HEADERS, method="HEAD")
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=25) as response:
                return response.status == 200
        except urllib.error.HTTPError as error:
            if error.code == 404:
                return False
        except Exception:
            pass
    # A network failure must not be read as "frame missing": that would truncate the catalog
    # and make the skin play the wrong poses.
    raise RuntimeError("Could not determine whether %s exists" % url)


def fetch(url):
    request = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(request, timeout=25) as response:
        return Image.open(BytesIO(response.read())).convert("RGBA")


def scan(evolution, slug):
    row = {}
    for state in STATES:
        frames = []
        for frame in range(1, MAX_FRAME + 1):
            if exists("%s/%s/%s/%s/%d.png" % (BASE, evolution, slug, state, frame)):
                frames.append(frame)
            else:
                break
        if frames:
            row[state] = frames
    return row


def make_thumbnail(evolution, slug, frames):
    """Uses the same source frame the existing thumbnails use: idle if present, else flying."""
    for state in ("idle", "flying", "attack"):
        if frames.get(state):
            source = fetch("%s/%s/%s/%s/%d.png" % (BASE, evolution, slug, state, frames[state][0]))
            break
    else:
        raise RuntimeError("%s/%s has no frames" % (evolution, slug))

    if evolution == "ghost":
        width = max(1, round(source.width * BOX / source.height))
        return source.resize((width, BOX), Image.LANCZOS)

    box = source.getbbox()
    cropped = source.crop(box) if box else source
    scale = min(BOX / cropped.width, BOX / cropped.height)
    resized = cropped.resize(
        (max(1, round(cropped.width * scale)), max(1, round(cropped.height * scale))),
        Image.LANCZOS,
    )
    canvas = Image.new("RGBA", (BOX, BOX), (0, 0, 0, 0))
    canvas.paste(resized, ((BOX - resized.width) // 2, (BOX - resized.height) // 2))
    return canvas


def title_for(slug):
    """headless_2 -> Headless 2, polarBearFroster -> Polar Bear Froster"""
    import re
    spaced = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", slug).replace("_", " ")
    return " ".join(word.capitalize() for word in spaced.split())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    catalog_path = os.path.join(root, "skins.json")
    frames_path = os.path.join(root, "frames-catalog.json")

    catalog = json.load(open(catalog_path))
    frames_catalog = json.load(open(frames_path))
    existing = {"%s/%s" % (entry["evolution"], entry["slug"]) for entry in catalog}

    tasks = [
        (evolution, slug)
        for evolution, slugs in NEW_SKINS.items()
        for slug in slugs
        if "%s/%s" % (evolution, slug) not in existing
    ]
    if not tasks:
        print("nothing to add: every live skin is already in the catalog")
        return

    with ThreadPoolExecutor(max_workers=6) as pool:
        scanned = list(pool.map(lambda t: (t[0], t[1], scan(t[0], t[1])), tasks))

    added = []
    for evolution, slug, frames in scanned:
        if not frames:
            print("SKIP %s/%s: no frames on the CDN" % (evolution, slug), file=sys.stderr)
            continue
        info = EVOLUTIONS[evolution]
        name = title_for(slug) if info["title"] == "title" else slug
        added.append({
            "id": "%s-%s.png" % (info["category"], slug),
            "category": info["category"],
            "categoryLabel": info["label"],
            "evolution": evolution,
            "name": name,
            "slug": slug,
            "image": "skins/%s/%s.png" % (info["category"], slug),
        })
        frames_catalog["%s/%s" % (evolution, slug)] = frames
        print("%-34s %s" % ("%s/%s" % (evolution, slug),
                            {state: len(nums) for state, nums in frames.items()}))

    if args.dry_run:
        print("\ndry run: %d skins would be added" % len(added))
        return

    catalog.extend(added)
    with open(catalog_path, "w") as handle:
        json.dump(catalog, handle, indent=1)
        handle.write("\n")
    with open(frames_path, "w") as handle:
        json.dump(frames_catalog, handle, indent=1, sort_keys=True)
        handle.write("\n")

    for entry in added:
        thumbnail = make_thumbnail(entry["evolution"], entry["slug"],
                                  frames_catalog["%s/%s" % (entry["evolution"], entry["slug"])])
        thumbnail.save(os.path.join(root, entry["image"]))

    print("\nadded %d skins to skins.json (total %d)" % (len(added), len(catalog)))
    print("added %d entries to frames-catalog.json" % len(added))


if __name__ == "__main__":
    main()
