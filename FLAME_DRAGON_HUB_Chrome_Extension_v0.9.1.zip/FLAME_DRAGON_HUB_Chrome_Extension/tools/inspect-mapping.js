#!/usr/bin/env node
/*
 * Prints the redirect rules generated for one mapping and the frame the game would actually see
 * for each request index, using the game's own ping-pong animation arrays.
 */
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const source = fs.readFileSync(path.join(root, "background.js"), "utf8");
const catalogJson = fs.readFileSync(path.join(root, "frames-catalog.json"), "utf8");

let installed = [];
const sandbox = {
  console,
  URL,
  fetch: () => Promise.resolve({ ok: true, json: () => Promise.resolve(JSON.parse(catalogJson)) }),
  setTimeout,
  chrome: {
    runtime: { getURL: p => p, onMessage: { addListener() {} }, onInstalled: { addListener() {} } },
    declarativeNetRequest: {
      updateDynamicRules: o => { installed = (o.addRules || []); return Promise.resolve(); },
      updateSessionRules: () => Promise.resolve(),
      getDynamicRules: () => Promise.resolve([])
    },
    storage: { local: { get: () => Promise.resolve({}), set: () => Promise.resolve() } }
  }
};
const vm = require("vm");
vm.createContext(sandbox);
vm.runInContext(source + "\nglobalThis.__sync = syncMappings; globalThis.__ready = catalogReady;", sandbox);

// The game's own sequences, read from shared.js.
const shared = fs.readFileSync("/tmp/shared.js", "utf8");
function gameSeq(evo, anim) {
  const i = shared.indexOf(`${evo}:{name:"${evo}"`);
  const seg = shared.slice(i, i + 3000);
  const m = seg.match(new RegExp(`${anim}:\\{sprites:\\[([^\\]]*)\\]`));
  return m ? [...m[1].matchAll(/"(\w+)_(\d+)_/g)].map(x => Number(x[2])) : [];
}

const EVO = process.argv[2] || "grimReaper";
const SLUG = process.argv[3] || "halloween2020";

(async () => {
  await sandbox.__ready;
  const res = await sandbox.__sync([{ id: "t", evolution: EVO, sourceSkin: "black", skin: SLUG }]);
  console.log(`mapping ${EVO}: black -> ${SLUG}`);
  console.log(`rules generated: ${res.rules}`);
  console.log();

  const catalog = JSON.parse(catalogJson)[`${EVO}/${SLUG}`];
  console.log("catalog frames:", JSON.stringify(catalog));
  console.log();

  // Which rule fires for each requested frame index?
  function resolve(state, idx) {
    const url = `https://cdn.eu.evoworld.io/sprites/characters/${EVO}/black/${state}/${idx}.png`;
    let best = null;
    for (const r of installed) {
      const re = new RegExp(r.condition.regexFilter);
      if (re.test(url)) {
        if (!best || r.priority > best.priority) best = r;
      }
    }
    if (!best) return null;
    const m = best.action.redirect.regexSubstitution;
    const num = Number(m.match(/\/(\d+)\.png$/)[1]);
    return { frame: num, priority: best.priority };
  }

  for (const [anim, state, count] of [["flapping", "flying", 8], ["flying", "idle", 11], ["attacking", "attack", 9]]) {
    const seq = gameSeq(EVO, anim + "_left");
    if (!seq.length) continue;
    const maxReq = Math.max(...seq);
    const shown = [];
    for (let i = 1; i <= maxReq; i++) {
      const r = resolve(state, i);
      shown.push(r ? r.frame : "MISS");
    }
    const played = seq.map(f => shown[f - 1]);
    const native = seq;
    const same = played.join() === native.join();
    console.log(`${anim} (${state}): game requests 1..${maxReq}`);
    console.log(`   game sequence : [${native.join(",")}]`);
    console.log(`   skin shows    : [${played.join(",")}]   ${same ? "MATCH" : "<-- DIFFERENT"}`);
    console.log();
  }
})();
