#!/usr/bin/env node
/*
 * Exercises page-bridge.js in a stubbed page world.
 *
 * Checks the behaviour the user asked for:
 *   - every frame of a skin resolves to that skin's own frame (no cross-skin leakage)
 *   - the frame number actually changes while the game walks through idle/flying/attack
 *   - a missing state (pumpkinGhost and ghostlyReaper have no idle folder) falls back
 *   - an out-of-range frame is clamped instead of returning a 404 URL
 *   - a custom image mapping is used for its own skin only
 *
 * Run: node tools/test-bridge.js
 */
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const source = fs.readFileSync(path.join(root, "page-bridge.js"), "utf8");

let failures = 0;
function check(label, actual, expected) {
  const ok = actual === expected;
  if (!ok) failures++;
  console.log(`${ok ? "PASS" : "FAIL"}  ${label}`);
  if (!ok) console.log(`        expected: ${expected}\n        actual:   ${actual}`);
}

function makeSandbox() {
  const listeners = {};
  const imgProto = {};
  Object.defineProperty(imgProto, "src", {
    configurable: true,
    enumerable: true,
    get() { return this._src; },
    set(v) { this._src = v; }
  });
  const elementProto = { setAttribute() {} };

  const sandbox = {
    console,
    URL,
    location: { href: "https://evoworld.io/" },
    HTMLImageElement: function HTMLImageElement() {},
    Element: function Element() {},
    document: { images: [] },
    window: {
      addEventListener(type, fn) { (listeners[type] ||= []).push(fn); },
      postMessage() {}
    }
  };
  sandbox.HTMLImageElement.prototype = imgProto;
  sandbox.Element.prototype = elementProto;
  sandbox.window.HTMLImageElement = sandbox.HTMLImageElement;
  sandbox.window.Element = sandbox.Element;
  vm.createContext(sandbox);
  vm.runInContext(source, sandbox);
  sandbox.__listeners = listeners;
  return sandbox;
}

const CDN = "https://cdn.eu.evoworld.io/sprites/characters";

function mappingFor(evolution, sourceSkin, frames, dataUrl = "") {
  return { evolution, sourceSkin, dataUrl, frames };
}

const black = mappingFor("grimReaper", "black", {
  idle: [1, 2, 3, 4, 5, 6].map(n => `${CDN}/grimReaper/black/idle/${n}.png`),
  flying: [1, 2, 3, 4, 5].map(n => `${CDN}/grimReaper/black/flying/${n}.png`),
  attack: [1, 2, 3, 4, 5, 6, 7, 8].map(n => `${CDN}/grimReaper/black/attack/${n}.png`)
});

const ghostly = mappingFor("ghostlyReaper", "standard", {
  flying: [1, 2, 3].map(n => `${CDN}/ghostlyReaper/standard/flying/${n}.png`),
  attack: [1, 2, 3].map(n => `${CDN}/ghostlyReaper/standard/attack/${n}.png`)
});

function deliver(sandbox, mappings) {
  const event = {
    source: sandbox.window,
    data: { type: "FDH_CUSTOM_SKIN_MAPPINGS", mappings }
  };
  for (const fn of sandbox.__listeners.message || []) fn(event);
}

const PET_CDN = "https://cdn.eu.evoworld.io/sprites/pets";
const pet = mappingFor("pets", "1", {
  flying: [1, 2, 3, 4, 5, 6, 7, 8].map(n => `${PET_CDN}/1/${n}.png`)
});

const sandbox = makeSandbox();
deliver(sandbox, [black, ghostly, pet]);
const bridge = sandbox.window.__FDH_BRIDGE__;

console.log("--- skin keeps its own frames ---");
check("grimReaper black idle frame 3",
  bridge.rewrite(`${CDN}/grimReaper/black/idle/3.png`),
  `${CDN}/grimReaper/black/idle/3.png`);
check("grimReaper black attack frame 7",
  bridge.rewrite(`${CDN}/grimReaper/black/attack/7.png`),
  `${CDN}/grimReaper/black/attack/7.png`);
check("ghostlyReaper standard attack frame 2",
  bridge.rewrite(`${CDN}/ghostlyReaper/standard/attack/2.png`),
  `${CDN}/ghostlyReaper/standard/attack/2.png`);

console.log("--- frames change during movement (the old freeze bug) ---");
const seen = new Set();
for (let frame = 1; frame <= 6; frame++) {
  seen.add(bridge.rewrite(`${CDN}/grimReaper/black/idle/${frame}.png`));
}
check("idle 1-6 produce six different images", seen.size, 6);

console.log("--- pets resolve in their own namespace ---");
check("pet 1 frame 4 stays on pet 1 frame 4",
  bridge.rewrite(`${PET_CDN}/1/4.png`), `${PET_CDN}/1/4.png`);
check("pet 1 frame 9 clamps to its last frame (8)",
  bridge.rewrite(`${PET_CDN}/1/9.png`), `${PET_CDN}/1/8.png`);
check("an unmapped pet id is not touched",
  bridge.rewrite(`${PET_CDN}/2/3.png`), `${PET_CDN}/2/3.png`);
check("a pet path is never read as a character folder",
  bridge.rewrite(`${CDN}/pets/1/flying/3.png`), `${CDN}/pets/1/flying/3.png`);

console.log("--- a skin that is not mapped is left alone ---");
check("unmapped pumpkinGhost untouched",
  bridge.rewrite(`${CDN}/pumpkinGhost/standard/flying/4.png`),
  `${CDN}/pumpkinGhost/standard/flying/4.png`);

console.log("--- missing state falls back instead of returning nothing ---");
const idleFallback = bridge.rewrite(`${CDN}/ghostlyReaper/standard/idle/5.png`);
check("ghostlyReaper has no idle folder, falls back to flying 1",
  idleFallback,
  `${CDN}/ghostlyReaper/standard/flying/1.png`);

console.log("--- out-of-range frame is clamped, not left as a 404 ---");
check("attack frame 12 on a 3-frame sequence clamps to frame 3",
  bridge.rewrite(`${CDN}/ghostlyReaper/standard/attack/12.png`),
  `${CDN}/ghostlyReaper/standard/attack/3.png`);

console.log("--- other CDN hosts are covered ---");
check("cdn.na host is rewritten",
  bridge.rewrite("https://cdn.na.evoworld.io/sprites/characters/grimReaper/black/attack/5.png"),
  `${CDN}/grimReaper/black/attack/5.png`);

console.log("--- custom image mapping stays inside its own skin ---");
const customSandbox = makeSandbox();
deliver(customSandbox, [
  mappingFor("grimReaper", "mummy", {}, "data:image/png;base64,AAAA"),
  black
]);
const customBridge = customSandbox.window.__FDH_BRIDGE__;
check("mummy gets the uploaded image",
  customBridge.rewrite(`${CDN}/grimReaper/mummy/attack/3.png`),
  "data:image/png;base64,AAAA");
check("black still gets its own frame",
  customBridge.rewrite(`${CDN}/grimReaper/black/attack/3.png`),
  `${CDN}/grimReaper/black/attack/3.png`);

console.log("--- untrusted frames are rejected ---");
const rejectSandbox = makeSandbox();
deliver(rejectSandbox, [mappingFor("grimReaper", "bee", {
  attack: ["https://evil.example.com/x.png", `${CDN}/grimReaper/bee/attack/2.png`]
})]);
check("foreign frame dropped, valid frame kept",
  rejectSandbox.window.__FDH_BRIDGE__.rewrite(`${CDN}/grimReaper/bee/attack/2.png`),
  `${CDN}/grimReaper/bee/attack/2.png`);

console.log("");
console.log(failures === 0 ? "ALL BRIDGE TESTS PASSED" : `${failures} TEST(S) FAILED`);
process.exit(failures === 0 ? 0 : 1);
