#!/usr/bin/env python3
"""
Regenerates pets-catalog.json from the live EvoWorld CDN.

Pets are not characters. The game keeps them in their own namespace and asks for
    https://cdn.eu.evoworld.io/sprites/pets/<pet id>/<frame>.png
There is no state folder (no idle/flying/attack) and no left/right folder: the pet's single
flapping animation is what the game plays, and it mirrors the sprites for the other direction.

The frame counts are not guessable. The game's own definition of each pet lists its sprite
sequence, for example pet_2 is [1,2,3,4,3,2] and pet_40 is 42 slots long. A pet therefore has
fewer artwork frames than the number of slots the game plays. The extension maps the frame the
game asks for onto the replacement's own sequence, so the catalog only has to record which
artwork frames exist, in order.

Usage:
    python3 tools/build-pet-catalog.py [--out pets-catalog.json]

Output shape (keyed the same way as the character catalog so the code can share lookups):
    { "pets/1": { "flying": [1,2,3,4,5,6,7,8] }, ... }
"""
import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request

BASE = "https://cdn.eu.evoworld.io/sprites/pets"
MAX_PET = 41
MAX_FRAME = 60
HEADERS = {"User-Agent": "Mozilla/5.0"}


def exists(url):
    request = urllib.request.Request(url, headers=HEADERS, method="HEAD")
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                return response.status == 200
        except urllib.error.HTTPError as error:
            if error.code == 404:
                return False
            time.sleep(0.3 * (attempt + 1))
        except Exception:
            time.sleep(0.3 * (attempt + 1))
    # A network failure must never be reported as a missing frame: that would truncate the
    # catalog and make the pet play the wrong poses.
    raise RuntimeError("Could not determine whether %s exists" % url)


def scan_pet(pet):
    frames = []
    for frame in range(1, MAX_FRAME + 1):
        if exists("%s/%d/%d.png" % (BASE, pet, frame)):
            frames.append(frame)
        else:
            break
    return frames


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="pets-catalog.json")
    args = parser.parse_args()

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    out_file = os.path.join(root, args.out)

    catalog = {}
    for pet in range(1, MAX_PET + 1):
        frames = scan_pet(pet)
        if not frames:
            print("pet %d has no frames on the CDN" % pet, file=sys.stderr)
            continue
        catalog["pets/%d" % pet] = {"flying": frames}
        print("pets/%-3d flying=%d frames %s" % (pet, len(frames), frames))

    with open(out_file, "w") as handle:
        json.dump(catalog, handle, indent=1, sort_keys=False)
        handle.write("\n")
    print("\nwrote %s with %d pets" % (out_file, len(catalog)))


if __name__ == "__main__":
    main()
