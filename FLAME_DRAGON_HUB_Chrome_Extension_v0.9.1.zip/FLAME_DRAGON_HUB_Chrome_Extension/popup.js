const $ = id => document.getElementById(id);
let catalog = [];
let evolution = "ghost";
let selectedItem = null;
let customDraft = null;
let showCustomOnly = false;
let customSkins = [];
let activeMappings = [];
let frameCatalog = {};
const evolutionLabel = {grimReaper:"Grim Reaper", pumpkinGhost:"Pumpkin Ghost", ghostlyReaper:"Ghostly Reaper", ghost:"Ghosts", pets:"Pets"};
const keys = ["fdhSettings","fdhMappings","fdhCustomSkins","fdhUiState"];

function itemsForCurrent() {
  return catalog.filter(x => x.evolution === evolution);
}
function uniqueBySlug(items) {
  const seen = new Set();
  return items.filter(x => {
    if (!x.slug || seen.has(x.slug)) return false;
    seen.add(x.slug); return true;
  });
}
function setStatus(s) { $("status").textContent = s; }
function itemImage(item) {
  if (item?.dataUrl) return item.dataUrl;
  if (item?.image && item.image.startsWith("data:")) return item.image;
  return item?.image ? chrome.runtime.getURL(item.image) : "";
}
function animationInfoFor(evolution, slug) {
  const states = frameCatalog?.[`${evolution}/${slug}`];
  const wanted = evolution === "pets" ? ["flying"] : ["idle","flying","attack"];
  const missing = [];
  const present = [];
  for (const state of wanted) {
    const numbers = states?.[state];
    if (Array.isArray(numbers) && numbers.length) present.push(`${state} ${numbers.length}`);
    else missing.push(state);
  }
  return { present, missing, hasAny: present.length > 0 };
}
function updateAnimationInfo() {
  const el = $("animationInfo");
  if (!el) return;
  const slug = $("replacement")?.value || "";
  if (slug.startsWith("custom:")) {
    el.textContent = "Custom skin: your image is shown as a still sprite. An animated GIF can animate.";
    return;
  }
  if (!slug) { el.textContent = ""; return; }
  const info = animationInfoFor(evolution, slug);
  if (!info.hasAny) {
    el.textContent = "No animation frames were found on the CDN for this skin, so it appears still.";
    return;
  }
  const parts = [];
  parts.push(`Frames available: ${info.present.join(", ")}`);
  if (info.missing.length) {
    parts.push(`Not on the CDN: ${info.missing.join(", ")} (the first available frame is reused)`);
  }
  el.textContent = parts.join(" · ");
}
function updateReplacementPreview() {
  const sourceSlug = $("sourceSkin")?.value || "";
  const replaceSlug = $("replacement")?.value || "";
  const sourceItem = catalog.find(x => x.slug === sourceSlug && x.evolution === evolution);
  const customId = replaceSlug.startsWith("custom:") ? replaceSlug.slice(7) : "";
  const customItem = customId ? customSkins.find(x => x.id === customId) : null;
  const replacementItem = customItem || catalog.find(x => x.slug === replaceSlug && x.evolution === evolution);
  const sourceImg = $("targetPreviewImage");
  const replacementImg = $("replacementPreviewImage");
  sourceImg.src = sourceItem ? itemImage(sourceItem) : "";
  replacementImg.src = replacementItem ? itemImage(replacementItem) : "";
  $("targetPreviewName").textContent = sourceItem ? sourceItem.name : "Choose original skin";
  $("replacementPreviewName").textContent = replacementItem ? replacementItem.name + (customItem ? " (custom)" : "") : "Choose replacement skin";
  updateAnimationInfo();
}
function setPreview(item, kind="Library skin") {
  if (!item) return;
  // The selected tile is now the visual preview; avoid the old oversized duplicate preview.
}
function fillSourceSkins(preferred) {
  const select = $("sourceSkin");
  const old = preferred || select.value;
  select.replaceChildren();
  const placeholder = new Option("Choose the original skin…", "");
  select.add(placeholder);
  const list = uniqueBySlug(itemsForCurrent()).sort((a,b)=>a.name.localeCompare(b.name));
  for (const item of list) select.add(new Option(item.name, item.slug));
  if (old && [...select.options].some(o=>o.value===old)) select.value=old;
}
function fillReplacementSelect(preferred) {
  const select=$("replacement"), old=preferred || select.value;
  select.replaceChildren();
  const list=uniqueBySlug(itemsForCurrent()).sort((a,b)=>a.name.localeCompare(b.name));
  select.add(new Option("Choose a replacement…",""));
  for (const item of list) select.add(new Option(item.name,item.slug));
  if (old && [...select.options].some(o=>o.value===old)) select.value=old;
  if (!select.value && list.length) select.value=list[0].slug;
}
function renderGrid() {
  const grid=$("skinGrid"), query=$("search").value.trim().toLowerCase();
  grid.replaceChildren();
  // Keep the gallery in one-to-one sync with the replacement dropdown.
  // Some skins ship as both PNG and WebP with the same folder slug; showing
  // both made the tile preview differ from the actual selected replacement.
  const baseItems = uniqueBySlug(itemsForCurrent());
  const items=baseItems
    .filter(x => (x.name||"").toLowerCase().includes(query) || (x.slug||"").toLowerCase().includes(query))
    .sort((a,b)=>(a.name||"").localeCompare(b.name||""));
  for (const item of items) {
    const btn=document.createElement("button");
    btn.type="button";
    btn.className="tile"+(selectedItem && selectedItem.id===item.id && selectedItem._custom===item._custom ? " selected":"");
    btn.title=item.name || item.slug;
    const img=document.createElement("img"); img.alt=""; img.loading="lazy"; img.src=itemImage(item);
    img.addEventListener("error",()=>{img.style.opacity=".25";});
    const label=document.createElement("span"); label.textContent=item.name || item.slug || "Custom skin";
    btn.append(img,label);
    btn.addEventListener("mouseenter",()=>setPreview(item,item._custom?"Custom skin":"Library skin"));
    btn.addEventListener("focus",()=>setPreview(item,item._custom?"Custom skin":"Library skin"));
    btn.addEventListener("mouseleave",()=>{ if(selectedItem) setPreview(selectedItem,selectedItem._custom?"Custom skin":"Library skin"); });
    btn.addEventListener("click",()=>{
      selectedItem=item;
      setPreview(item,item._custom?"Custom skin":"Library skin");
      renderGrid();
      const replacementValue = item._custom ? "custom:" + item.id : item.slug;
      if ((item._custom || item.evolution===evolution) && [...$("replacement").options].some(o=>o.value===replacementValue)) { $("replacement").value=replacementValue; }
      updateReplacementPreview();
      saveUiState();
    });
    grid.append(btn);
  }
  $("count").textContent = `${items.length} ${showCustomOnly?"custom skins":"skins shown"} · ${showCustomOnly?"saved locally":evolutionLabel[evolution]}`;
  if (!items.length) {
    const empty=document.createElement("div"); empty.className="small"; empty.textContent="No matching skins. Try another search or collection."; grid.append(empty);
  }
}
async function saveUiState() {
  await chrome.storage.local.set({fdhUiState:{evolution,showCustomOnly,selectedId:selectedItem?.id || null,selectedCustom:!!selectedItem?._custom}});
}
function message(type, settings) {
  return new Promise(resolve => chrome.runtime.sendMessage({type, settings}, response => {
    if (chrome.runtime.lastError) resolve({ok:false,error:chrome.runtime.lastError.message});
    else resolve(response || {ok:false,error:"No response from extension background."});
  }));
}
function switchEvolution(next) {
  evolution=next; showCustomOnly=false;
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.evolution===evolution));
  fillSourceSkins(); fillReplacementSelect();
  const first=itemsForCurrent()[0] || null;
  selectedItem=first;
  setPreview(first);
  renderGrid(); updateReplacementPreview(); saveUiState();
}
function displaySkinName(evo, slug) {
  const item = catalog.find(x => x.evolution === evo && x.slug === slug);
  return item?.name || slug || "Unknown skin";
}
function renderActiveMappings() {
  const root = $("activeSkins");
  root.replaceChildren();
  $("activeCount").textContent = `${activeMappings.length} active mapping${activeMappings.length===1?"":"s"} · up to 900`;
  if (!activeMappings.length) {
    const p=document.createElement("p"); p.className="small";
    p.textContent="No active skins yet. Choose an original folder and replacement, then add it.";
    root.append(p); return;
  }
  activeMappings.forEach((mapping,index)=>{
    const row=document.createElement("div"); row.className="active-mapping";
    const info=document.createElement("div"); info.className="mapping-info";
    const title=document.createElement("div"); title.className="mapping-title";
    const sourceName = displaySkinName(mapping.evolution, mapping.sourceSkin);
    const customReplacement = mapping.customId ? customSkins.find(x=>x.id===mapping.customId) : null;
    const replacementName = customReplacement?.name || displaySkinName(mapping.evolution, mapping.skin);
    title.textContent=`${evolutionLabel[mapping.evolution]||mapping.evolution}: ${sourceName} → ${replacementName}`;
    const sub=document.createElement("div"); sub.className="mapping-sub";
    sub.textContent=`${index+1}. Folder: ${mapping.sourceSkin} → ${customReplacement ? "Custom image" : mapping.skin}`;
    const visual=document.createElement("div"); visual.className="mapping-visual";
    const originalImg=document.createElement("img"); originalImg.alt="Original skin";
    const originalItem=catalog.find(x=>x.evolution===mapping.evolution && x.slug===mapping.sourceSkin); if(originalItem) originalImg.src=itemImage(originalItem);
    const arrow=document.createElement("span"); arrow.textContent="→"; arrow.style.color="var(--orange2)";
    const replacementImg=document.createElement("img"); replacementImg.alt="Replacement skin";
    const replacementItem=customReplacement || catalog.find(x=>x.evolution===mapping.evolution && x.slug===mapping.skin); if(replacementItem) replacementImg.src=itemImage(replacementItem);
    visual.append(originalImg,arrow,replacementImg);
    const remove=document.createElement("button"); remove.className="remove-mapping";
    remove.type="button"; remove.textContent="Remove";
    remove.title="Remove this mapping only";
    remove.addEventListener("click",async()=>{
      const next=activeMappings.filter((_,i)=>i!==index);
      await syncActiveMappings(next);
      setStatus("Removed this mapping only.");
    });
    info.append(title,sub); row.append(visual,info,remove); root.append(row);
  });
}
async function syncActiveMappings(next) {
  setStatus("Updating active skins…");
  const result=await new Promise(resolve=>chrome.runtime.sendMessage({type:"FDH_SYNC",mappings:next},response=>{
    if(chrome.runtime.lastError) resolve({ok:false,error:chrome.runtime.lastError.message});
    else resolve(response||{ok:false,error:"No response from background."});
  }));
  if(!result.ok) { setStatus(`Could not update active skins: ${result.error||"unknown error"}`); return false; }
  activeMappings=next;
  renderActiveMappings();
  const skipped=result.result?.skipped||[];
  if(skipped.length) setStatus(`Applied. These skins have no animation frames on the CDN and will appear still: ${skipped.join(", ")}`);
  return true;
}
function renderCustomList() {
  const root=$("customList"); root.replaceChildren();
  if (!customSkins.length) { const p=document.createElement("p");p.className="small";p.textContent="No saved custom skins yet. Upload an image and click Save.";root.append(p);return; }
  customSkins.forEach((item,index)=>{
    const row=document.createElement("div");row.className="bundle-preview";
    const img=document.createElement("img");img.src=item.dataUrl;img.alt="";
    const info=document.createElement("div");
    const title=document.createElement("div");title.className="skin-title";title.textContent=item.name;
    const actions=document.createElement("div");actions.className="custom-row-actions";
    const use=document.createElement("button");use.className="btn";use.textContent="Use";use.title="Use this custom skin as the replacement";
    use.addEventListener("click",()=>{
      selectedItem={...item,_custom:true}; showCustomOnly=true; $("search").value="";
      $("customPreview").src=item.dataUrl; $("customName").textContent=item.name; $("customNameInput").value=item.name;
      fillReplacementSelect("custom:"+item.id); $("replacement").value="custom:"+item.id;
      renderGrid(); updateReplacementPreview(); saveUiState();
      $("skinGrid").scrollIntoView({behavior:"smooth",block:"start"});
      $("sourceSkin").focus();
      setStatus(`“${item.name}” is now selected as the replacement. Choose the original skin folder above, then click Add / Update.`);
    });
    const del=document.createElement("button");del.className="btn danger";del.textContent="Delete";
    del.addEventListener("click",async()=>{customSkins.splice(index,1);await chrome.storage.local.set({fdhCustomSkins:customSkins});if(selectedItem?._custom&&selectedItem.id===item.id)selectedItem=null;fillReplacementSelect();renderCustomList();renderGrid();updateReplacementPreview();setStatus("Custom skin deleted from local storage.");});
    actions.append(use,del);info.append(title,actions);row.append(img,info);root.append(row);
  });
}
function readFileAsDataURL(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(new Error("Could not read image: "+file.name));reader.readAsDataURL(file);});}
function previewCustomDraft(draft, message){
  customDraft=draft; $("customNameInput").value=draft.name; $("customPreview").src=draft.dataUrl;
  $("customName").textContent=draft.name; $("replacementPreviewImage").src=draft.dataUrl;
  $("replacementPreviewName").textContent=draft.name+" (custom)";
  $("saveCustom").disabled=false; setPreview({...draft,id:"upload-preview",_custom:true},"Custom upload preview");
  selectedItem={...draft,id:"upload-preview",_custom:true}; renderGrid(); saveUiState(); setStatus(message);
}
$("customFile").addEventListener("change",async()=>{
  const file=$("customFile").files?.[0]; if(!file)return;
  const ext=(file.name.split(".").pop()||"").toLowerCase();
  const allowed=/^image\/(png|jpeg|webp|gif)$/.test(file.type)||["png","jpg","jpeg","webp","gif"].includes(ext);
  if(!allowed){setStatus("Please choose a PNG, JPG, WebP, or GIF image.");return;}
  if(file.size>5*1024*1024){setStatus("Image is too large. Choose an image under 5 MB.");return;}
  try {
    const dataUrl=await readFileAsDataURL(file);
    // Verify that Chrome can decode the selected Desktop image before enabling Save.
    await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve();img.onerror=()=>reject(new Error("Image format could not be decoded. Try saving it as PNG or JPG."));img.src=dataUrl;});
    const name=$("customNameInput").value.trim()||file.name.replace(/\.[^.]+$/,"");
    const type=file.type||({jpg:"image/jpeg",jpeg:"image/jpeg",png:"image/png",webp:"image/webp",gif:"image/gif"}[ext]||"image/png");
    previewCustomDraft({name,dataUrl,type},"Image preview loaded. A still image will not animate by itself; click Save custom skin.");
  } catch(e){setStatus(e.message||"Could not read this image.");}
});

// Library skins keep their native frames; the page bridge reads them from frames-catalog.json.

$("customNameInput").addEventListener("input",()=>{
  if(!customDraft)return;
  const name=$("customNameInput").value.trim() || "Unnamed custom skin";
  customDraft.name=name; $("customName").textContent=name;
  $("replacementPreviewName").textContent=name+" (custom)";
});
$("clearCustomDraft").addEventListener("click",()=>{
  customDraft=null; $("customFile").value=""; if($("framesStatus"))$("framesStatus").textContent="Library skins keep their own animation. An uploaded image is shown as a still sprite unless it is an animated GIF."; $("customNameInput").value=""; $("customPreview").removeAttribute("src"); $("customName").textContent="No custom skin selected"; $("saveCustom").disabled=true;
  setStatus("Current custom preview cleared.");
});
$("saveCustom").addEventListener("click",async()=>{
  if(!customDraft)return;
  customDraft.name=$("customNameInput").value.trim() || customDraft.name || "Custom skin";
  const existing=customSkins.findIndex(x=>x.name===customDraft.name && x.type===customDraft.type);
  const id=existing>=0?customSkins[existing].id:("custom-"+Date.now()+"-"+Math.random().toString(36).slice(2,7));
  const saved={id,name:customDraft.name,dataUrl:customDraft.dataUrl,type:customDraft.type,...(customDraft.frames?{frames:customDraft.frames}:{}),createdAt:Date.now()};
  if(existing>=0) customSkins[existing]=saved; else customSkins.push(saved);
  try{await chrome.storage.local.set({fdhCustomSkins:customSkins});selectedItem={...saved,_custom:true};fillReplacementSelect("custom:"+saved.id);renderCustomList();renderGrid();setPreview(selectedItem,"Custom skin");updateReplacementPreview();setStatus("Custom skin saved locally. Press Use on its card to select it for replacement.");$("saveCustom").disabled=true;customDraft=null;}
  catch(e){setStatus("Could not save custom skin. Browser storage may be full.");}
});
$("search").addEventListener("input",renderGrid);
$("showAll").addEventListener("click",()=>{showCustomOnly=false;renderGrid();});
$("showCustom").addEventListener("click",()=>{showCustomOnly=true;renderGrid();});
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>switchEvolution(b.dataset.evolution)));
$("sourceSkin").addEventListener("change",()=>{updateReplacementPreview();saveUiState();});
$("replacement").addEventListener("change",()=>{
  const value=$("replacement").value;
  const item=value.startsWith("custom:") ? customSkins.find(x=>x.id===value.slice(7)) : itemsForCurrent().find(x=>x.slug===value);
  if(item){selectedItem={...item,...(value.startsWith("custom:")?{_custom:true}:{})};setPreview(selectedItem);showCustomOnly=!!selectedItem._custom;renderGrid();}
  updateReplacementPreview(); saveUiState();
});
$("apply").addEventListener("click",async()=>{
  const sourceSkin=$("sourceSkin").value, replacementValue=$("replacement").value;
  if(!sourceSkin||!replacementValue){setStatus("Choose both the original skin folder and a replacement first.");return;}
  const isCustom=replacementValue.startsWith("custom:");
  const customId=isCustom?replacementValue.slice(7):null;
  const customItem=isCustom?customSkins.find(x=>x.id===customId):null;
  if(isCustom&&!customItem){setStatus("That custom skin was not found. Press Use again.");return;}
  const skin=isCustom?("custom-"+customId):replacementValue;
  const key=`${evolution}::${sourceSkin}`;
  const next=activeMappings.filter(x=>`${x.evolution}::${x.sourceSkin}`!==key);
  if(next.length>=900){setStatus("You reached the safe limit of 900 active mappings. Remove one before adding another.");return;}
  next.push({id:`${evolution}-${sourceSkin}`,evolution,sourceSkin,skin,...(isCustom?{customId}: {})});
  const ok=await syncActiveMappings(next);
  if(ok) setStatus(isCustom ? `Custom image “${customItem.name}” assigned to ${sourceSkin}. Your image is now the sprite for that skin; a still image stays still, an animated GIF can animate. Reload EvoWorld to test.` : evolution==="pets" ? `Active: pet ${sourceSkin} → pet ${skin}. This pet keeps its own flapping animation. Reload EvoWorld to test. Other active mappings were kept.` : `Active: ${sourceSkin} → ${skin}. This skin keeps its own idle/flying/attack frames. Reload EvoWorld to test. Other active mappings were kept.`);
});
$("reset").addEventListener("click",async()=>{
  const ok=await syncActiveMappings([]);
  if(ok) setStatus("All active replacements removed. Reload EvoWorld to restore original sprites.");
});
(async()=>{
  try{
    const response=await fetch(chrome.runtime.getURL("skins.json"));
    if(!response.ok)throw new Error("Skin catalog file not found.");
    catalog=await response.json();
    if(!Array.isArray(catalog))throw new Error("Skin catalog format is invalid.");
    catalog=catalog.filter(x=>x && x.slug && x.evolution && x.image);
    // Pets are a separate list with their own CDN namespace, so they load separately and are
    // appended to the same catalog. A failure here must not stop the characters from loading.
    try {
      const petsResponse=await fetch(chrome.runtime.getURL("pets.json"));
      if(petsResponse.ok){
        const pets=await petsResponse.json();
        if(Array.isArray(pets))catalog=catalog.concat(pets.filter(x=>x && x.slug && x.evolution && x.image));
      }
    } catch {}
    try {
      const framesResponse = await fetch(chrome.runtime.getURL("frames-catalog.json"));
      if (framesResponse.ok) {
        const data = await framesResponse.json();
        if (data && typeof data === "object") frameCatalog = data;
      }
    } catch { frameCatalog = {}; }
    try {
      const petFramesResponse = await fetch(chrome.runtime.getURL("pets-catalog.json"));
      if (petFramesResponse.ok) {
        const data = await petFramesResponse.json();
        if (data && typeof data === "object") frameCatalog = Object.assign(frameCatalog, data);
      }
    } catch {}
    const stored=await chrome.storage.local.get(keys);
    customSkins=Array.isArray(stored.fdhCustomSkins)?stored.fdhCustomSkins:[];
    renderCustomList();
    const ui=stored.fdhUiState||{};
    const settings=stored.fdhSettings||{};
    activeMappings=Array.isArray(stored.fdhMappings)?stored.fdhMappings:(Array.isArray(settings.mappings)?settings.mappings:(settings.enabled&&settings.evolution&&settings.sourceSkin&&settings.skin?[{id:"legacy",evolution:settings.evolution,sourceSkin:settings.sourceSkin,skin:settings.skin}]:[]));
    renderActiveMappings();
    evolution=ui.evolution||settings.evolution||"ghost";
    if(!evolutionLabel[evolution])evolution="ghostlyReaper";
    document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.evolution===evolution));
    showCustomOnly=!!ui.showCustomOnly;
    fillSourceSkins(settings.sourceSkin);
    fillReplacementSelect(settings.skin || (settings.customId ? "custom:"+settings.customId : undefined));
    let selected=catalog.find(x=>x.id===ui.selectedId);
    if(ui.selectedCustom){const found=customSkins.find(x=>x.id===ui.selectedId);if(found)selected={...found,_custom:true};}
    selectedItem=selected||itemsForCurrent()[0]||null;
    if(selectedItem)setPreview(selectedItem,selectedItem.dataUrl?"Custom skin":"Library skin");
    renderGrid();
    if(ui.selectedCustom && selectedItem?._custom) { fillReplacementSelect("custom:"+selectedItem.id); $("replacement").value="custom:"+selectedItem.id; }
    updateReplacementPreview();
    setStatus(`${catalog.length} bundled skin files loaded · ${activeMappings.length} active mappings.`);
  }catch(e){setStatus(`Could not load skin catalog: ${e.message}`);}
})();
