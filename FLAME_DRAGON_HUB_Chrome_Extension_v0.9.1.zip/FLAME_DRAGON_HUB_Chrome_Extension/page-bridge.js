// Page-world bridge: redirects real EvoWorld sprite requests to the frames the user selected.
//
// Two problems in the previous version are fixed here:
//   1. The frame index was read with /(\\d+)/ instead of /(\d+)/, so every request was
//      treated as frame 1. The game therefore received the same image for all frames and
//      the character looked frozen.
//   2. A single hard-coded Purple Grim Reaper sequence was returned for every custom skin,
//      which replaced each skin's artwork. Frames now come from the mapping itself, so a
//      skin only ever receives its own frames.
(() => {
  let mappings = [];
  const originalUrls = new WeakMap();
  const originalSetAttribute = Element.prototype.setAttribute;
  const imageSrcDescriptor = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, "src");

  const stats = { rewrites: 0, missingFrames: 0, lastState: null };

  const CDN_HOST = /^cdn[0-9]*\.[a-z]+\.evoworld\.io$/;
  const STATE_ORDER = ["idle", "flying", "attack"];
  const PET_STATE = "flying";

  function frameList(mapping, state) {
    const frames = mapping?.frames;
    if (!frames || typeof frames !== "object") return null;
    const list = frames[state];
    return Array.isArray(list) && list.length ? list : null;
  }

  // A state may be missing on the CDN (for example ghostlyReaper and pumpkinGhost have no
  // idle folder). Reuse the first frame of a state that does exist so the character keeps
  // moving instead of being left on a blank sprite. The requested frame number is meaningless
  // in a different state's sequence, so the first frame is used.
  function resolveFrame(mapping, state, frameNumber) {
    let list = frameList(mapping, state);
    let index = Math.min(Math.max(frameNumber, 1), list ? list.length : 1) - 1;
    if (!list) {
      for (const fallback of STATE_ORDER) {
        list = frameList(mapping, fallback);
        if (list) break;
      }
      if (list) { stats.missingFrames++; index = 0; }
    }
    if (!list) return null;
    const frame = list[Math.min(index, list.length - 1)];
    return typeof frame === "string" && frame ? frame : null;
  }

  function rewrite(value) {
    if (typeof value !== "string" || !value) return value;
    if (value.startsWith("data:")) return value;
    let url;
    try { url = new URL(value, location.href); } catch { return value; }
    if (!CDN_HOST.test(url.hostname)) return value;

    const parts = url.pathname.split("/");
    // Pets have their own namespace and no state folder:
    //   /sprites/pets/{pet id}/{number}.png
    if (parts.length >= 5 && parts[1] === "sprites" && parts[2] === "pets") {
      const petId = parts[3];
      const mapping = mappings.find(m => m.evolution === "pets" && m.sourceSkin === petId);
      if (!mapping) return value;
      const frameNumber = Number((String(parts[4] || "").match(/(\d+)/) || [])[1] || 1);
      stats.lastState = PET_STATE;
      const frame = resolveFrame(mapping, PET_STATE, frameNumber);
      if (frame) { stats.rewrites++; return frame; }
      return mapping.dataUrl || value;
    }

    // /sprites/characters/{evolution}/{sourceSkin}/{state}/{number}.png
    if (parts.length < 7 || parts[1] !== "sprites" || parts[2] !== "characters") return value;

    const evolution = parts[3], sourceSkin = parts[4];
    // "pets" is reserved for the pet namespace, so it can never name a character evolution.
    // Without this guard a character URL like /sprites/characters/pets/1/flying/3.png would be
    // read as pet 1 and rewritten to a pet sprite.
    if (evolution === "pets") return value;
    const mapping = mappings.find(m => m.evolution === evolution && m.sourceSkin === sourceSkin);
    if (!mapping) return value;

    const state = parts[5] || "idle";
    const filename = parts[6] || "1.png";
    const frameNumber = Number((filename.match(/(\d+)/) || [])[1] || 1);

    stats.lastState = state;
    const frame = resolveFrame(mapping, state, frameNumber);
    if (frame) { stats.rewrites++; return frame; }
    return mapping.dataUrl || value;
  }

  function remember(img, raw, next) {
    if (next !== raw) originalUrls.set(img, raw);
    else if (!raw.startsWith("data:")) originalUrls.delete(img);
  }

  if (imageSrcDescriptor?.get && imageSrcDescriptor?.set) {
    Object.defineProperty(HTMLImageElement.prototype, "src", {
      configurable: true,
      enumerable: imageSrcDescriptor.enumerable,
      get: imageSrcDescriptor.get,
      set(value) {
        const raw = String(value), next = rewrite(raw);
        remember(this, raw, next);
        imageSrcDescriptor.set.call(this, next);
      }
    });
  }

  Element.prototype.setAttribute = function (name, value) {
    if (this instanceof HTMLImageElement && String(name).toLowerCase() === "src") {
      const raw = String(value), next = rewrite(raw);
      remember(this, raw, next);
      return originalSetAttribute.call(this, name, next);
    }
    return originalSetAttribute.call(this, name, value);
  };

  function applyToExistingImages() {
    for (const img of document.images) {
      const current = img.getAttribute("src") || img.src;
      const base = originalUrls.get(img) || current;
      const replacement = rewrite(base);
      if (replacement && replacement !== current) img.src = replacement;
      if (replacement === base && originalUrls.has(img)) originalUrls.delete(img);
    }
  }

  function isTrustedFrame(frame) {
    if (typeof frame !== "string" || !frame) return false;
    if (/^data:image\/(png|jpeg|webp|gif);base64,/.test(frame)) return true;
    try {
      const u = new URL(frame);
      if (u.protocol !== "https:" || !CDN_HOST.test(u.hostname)) return false;
      // Character frame: /sprites/characters/{evolution}/{skin}/{state}/{n}.png
      if (/^\/sprites\/characters\/[^/]+\/[^/]+\/(idle|flying|attack)\/\d+\.png$/.test(u.pathname)) return true;
      // Pet frame: /sprites/pets/{id}/{n}.png
      return /^\/sprites\/pets\/\d+\/\d+\.png$/.test(u.pathname);
    } catch { return false; }
  }

  function sanitizeFrames(frames) {
    if (!frames || typeof frames !== "object") return undefined;
    const clean = {};
    for (const state of STATE_ORDER) {
      const list = frames[state];
      if (!Array.isArray(list)) continue;
      const valid = list.filter(isTrustedFrame);
      if (valid.length) clean[state] = valid;
    }
    return Object.keys(clean).length ? clean : undefined;
  }

  window.addEventListener("message", event => {
    if (event.source !== window) return;
    if (event.data?.type !== "FDH_CUSTOM_SKIN_MAPPINGS") return;
    if (!Array.isArray(event.data.mappings)) return;

    mappings = event.data.mappings
      .filter(m => typeof m?.evolution === "string" && typeof m?.sourceSkin === "string")
      .map(m => ({
        evolution: m.evolution,
        sourceSkin: m.sourceSkin,
        dataUrl: typeof m.dataUrl === "string" && /^data:image\//.test(m.dataUrl) ? m.dataUrl : "",
        frames: sanitizeFrames(m.frames)
      }))
      .filter(m => m.dataUrl || m.frames);

    console.info(`[FLAME DRAGON HUB] ${mappings.length} active mapping(s) applied.`);
    applyToExistingImages();
  });

  // Read-only diagnostics so a live session can be checked from the console:
  //   __FDH_BRIDGE__.stats    -> how many sprite requests were rewritten
  //   __FDH_BRIDGE__.mappings -> the mappings currently in effect
  window.__FDH_BRIDGE__ = {
    get mappings() { return mappings; },
    get stats() { return { ...stats }; },
    rewrite
  };
})();
