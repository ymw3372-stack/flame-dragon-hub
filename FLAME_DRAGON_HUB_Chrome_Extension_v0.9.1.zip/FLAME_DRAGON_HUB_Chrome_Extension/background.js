// Builds the declarativeNetRequest rules that point one EvoWorld skin folder at another.
//
// Why this version exists
//   The previous rule copied the requested frame number straight onto the replacement:
//
//     /characters/grimReaper/black/flying/6.png  ->  .../{replacement}/flying/6.png
//
//   Skins do not all have the same number of frames. grimReaper flying has 5 frames, pumpkinGhost
//   flying has 9 or 17, ghostlyReaper attack has 16, pumpkinGhost attack has 5. So the game asked
//   for frames the replacement does not have, the request 404'd, and the character froze on
//   screen. Two of the evolutions have no idle folder at all, which froze the idle animation too.
//
// How it works now
//   The real frame numbers of every skin are read from frames-catalog.json, which is generated
//   from the live CDN by tools/build-frame-catalog.js. For each mapping the rules are:
//
//     * one exact rule per frame the replacement actually has (priority 2)
//     * one catch-all rule per animation state (priority 1) that maps any frame beyond the
//       replacement's range onto its last frame, so the request always resolves
//     * for a state the replacement does not have (no idle folder), a catch-all rule that maps
//       onto the first frame of a state it does have
//
//   Chrome picks the highest priority match, so an exact frame always beats the catch-all.
const FIRST_RULE_ID = 70101;
const MAX_RULES = 4800; // inside Chrome's dynamic rule budget
// Pets live in their own CDN namespace, /sprites/pets/<id>/<frame>.png. There is no state folder
// and no left/right folder: the game plays one flapping animation and mirrors it. The pet is
// therefore modelled as an evolution with a single state.
const PET_EVOLUTION = "pets";
const CHARACTER_STATES = ["idle", "flying", "attack"];
const PET_STATES = ["flying"];
const EVOLUTIONS = new Set(["grimReaper", "pumpkinGhost", "ghostlyReaper", "ghost", PET_EVOLUTION]);
const STATES = CHARACTER_STATES;

function statesFor(evolution) {
  return evolution === PET_EVOLUTION ? PET_STATES : CHARACTER_STATES;
}

let frameCatalog = {};
// The two catalogs are generated separately (characters from tools/build-frame-catalog.js, pets
// from tools/build-pet-catalog.py) and merged here, so regenerating one never drops the other.
const catalogReady = Promise.all([
  fetch(chrome.runtime.getURL("frames-catalog.json")).then(r => r.ok ? r.json() : {}).catch(() => ({})),
  fetch(chrome.runtime.getURL("pets-catalog.json")).then(r => r.ok ? r.json() : {}).catch(() => ({}))
]).then(([characters, pets]) => {
  frameCatalog = {
    ...(characters && typeof characters === "object" ? characters : {}),
    ...(pets && typeof pets === "object" ? pets : {})
  };
  return frameCatalog;
}).catch(() => ({}));

function validSlug(s) {
  return typeof s === "string" && /^[A-Za-z0-9 _-]{1,60}$/.test(s) && s.trim() === s;
}

function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function framesOf(evolution, skin, state) {
  const list = frameCatalog?.[`${evolution}/${skin}`]?.[state];
  return Array.isArray(list) && list.length ? list : null;
}

function frameUrl(evolution, skin, state, number) {
  if (evolution === PET_EVOLUTION) {
    return `https://cdn.eu.evoworld.io/sprites/pets/${skin}/${number}.png`;
  }
  return `https://cdn.eu.evoworld.io/sprites/characters/${evolution}/${skin}/${state}/${number}.png`;
}

function redirectRule(id, evolution, sourceSkin, state, framePattern, targetUrl, priority) {
  const path = evolution === PET_EVOLUTION
    ? `^https://cdn[0-9]*\\.[a-z]+\\.evoworld\\.io/sprites/pets/${escapeRegex(sourceSkin)}/`
    : `^https://cdn[0-9]*\\.[a-z]+\\.evoworld\\.io/sprites/characters/` +
      `${escapeRegex(evolution)}/${escapeRegex(sourceSkin)}/${state}/`;
  return {
    id,
    priority,
    action: { type: "redirect", redirect: { regexSubstitution: targetUrl } },
    condition: {
      regexFilter: `${path}${framePattern}\\.png(?:\\?.*)?$`,
      resourceTypes: ["image"]
    }
  };
}

function buildRules(mapping, startId) {
  const { evolution, sourceSkin, skin } = mapping;
  const rules = [];
  let id = startId;
  const states = statesFor(evolution);

  // A state the replacement does not have falls back to the first frame of a state it does.
  const fallbackState = states.find(state => framesOf(evolution, skin, state));

  for (const state of states) {
    const frames = framesOf(evolution, skin, state);
    if (frames) {
      frames.forEach((number, index) => {
        rules.push(redirectRule(
          id++, evolution, sourceSkin, state, String(index + 1),
          frameUrl(evolution, skin, state, number), 2
        ));
      });
      rules.push(redirectRule(
        id++, evolution, sourceSkin, state, "\\d+",
        frameUrl(evolution, skin, state, frames[frames.length - 1]), 1
      ));
    } else if (fallbackState) {
      rules.push(redirectRule(
        id++, evolution, sourceSkin, state, "\\d+",
        frameUrl(evolution, skin, fallbackState, framesOf(evolution, skin, fallbackState)[0]), 1
      ));
    }
  }
  return rules;
}

function normalizeMappings(settings) {
  if (Array.isArray(settings?.mappings)) return settings.mappings;
  if (settings?.enabled && settings.evolution && settings.sourceSkin && settings.skin) {
    return [{
      id: "legacy-" + settings.evolution + "-" + settings.sourceSkin,
      evolution: settings.evolution,
      sourceSkin: settings.sourceSkin,
      skin: settings.skin
    }];
  }
  return [];
}

function validateMappings(mappings) {
  if (!Array.isArray(mappings)) throw new Error("Mappings list is invalid.");
  const seen = new Set();
  mappings.forEach((item, index) => {
    const evolution = item?.evolution, sourceSkin = item?.sourceSkin, skin = item?.skin;
    if (!EVOLUTIONS.has(evolution) || !validSlug(sourceSkin) || !validSlug(skin)) {
      throw new Error(`Mapping ${index + 1} has an invalid evolution or skin folder name.`);
    }
    // A pet id is the numeric folder name, and a pet is only ever a pet. Mixing the two
    // namespaces would build a rule that matches nothing.
    if (evolution === PET_EVOLUTION) {
      if (!/^\d{1,3}$/.test(sourceSkin) || !/^\d{1,3}$/.test(skin)) {
        throw new Error(`Mapping ${index + 1} uses a pet id that is not a number.`);
      }
    }
    // One replacement per original folder per evolution. A duplicate would silently replace the
    // earlier entry, so it is rejected instead of overwriting it.
    const key = `${evolution}::${sourceSkin}`;
    if (seen.has(key)) {
      throw new Error(`The original folder "${sourceSkin}" is already mapped for this evolution. Remove it first to avoid conflicts.`);
    }
    seen.add(key);
  });
}

async function syncMappings(mappings) {
  await catalogReady;
  validateMappings(mappings);

  const rules = [];
  const skipped = [];
  for (const mapping of mappings) {
    // A chrome.storage data URL cannot be a redirect target, so page-bridge.js handles custom
    // images in the page world instead.
    if (mapping.customId) continue;
    if (!statesFor(mapping.evolution).some(state => framesOf(mapping.evolution, mapping.skin, state))) {
      skipped.push(`${mapping.evolution}/${mapping.skin}`);
      continue;
    }
    rules.push(...buildRules(mapping, FIRST_RULE_ID + rules.length));
  }

  if (rules.length > MAX_RULES) {
    throw new Error(`This selection needs ${rules.length} redirect rules, above the safe limit of ${MAX_RULES}. Reduce the number of active skins.`);
  }

  const removeRuleIds = Array.from({ length: MAX_RULES }, (_, i) => FIRST_RULE_ID + i);
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules: rules });
  return { enabled: rules.length > 0, rules: rules.length, mappings: mappings.length, skipped };
}

async function persist(mappings) {
  await chrome.storage.local.set({
    fdhMappings: mappings,
    fdhSettings: { enabled: mappings.length > 0, mappings }
  });
}

async function clearRules() {
  const removeRuleIds = Array.from({ length: MAX_RULES }, (_, i) => FIRST_RULE_ID + i);
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "FDH_SYNC") {
    syncMappings(message.mappings)
      .then(async result => {
        await persist(message.mappings);
        sendResponse({ ok: true, result });
      })
      .catch(error => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "FDH_APPLY") {
    const incoming = message.settings || {};
    chrome.storage.local.get(["fdhMappings", "fdhSettings"])
      .then(async stored => {
        const mappings = Array.isArray(stored.fdhMappings)
          ? stored.fdhMappings
          : normalizeMappings(stored.fdhSettings);
        const key = `${incoming.evolution}::${incoming.sourceSkin}`;
        const next = mappings.filter(x => `${x.evolution}::${x.sourceSkin}` !== key);
        next.push({
          id: `${incoming.evolution}-${incoming.sourceSkin}`,
          evolution: incoming.evolution,
          sourceSkin: incoming.sourceSkin,
          skin: incoming.skin
        });
        const result = await syncMappings(next);
        await persist(next);
        sendResponse({ ok: true, result, mappings: next });
      })
      .catch(error => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "FDH_RESET") {
    syncMappings([])
      .then(async () => {
        await persist([]);
        sendResponse({ ok: true });
      })
      .catch(error => sendResponse({ ok: false, error: error.message }));
    return true;
  }
});

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get(["fdhMappings", "fdhSettings"]);
  const mappings = Array.isArray(stored.fdhMappings)
    ? stored.fdhMappings
    : normalizeMappings(stored.fdhSettings);
  try {
    await syncMappings(mappings);
    await persist(mappings);
  } catch (e) {
    // A stale or invalid saved mapping must not leave broken rules behind.
    console.warn("FLAME DRAGON HUB: saved mappings could not be restored, clearing them.", e);
    try {
      await clearRules();
      await persist([]);
    } catch (cleanupError) {
      console.error("FLAME DRAGON HUB: could not clear redirect rules.", cleanupError);
    }
  }
});
