// Publishes the user's active mappings into the page world.
//
// Each mapping carries the real animation frames of the skin the user picked, so the bridge
// can answer every EvoWorld sprite request with that skin's own artwork. Nothing is shared
// between skins: a mapping without frames simply falls back to its own still image.
//
// Frame data lives in frames-catalog.json, which is generated from the live EvoWorld CDN by
// tools/build-frame-catalog.js. A state that does not exist on the CDN (pumpkinGhost and
// ghostlyReaper have no idle folder) is left out so the bridge can substitute correctly.
const FDH_CDN = "https://cdn.eu.evoworld.io/sprites/characters";

let frameCatalog = {};
const catalogReady = fetch(chrome.runtime.getURL("frames-catalog.json"))
  .then(response => response.ok ? response.json() : {})
  .then(data => {
    frameCatalog = (data && typeof data === "object") ? data : {};
    return frameCatalog;
  })
  .catch(() => ({}));

function framesFor(evolution, sourceSkin) {
  const states = frameCatalog?.[`${evolution}/${sourceSkin}`];
  if (!states || typeof states !== "object") return undefined;
  const frames = {};
  for (const state of ["idle", "flying", "attack"]) {
    const numbers = states[state];
    if (Array.isArray(numbers) && numbers.length) {
      frames[state] = numbers.map(n => `${FDH_CDN}/${evolution}/${sourceSkin}/${state}/${n}.png`);
    }
  }
  return Object.keys(frames).length ? frames : undefined;
}

async function publishCustomMappings() {
  try {
    const catalog = await catalogReady;
    const stored = await chrome.storage.local.get(["fdhMappings", "fdhCustomSkins"]);
    const mappings = Array.isArray(stored.fdhMappings) ? stored.fdhMappings : [];
    const customSkins = Array.isArray(stored.fdhCustomSkins) ? stored.fdhCustomSkins : [];

    const custom = mappings.filter(m => m.customId).map(m => {
      const skin = customSkins.find(x => x.id === m.customId);
      if (!skin?.dataUrl) return null;
      // The uploaded image is the artwork; the native frame sequence only supplies the
      // motion timing, which the bridge expresses by cycling the image.
      return {
        evolution: m.evolution,
        sourceSkin: m.sourceSkin,
        dataUrl: skin.dataUrl,
        frames: skin.frames && typeof skin.frames === "object" ? skin.frames : undefined
      };
    }).filter(Boolean);

    window.postMessage({
      type: "FDH_CUSTOM_SKIN_MAPPINGS",
      mappings: custom,
      catalogSize: Object.keys(catalog || {}).length
    }, "*");

    console.info(`[FLAME DRAGON HUB] Published ${custom.length} custom mapping(s); ` +
      `frame catalog has ${Object.keys(catalog || {}).length} skin(s).`);
  } catch (e) {
    console.warn("FLAME DRAGON HUB: could not load custom mappings", e);
  }
}

publishCustomMappings();

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.fdhMappings || changes.fdhCustomSkins)) publishCustomMappings();
});

// Lets the popup report whether the animation frame catalog is present.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "FDH_FRAME_CATALOG_INFO") {
    catalogReady.then(catalog => sendResponse({
      ok: true,
      skins: Object.keys(catalog || {}).length
    })).catch(() => sendResponse({ ok: false, skins: 0 }));
    return true;
  }
});
